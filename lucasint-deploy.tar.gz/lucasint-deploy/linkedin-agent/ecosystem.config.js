/**
 * PM2 Ecosystem Config — GeoJob Agent Suite v2
 * Adds: persistent Telegram command bot (24/7)
 * Deploy: pm2 start ecosystem.config.js && pm2 save
 */

module.exports = {
  apps: [
    {
      name: 'geojob-telegram-bot',
      script: './agents/telegram-bot.js',
      watch: false,
      autorestart: true,           // persistent — always running
      max_restarts: 50,
      restart_delay: 5000,
      log_file: './logs/telegram-bot.log',
      error_file: './logs/telegram-bot-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    },
    {
      name: 'geojob-monitoring',
      script: './agents/monitoring.js',
      cron_restart: '0 * * * *',
      watch: false,
      autorestart: false,
      log_file: './logs/monitoring.log',
      error_file: './logs/monitoring-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    },
    {
      name: 'geojob-morning-briefing',
      script: './agents/morning-briefing.js',
      cron_restart: '0 7 * * *',
      watch: false,
      autorestart: false,
      log_file: './logs/morning-briefing.log',
      error_file: './logs/morning-briefing-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    },
    {
      name: 'geojob-evening-digest',
      script: './agents/evening-digest.js',
      cron_restart: '0 18 * * *',
      watch: false,
      autorestart: false,
      log_file: './logs/evening-digest.log',
      error_file: './logs/evening-digest-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    },
    {
      name: 'geojob-shopping',
      script: './agents/shopping.js',
      cron_restart: '5 18 * * *',   // 6:05 PM — staggered after digest
      watch: false,
      autorestart: false,
      log_file: './logs/shopping.log',
      error_file: './logs/shopping-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    },
    {
      name: 'linkedin-draft',
      script: './agents/linkedin-bot.js',
      args: 'draft',
      cron_restart: '0 8 * * 0',    // Sunday 8am AEST — draft + send to Telegram
      watch: false,
      autorestart: false,
      log_file: './logs/linkedin-draft.log',
      error_file: './logs/linkedin-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    },
    {
      name: 'linkedin-post',
      script: './agents/linkedin-bot.js',
      args: 'post',
      cron_restart: '0 8 * * 1-6',  // Mon-Sat 8am AEST — post one approved item
      watch: false,
      autorestart: false,
      log_file: './logs/linkedin-post.log',
      error_file: './logs/linkedin-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    },
    {
      name: 'linkedin-callbacks',
      script: './agents/linkedin-bot.js',
      args: 'callbacks',
      watch: false,
      autorestart: true,            // 24/7 — listens for approve/skip taps
      max_restarts: 50,
      restart_delay: 5000,
      log_file: './logs/linkedin-callbacks.log',
      error_file: './logs/linkedin-error.log',
      time: true,
      env: { NODE_ENV: 'production', TZ: 'Australia/Sydney' }
    }
  ]
};
