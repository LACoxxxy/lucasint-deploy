/**
 * GeoJob Station — LinkedIn Automation Agent
 * ─────────────────────────────────────────────────────────────────────────
 * Sunday 8am: Claude drafts 6 posts → Telegram approval buttons
 * Mon-Sat 8am: Posts one approved post via Playwright headless Chrome
 *
 * Flow:
 *   Draft phase  → Claude API generates GeoJob posts (personal + company mix)
 *                → Each sent to Telegram with ✅ APPROVE / ✏️ SKIP buttons
 *                → Approved posts queued in linkedin-queue.json
 *
 *   Post phase   → Pick next approved post from queue
 *                → Playwright opens LinkedIn, posts to personal OR company page
 *                → Result reported to Telegram
 *
 * First-run login: run `npm run linkedin-login` on the Beelink once to sign in
 * with a visible browser and save the session. Subsequent runs use saved cookies.
 * ─────────────────────────────────────────────────────────────────────────
 */

require('dotenv').config({ path: __dirname + '/../.env' });
const https  = require('https');
const fs     = require('fs');
const path   = require('path');

const TOKEN     = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID   = String(process.env.TELEGRAM_CHAT_ID || '');
const CLAUDE_KEY = process.env.ANTHROPIC_API_KEY;
const COMPANY_PAGE = process.env.LINKEDIN_COMPANY_SLUG || 'geojob-australia'; // slug from your company URL

const DATA_DIR  = path.join(__dirname, '..', 'data');
const QUEUE_FILE = path.join(DATA_DIR, 'linkedin-queue.json');
const PROFILE_DIR = path.join(DATA_DIR, 'chrome-linkedin-profile');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ── Queue helpers ────────────────────────────────────────────────────────
function loadQueue() {
  try { return JSON.parse(fs.readFileSync(QUEUE_FILE, 'utf8')); } catch { return []; }
}
function saveQueue(q) { fs.writeFileSync(QUEUE_FILE, JSON.stringify(q, null, 2)); }

// ── Telegram helpers ─────────────────────────────────────────────────────
function tg(method, payload) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req = https.request({
      hostname: 'api.telegram.org',
      path: `/bot${TOKEN}/${method}`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
    });
    req.on('error', reject);
    req.end(body);
  });
}

function send(text, extra = {}) {
  return tg('sendMessage', { chat_id: CHAT_ID, text, parse_mode: 'HTML', ...extra });
}

function answerCallback(callback_query_id, text = 'Done') {
  return tg('answerCallbackQuery', { callback_query_id, text });
}

// ── Claude API — draft posts ─────────────────────────────────────────────
async function draftPosts() {
  const today = new Date().toLocaleDateString('en-AU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Australia/Sydney' });
  const prompt = `You are writing LinkedIn posts for Lucas Cox, founder of GeoJob (app.geojob.com.au) — a live GPS load-tracking and automated import/export register platform for bulk haulage and civil construction in Australia.

Draft 6 LinkedIn posts for the coming week. Mix:
- 2 posts for Lucas's PERSONAL LinkedIn (first-person, founder perspective, thought leadership on construction tech/productivity/digital transformation in civil construction)
- 2 posts for the GEOJOB COMPANY PAGE (professional, product-focused, benefits for contractors)
- 1 post either personal or company about a specific GeoJob feature (GPS tracking, import/export register, compliance)
- 1 post either personal or company that is a question/poll style to drive engagement

Guidelines:
- Australian audience, conversational but professional
- No hashtag spam — max 3 relevant hashtags per post
- Personal posts: 150-250 words, authentic founder voice
- Company posts: 100-200 words, benefit-led
- Do NOT use em dashes
- Include a clear call to action where natural
- Today is ${today}

Return ONLY a JSON array, no other text, no markdown fences:
[
  { "type": "personal|company", "content": "post text here", "hook": "opening line only (for preview)" },
  ...
]`;

  const res = await new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model: 'claude-sonnet-4-6', max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }]
    });
    const req = https.request({
      hostname: 'api.anthropic.com', path: '/v1/messages', method: 'POST',
      headers: {
        'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body),
        'x-api-key': CLAUDE_KEY, 'anthropic-version': '2023-06-01'
      }
    }, r => {
      let d = ''; r.on('data', c => d += c);
      r.on('end', () => { try { resolve(JSON.parse(d)); } catch(e) { reject(e); } });
    });
    req.on('error', reject); req.end(body);
  });

  const text = res.content?.[0]?.text || '[]';
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}

// ── Draft phase: generate + send to Telegram for approval ────────────────
async function runDraftPhase() {
  await send('📝 <b>LinkedIn weekly draft</b>\nGenerating 6 posts with Claude. Approve the ones you want to publish this week...');
  let posts;
  try { posts = await draftPosts(); }
  catch(e) { await send(`❌ Draft failed: ${e.message}`); return; }

  for (let i = 0; i < posts.length; i++) {
    const p = posts[i];
    const tag = p.type === 'personal' ? '👤 Personal' : '🏢 GeoJob page';
    const preview = `<b>${tag} — Post ${i+1}/${posts.length}</b>\n\n${p.content.slice(0, 800)}${p.content.length > 800 ? '...' : ''}`;
    await tg('sendMessage', {
      chat_id: CHAT_ID, text: preview, parse_mode: 'HTML',
      reply_markup: { inline_keyboard: [[
        { text: '✅ Approve', callback_data: `li_approve_${i}` },
        { text: '⏭ Skip', callback_data: `li_skip_${i}` }
      ]]}
    });
    // Store draft in queue with pending status
    const q = loadQueue();
    q.push({ id: i, type: p.type, content: p.content, status: 'pending', draftedAt: new Date().toISOString() });
    saveQueue(q);
    await new Promise(r => setTimeout(r, 1000));
  }
  await send('👆 Tap Approve on the posts you want posted this week. Skipped posts are discarded.');
}

// ── Post phase: post next approved item via Playwright ───────────────────
async function runPostPhase() {
  const q = loadQueue();
  const next = q.find(p => p.status === 'approved');
  if (!next) { await send('📭 LinkedIn: no approved posts in queue. Approve some on Sunday to queue them up.'); return; }

  await send(`🔗 LinkedIn: posting ${next.type === 'personal' ? 'personal' : 'company page'} post...\n\n<i>${next.content.slice(0, 200)}...</i>`);

  let pw;
  try {
    pw = require('playwright');
  } catch(e) {
    await send('❌ Playwright not installed on this machine. Run the install command first.');
    return;
  }

  const browser = await pw.chromium.launchPersistentContext(PROFILE_DIR, {
    headless: true,
    args: [
      '--no-sandbox', '--disable-setuid-sandbox',
      '--disable-blink-features=AutomationControlled',
      '--disable-dev-shm-usage', '--no-first-run',
    ],
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 900 },
  });

  try {
    const page = await browser.newPage();
    await page.goto('https://www.linkedin.com', { waitUntil: 'domcontentloaded', timeout: 30000 });

    // Check logged in
    const isLoggedIn = await page.locator('[data-control-name="nav.homepage"]').count() > 0
      || await page.locator('a[href*="feed"]').count() > 0
      || (await page.url()).includes('/feed');

    if (!isLoggedIn) {
      await browser.close();
      await send('🔑 LinkedIn session expired. Run <code>npm run linkedin-login</code> on the Beelink to re-login.');
      return;
    }

    if (next.type === 'personal') {
      await postToPersonalFeed(page, next.content);
    } else {
      await postToCompanyPage(page, next.content);
    }

    // Mark posted
    next.status = 'posted';
    next.postedAt = new Date().toISOString();
    saveQueue(q.map(p => p.id === next.id ? next : p));

    await send(`✅ <b>LinkedIn posted!</b>\n${next.type === 'personal' ? '👤 Personal feed' : '🏢 GeoJob company page'}\n\n<i>${next.content.slice(0, 300)}${next.content.length > 300 ? '...' : ''}</i>`);
  } catch(e) {
    await send(`❌ LinkedIn post failed: ${e.message.slice(0, 300)}`);
  } finally {
    await browser.close();
  }
}

async function postToPersonalFeed(page, content) {
  await page.goto('https://www.linkedin.com/feed/', { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForTimeout(2000);

  // Click "Start a post"
  const startPost = page.locator('button:has-text("Start a post"), [placeholder*="post"], .share-box-feed-entry__trigger').first();
  await startPost.waitFor({ timeout: 15000 });
  await startPost.click();
  await page.waitForTimeout(2000);

  // Type content
  const editor = page.locator('.ql-editor, [contenteditable="true"][role="textbox"]').first();
  await editor.waitFor({ timeout: 10000 });
  await editor.click();
  await page.keyboard.type(content, { delay: 15 });
  await page.waitForTimeout(1000);

  // Click Post button
  const postBtn = page.locator('button:has-text("Post")').last();
  await postBtn.waitFor({ timeout: 10000 });
  await postBtn.click();
  await page.waitForTimeout(3000);
}

async function postToCompanyPage(page, content) {
  await page.goto(`https://www.linkedin.com/company/${COMPANY_PAGE}/admin/`, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForTimeout(2500);

  // Click "Start a post" on company page
  const startPost = page.locator('button:has-text("Start a post"), .share-box-feed-entry__trigger').first();
  await startPost.waitFor({ timeout: 15000 });
  await startPost.click();
  await page.waitForTimeout(2000);

  const editor = page.locator('.ql-editor, [contenteditable="true"][role="textbox"]').first();
  await editor.waitFor({ timeout: 10000 });
  await editor.click();
  await page.keyboard.type(content, { delay: 15 });
  await page.waitForTimeout(1000);

  const postBtn = page.locator('button:has-text("Post")').last();
  await postBtn.waitFor({ timeout: 10000 });
  await postBtn.click();
  await page.waitForTimeout(3000);
}

// ── Callback handler: wire into main Telegram bot via shared polling ─────
// (This agent handles callback_query updates for li_approve_* / li_skip_*)
async function handleCallback(update) {
  const cq = update.callback_query;
  if (!cq || String(cq.from.id) !== CHAT_ID) return false;
  const data = cq.data || '';
  if (!data.startsWith('li_')) return false;

  const [,action, idxStr] = data.split('_');
  const idx = parseInt(idxStr);
  const q = loadQueue();
  const item = q.find(p => p.id === idx);
  if (!item) { await answerCallback(cq.id, 'Not found'); return true; }

  if (action === 'approve') {
    item.status = 'approved';
    item.approvedAt = new Date().toISOString();
    saveQueue(q.map(p => p.id === idx ? p : item));
    await answerCallback(cq.id, '✅ Queued for posting');
    await tg('editMessageReplyMarkup', { chat_id: cq.message.chat.id, message_id: cq.message.message_id, reply_markup: { inline_keyboard: [] } });
    await send(`✅ Post ${idx + 1} approved and queued.`);
  } else {
    item.status = 'skipped';
    saveQueue(q.map(p => p.id === idx ? item : p));
    await answerCallback(cq.id, '⏭ Skipped');
    await tg('editMessageReplyMarkup', { chat_id: cq.message.chat.id, message_id: cq.message.message_id, reply_markup: { inline_keyboard: [] } });
  }
  return true;
}

// ── Standalone polling mode (when run directly for callback handling) ─────
async function pollForCallbacks() {
  let offset = 0;
  console.log(`[linkedin-bot] Polling for Telegram callbacks (li_approve/li_skip)…`);
  while (true) {
    try {
      const r = await tg('getUpdates', { offset, timeout: 30, allowed_updates: ['callback_query'] });
      for (const u of (r.result || [])) {
        offset = u.update_id + 1;
        await handleCallback(u).catch(e => console.error('[linkedin-bot] callback err:', e.message));
      }
    } catch(e) { await new Promise(r => setTimeout(r, 5000)); }
  }
}

// ── First-run login helper ────────────────────────────────────────────────
async function runLogin() {
  let pw;
  try { pw = require('playwright'); } catch { console.error('Run: npm install playwright && npx playwright install chromium'); process.exit(1); }
  console.log('Opening LinkedIn in headed browser — log in, then close the browser window.');
  if (!fs.existsSync(PROFILE_DIR)) fs.mkdirSync(PROFILE_DIR, { recursive: true });
  const browser = await pw.chromium.launchPersistentContext(PROFILE_DIR, {
    headless: false,
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  const page = await browser.newPage();
  await page.goto('https://www.linkedin.com/login');
  await send('🔑 LinkedIn login browser is open on the Beelink. Log in and then close the browser window. Session will be saved.');
  browser.on('disconnected', async () => { await send('✅ LinkedIn session saved. The bot will use this session for posting.'); });
}

// ── Entry point ──────────────────────────────────────────────────────────
const mode = process.argv[2];
if (mode === 'draft')  { runDraftPhase().catch(e => { console.error(e); process.exit(1); }); }
else if (mode === 'post')   { runPostPhase().catch(e => { console.error(e); process.exit(1); }); }
else if (mode === 'login')  { runLogin().catch(e => { console.error(e); process.exit(1); }); }
else if (mode === 'callbacks') { pollForCallbacks(); }
else {
  // Default: decide based on day of week (Sunday=0 → draft, else → post)
  const day = new Date(new Date().toLocaleString('en-US', { timeZone: 'Australia/Sydney' })).getDay();
  if (day === 0) runDraftPhase().catch(console.error);
  else runPostPhase().catch(console.error);
}

module.exports = { handleCallback };
