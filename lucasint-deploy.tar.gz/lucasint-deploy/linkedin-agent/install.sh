#!/bin/bash
set -e
echo "=== LinkedIn Agent Install ==="

# 1. Copy files into geojob-agents
cp ~/lucasint-deploy/linkedin-agent/linkedin-bot.js ~/geojob-agents/agents/linkedin-bot.js
cp ~/lucasint-deploy/linkedin-agent/ecosystem.config.js ~/geojob-agents/ecosystem.config.js
echo "Files copied"

# 2. Install Playwright + Chromium in geojob-agents
cd ~/geojob-agents
npm install playwright
NODE_OPTIONS='' npx playwright install chromium --with-deps
echo "PLAYWRIGHT_INSTALLED"

# 3. Add linkedin-login npm script
node -e "
const fs=require('fs');
const p=JSON.parse(fs.readFileSync('package.json','utf8'));
p.scripts=p.scripts||{};
p.scripts['linkedin-login']='node agents/linkedin-bot.js login';
p.scripts['linkedin-draft']='node agents/linkedin-bot.js draft';
p.scripts['linkedin-post']='node agents/linkedin-bot.js post';
fs.writeFileSync('package.json',JSON.stringify(p,null,2));
console.log('npm scripts updated');
"

# 4. Register LinkedIn PM2 processes
pm2 start ecosystem.config.js --only linkedin-callbacks
pm2 start ecosystem.config.js --only linkedin-draft || true
pm2 start ecosystem.config.js --only linkedin-post || true
pm2 save
echo ""
pm2 list | grep -E "linkedin|geojob"
echo ""
echo "=== DONE ==="
echo "One more step: run the login command to save your LinkedIn session:"
echo "  cd ~/geojob-agents && npm run linkedin-login"
echo "A headed browser opens (via xvfb). Log in once and session is saved forever."
