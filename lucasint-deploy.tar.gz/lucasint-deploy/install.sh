#!/usr/bin/env bash
#
# LucasINT — one-command installer for the Beelink (Ubuntu 24.04)
# Run from inside the lucasint-deploy folder:   ./install.sh
#
# It does the heavy lifting and pauses only for things ONLY YOU can do:
#   - pasting your API key   (a secret; never hardcoded)
#   - the Tailscale login    (a browser approval only you can give)
#
# Safe to re-run: it checks what's already done and skips it.

set -e  # stop on any error
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; RED='\033[0;31m'; NC='\033[0m'
say(){ echo -e "${CYAN}==>${NC} $1"; }
ok(){ echo -e "${GREEN}✓${NC} $1"; }
warn(){ echo -e "${YELLOW}!${NC} $1"; }

echo -e "${CYAN}"
echo "  LucasINT installer"
echo "  ------------------"
echo -e "${NC}"

# --- 0. sanity: are we in the right folder? ---
if [ ! -f "package.json" ] || [ ! -d "src" ]; then
  echo -e "${RED}This must be run from inside the lucasint-deploy folder.${NC}"
  echo "cd into that folder first, then run ./install.sh again."
  exit 1
fi
ok "Running from the lucasint-deploy folder."

# --- 1. system update ---
say "Updating the system (may ask for your password)…"
sudo apt-get update -qq && sudo apt-get upgrade -y -qq
sudo apt-get install -y -qq curl git
ok "System updated."

# --- 2. timezone (best-effort; edit later if wrong) ---
if command -v timedatectl >/dev/null; then
  say "Setting timezone to Australia/Sydney (change later with: sudo timedatectl set-timezone <Zone>)…"
  sudo timedatectl set-timezone Australia/Sydney || warn "Couldn't set timezone automatically — not fatal."
  ok "Timezone set."
fi

# --- 3. Node.js 22 ---
if command -v node >/dev/null && [ "$(node -v | cut -d. -f1 | tr -d 'v')" -ge 20 ] 2>/dev/null; then
  ok "Node.js already installed ($(node -v))."
else
  say "Installing Node.js 22…"
  curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - >/dev/null 2>&1
  sudo apt-get install -y -qq nodejs
  ok "Node.js installed ($(node -v))."
fi

# --- 4. app dependencies ---
say "Installing app dependencies (npm install)…"
npm install --no-audit --no-fund
ok "Dependencies installed."

# --- 5. .env setup (prompts for secrets — never hardcoded) ---
if [ -f ".env" ]; then
  ok ".env already exists — leaving it as-is."
else
  say "Creating your .env config file…"
  cp .env.example .env
  echo ""
  warn "I need two things from you. They're stored ONLY on this machine, never shared."
  echo ""
  read -rp "  Paste your Anthropic (Claude) API key: " ANTHKEY
  read -rp "  Your name + email for SEC (e.g. Lucas Cox lucas@geojob.com): " SECUA
  # write them in safely
  sed -i "s|ANTHROPIC_API_KEY=.*|ANTHROPIC_API_KEY=${ANTHKEY}|" .env
  sed -i "s|SEC_USER_AGENT=.*|SEC_USER_AGENT=${SECUA}|" .env
  ok "Secrets saved to .env (Telegram left blank — add later if you want alerts)."
fi

# --- 6. connectivity check ---
say "Checking connections (Claude + Yahoo)…"
npm run test-keys || warn "Some checks failed — you can fix .env and re-run 'npm run test-keys' later."

# --- 7. Tailscale (for phone access) ---
if command -v tailscale >/dev/null; then
  ok "Tailscale already installed."
else
  say "Installing Tailscale…"
  curl -fsSL https://tailscale.com/install.sh | sh >/dev/null 2>&1
  ok "Tailscale installed."
fi
echo ""
warn "NEXT: you must log Tailscale in yourself (opens a link only you can approve)."
echo "  Run this AFTER the installer finishes:   sudo tailscale up"
echo "  Then note the IP it shows (like 100.x.y.z) — that's how your phone reaches this box."
echo ""

# --- 8. systemd service (keeps it running + survives reboots) ---
say "Setting up the always-on service…"
SERVICE_USER=$(whoami)
APP_DIR=$(pwd)
sudo tee /etc/systemd/system/lucasint.service >/dev/null <<UNIT
[Unit]
Description=LucasINT Investment Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${APP_DIR}
ExecStart=$(command -v node) src/server.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable lucasint >/dev/null 2>&1
sudo systemctl restart lucasint
sleep 2
if sudo systemctl is-active --quiet lucasint; then
  ok "Service is running and will auto-start on every boot."
else
  warn "Service didn't start cleanly — check: journalctl -u lucasint -n 30"
fi

# --- done ---
echo ""
echo -e "${GREEN}================ DONE ================${NC}"
echo "  LucasINT is installed and running on this machine."
echo ""
echo "  On THIS Beelink, open:   http://localhost:8080"
echo ""
echo "  To reach it from your PHONE:"
echo "    1. Run:  sudo tailscale up   (approve the link it shows)"
echo "    2. Install the Tailscale app on your phone, log in (same account)"
echo "    3. On your phone browser go to:  http://<the-100.x.y.z-IP>:8080"
echo "    4. Share -> Add to Home Screen"
echo ""
echo "  Useful commands:"
echo "    See logs:      journalctl -u lucasint -f"
echo "    Restart:       sudo systemctl restart lucasint"
echo "    Stop:          sudo systemctl stop lucasint"
echo "    Re-check keys: npm run test-keys"
echo -e "${GREEN}=====================================${NC}"
