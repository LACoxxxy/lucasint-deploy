# LucasINT — Beelink Deployment (Refreshed)

## ⚡ QUICK START (automated)

Once the folder is on the Beelink, you only need ONE command:

```
cd lucasint-deploy
./install.sh
```

The script does everything — system update, Node.js, dependencies, the always-on
service, and Tailscale install. It pauses only twice, for things only you can do:
paste your Claude API key, and (after it finishes) run `sudo tailscale up` to log in.

Everything below is the manual step-by-step, kept for reference or if the script
hits a snag. But `./install.sh` is the fast path.

---


## Current state of the build (read this first)

Since the original guide, the package now includes the full feature set:
- **PWA** (public/index.html): screener with tiered detail, 6-factor conviction
  scoring, DCF + reverse-DCF, strength-and-upside weighted Allocate tab (language
  box + controls), Positions/exit monitor, Aligned tab, Terminal.
- **Modules** (src/): market-status (12 global exchanges), sentiment-direction
  (confidence-gated buzz), exit-strategy (stops/targets/conviction-decay),
  validation-harness (out-of-sample testing), research-guardrails (data validation
  + hallucination guard), trade-guardrails (execution safety, dormant/locked).
- **Backend** (server.js + jobs): serves the PWA, proxies Claude API server-side,
  screens the watchlist, writes the 6pm digest, exposes /api/markets, /api/screen.

### What goes LIVE the moment you run it on the Beelink
- Real Yahoo Finance prices + fundamentals feeding the screen job.
- The AI Deep Analysis button (Claude API key held server-side).
- Global market open/closed status.
- The PWA served over your network.

### What still needs finishing (honest TODO list)
1. **Port the full scoring model into src/jobs/screen.js.** The fetcher pulls raw
   fundamentals; the 6-factor scoring/validation currently lives in the PWA. Until
   ported, live-data scoring will be partial. THIS IS THE FIRST TASK once running.
2. **ROIC** isn't in Yahoo's basic feed — needs a balance-sheet calc (placeholder for now).
3. **Directional sentiment** (buzz direction) stays "unknown" until live options/
   social/price sources are wired — ALIGNED flag correctly stays pending until then.
4. **Validation harness** shows UNVALIDATED until historical + point-in-time data is fed.
5. **Telegram** command listener (sending works; interactive commands are next).
6. **Trade execution** stays LOCKED — do not unlock without deliberate, staged opt-in.

### Do NOT use the research report's numbers
The recent research scan returned pre-2025 placeholder figures (live-data tools
failed mid-scan). The Beelink's live Yahoo feed is your source of truth for numbers;
the research report is qualitative context (theses, risk flags) only.

---


A step-by-step runbook for arrival day. Written to be followed top to bottom.
Everything here has been tested; the backend boots and serves the PWA already.

**Honest framing before you start:** this gets the *research agent* live — screening,
the mobile app served over your network, the 6pm digest, AI analysis with the key held
safely server-side. It does **not** enable any trading. Execution stays locked until you
deliberately wire and turn it on, much later. That separation is intentional.

---

## What you have in this package

```
lucasint-deploy/
├── package.json          # dependencies + scripts
├── .env.example          # copy to .env, fill in keys
├── DEPLOYMENT.md         # this file
├── public/
│   └── index.html        # the mobile PWA (served to your phone/tablet)
├── src/
│   ├── server.js         # main server: serves PWA, API, schedules jobs
│   ├── research-guardrails.js  # input validation + hallucination guard
│   ├── trade-guardrails.js     # execution safety (dormant until trading)
│   ├── util/
│   │   ├── claude.js     # Claude API wrapper (key stays here)
│   │   ├── yahoo.js      # live fundamentals fetcher (no key)
│   │   ├── telegram.js   # digest/alert sender
│   │   ├── store.js      # simple JSON store
│   │   └── test-keys.js  # connectivity checker — run this first
│   ├── jobs/
│   │   ├── screen.js     # live screen loop
│   │   └── digest.js     # 6pm digest writer
│   └── data/
│       └── watchlist.json
└── data/                 # runtime cache (gitignored)
```

---

## STEP 1 — First boot of the Beelink (Ubuntu 24.04)

You noted Ubuntu 24.04 already. On first login:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git build-essential
```

Set the timezone so the 6pm digest and screen times are correct (AEST example):
```bash
sudo timedatectl set-timezone Australia/Brisbane   # adjust to your state
timedatectl   # verify
```

---

## STEP 2 — Install Node.js (LTS)

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node --version   # should print v22.x
```

---

## STEP 3 — Get the code onto the Beelink

Two options:

**A. Via GitHub (fits your existing workflow):**
```bash
cd ~
git clone https://github.com/LACoxxxy/lucasint-agent.git
cd lucasint-agent
```
(You'll push this package to that repo first — see "Putting it in GitHub" below.)

**B. Direct copy:** USB stick / scp the `lucasint-deploy` folder to `~/lucasint-agent`.

Then:
```bash
npm install
```

---

## STEP 4 — Configure secrets

```bash
cp .env.example .env
nano .env
```

Fill in, at minimum:
- `ANTHROPIC_API_KEY` — from console.anthropic.com (research + digest won't work without it)
- `SEC_USER_AGENT` — your name + email (SEC requires this; no signup)

Add when ready (not required to start):
- `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` — from your Telegram bot chat
- `QUIVER_API_KEY` — when you subscribe (~$20/mo, the high-value paid source)

Save (Ctrl-O, Enter, Ctrl-X). The `.env` is gitignored — it never leaves the box.

---

## STEP 5 — Verify everything connects

```bash
npm run test-keys
```

Expected:
```
Claude API … ✓ connected
Yahoo Finance … ✓ reachable
SEC EDGAR … ✓ reachable
Telegram bot … ✓ @your_bot   (or ✗ if not set up yet — fine for now)
```
Fix any ✗ in `.env` and re-run. **Yahoo + Claude are the minimum to start.**

---

## STEP 6 — First run

```bash
npm start
```
You should see the server start on port 8080 and the cron schedule print.
Open `http://localhost:8080` on the Beelink itself to confirm the PWA loads.

Trigger a live screen manually to test data flow:
```bash
curl -X POST http://localhost:8080/api/screen/run
```

---

## STEP 7 — Keep it running forever (systemd)

So it survives reboots and crashes. Create the service:

```bash
sudo nano /etc/systemd/system/lucasint.service
```
Paste (adjust paths/user):
```ini
[Unit]
Description=LucasINT Investment Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/home/YOUR_USERNAME/lucasint-agent
ExecStart=/usr/bin/node src/server.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```
Enable + start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable lucasint
sudo systemctl start lucasint
sudo systemctl status lucasint    # should be "active (running)"
```
View logs anytime:
```bash
journalctl -u lucasint -f
```

---

## STEP 8 — Access from your phone (Tailscale)

This is how the home-screen PWA reaches the Beelink from anywhere, securely.

On the Beelink:
```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
```
Follow the login link. Note the Beelink's Tailscale IP (e.g. `100.x.y.z`).

On your phone: install the Tailscale app, log in with the same account.

Now on your phone browser go to `http://100.x.y.z:8080` → Share → **Add to Home Screen**.
The icon now opens the live agent, full-screen, from anywhere. Same icon, live data.

(Cockpit, from your notes, installs alongside for web-based box management:
`sudo apt install cockpit` → reachable at `https://100.x.y.z:9090`.)

---

## STEP 9 — Point the PWA's AI button at the backend

In `public/index.html`, the AI analysis currently calls Claude directly (works only
inside Claude.ai). One small change makes it use your server instead:

Find the `runAI` function's `fetch("https://api.anthropic.com/...")` call and replace
the whole fetch with:
```js
const r = await fetch("/api/analyse", {
  method:"POST", headers:{"Content-Type":"application/json"},
  body: JSON.stringify({ system: sys, user: usr })
});
const data = await r.json();
let txt = data.text || "Analysis unavailable.";
```
Now the key stays on the Beelink and the button works on your phone. (I can make this
edit for you in the next session once the repo is set up.)

---

## Putting it in GitHub (do this before arrival day)

From this package on your current machine:
```bash
cd lucasint-deploy
git init && git add . && git commit -m "LucasINT deploy package"
# create a private repo LACoxxxy/lucasint-agent on github.com first, then:
git remote add origin https://github.com/LACoxxxy/lucasint-agent.git
git branch -M main && git push -u origin main
```
The `.gitignore` keeps `.env`, `node_modules`, and runtime data out. Safe to push.

---

## What's deliberately NOT here yet (and why)

- **Live ROIC + full scoring in screen.js** — the fetcher pulls raw fundamentals; the
  proven scoring model needs porting in (a clean next task). Marked with TODO.
- **Trade execution** — `trade-guardrails.js` is present but dormant. No broker is wired.
  Stays that way until you explicitly choose to, on `confirm` mode, far down the line.
- **Telegram command handling** — sending works; the interactive command listener
  (screen now, analyse $X, kill switch) is the natural next build.

## Arrival-day checklist (tear-off)

```
[ ] apt update/upgrade, set timezone
[ ] install Node 22
[ ] clone repo / copy folder, npm install
[ ] cp .env.example .env, add ANTHROPIC_API_KEY + SEC_USER_AGENT
[ ] npm run test-keys  → Claude + Yahoo green
[ ] npm start, open localhost:8080
[ ] curl -X POST localhost:8080/api/screen/run  → data flows
[ ] systemd service, enable + start
[ ] tailscale up, note IP
[ ] phone: Tailscale app, add PWA to home screen
[ ] (later) Telegram keys, AI button repoint, scoring port-in
```

---

Research tooling, not financial advice. The agent surfaces and ranks; every decision
is yours. Keep execution locked until you have consciously, deliberately enabled it.

---

## Out-of-hours behaviour (what to expect)

The agent is built fundamentals-first, so it is useful 24/7 — but it is honest
about what is live:

- **Fundamentals, signals, scores, DCF, sizing** — always current. They don't move
  intraday anyway (they change on earnings/filings), so screening and ranking work
  at any hour.
- **Live price + momentum** — out of hours these show the **last close**, clearly
  labelled. The price isn't wrong, it just isn't moving.
- **Market status** — every screen result is tagged with its exchange and whether
  that market is OPEN/CLOSED, plus ETA to next open (or to close if open). The PWA
  shows a global market bar across the top (12 exchanges).

`/api/markets` returns live status for all 12 exchanges. The PWA computes the same
client-side so it works even before the backend is up.

**Known limitation:** market hours do NOT account for public holidays — a market may
show "open" on a holiday. Add a per-exchange holiday calendar later if this matters.
Lunch breaks (Tokyo, HK, Taiwan, Korea) ARE handled.

**Data sourcing caveat:** Yahoo covers most non-US exchanges via suffix tickers
(.AX, .L, .T, .TW, .KS, .HK, etc), but reliability varies for the more exotic ones.
US + ASX + major European names are solid; verify Asian small-caps individually.
