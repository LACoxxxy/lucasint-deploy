/**
 * universe.js — Dynamic stock universe builder.
 *
 * Combines two sources:
 *  1. ETF seeds (hand-curated, liquid names per sector)
 *  2. EDGAR SIC sweep (every SEC-registered company in relevant industry codes)
 *
 * Output: universe.json — {ticker: {name, sector, cik, source}} 
 * Refreshed weekly by discover.js; used by screen.js as the screening universe.
 *
 * Why EDGAR SIC?  It catches names not in any ETF — the genuinely unknown
 * small/micro-cap operators that a thematic ETF excludes for being too small.
 * Those are exactly the asymmetric picks a screener should surface.
 */

const fs      = require('fs');
const path    = require('path');
const https   = require('https');

const UNIVERSE_FILE   = path.join(__dirname, '..', 'data', 'universe.json');
const TICKER_EXCHANGE = path.join(__dirname, '..', 'data', 'cik-map-exchange.json'); // CIK→ticker
const SECTOR_CFG      = require('../data/sector-config.json');

const SEC_UA = { 'User-Agent': 'LucasINT/1.0 (contact: lucas@geojob.com)', 'Accept': 'application/json' };

// ── Helpers ─────────────────────────────────────────────────────────────────
function get(url, opts = {}) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { ...SEC_UA, ...opts.headers }, timeout: 30000 }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        const body = Buffer.concat(chunks).toString('utf8');
        if (res.statusCode === 200) resolve(body);
        else reject(new Error(`HTTP ${res.statusCode} ${url.slice(0, 80)}`));
      });
    });
    req.on('timeout', () => req.destroy(new Error(`timeout ${url.slice(0, 60)}`)));
    req.on('error', reject);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Step 1: Build CIK→{ticker,name,exchange} reverse map ─────────────────────
async function loadCikToTickerMap() {
  // Cache this large file (4MB+) - refresh if older than 7 days
  const cacheFile = TICKER_EXCHANGE;
  try {
    const st = fs.statSync(cacheFile);
    if (Date.now() - st.mtimeMs < 7 * 24 * 3600 * 1000) {
      return JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
    }
  } catch { /* no cache */ }

  console.log('[universe] Fetching company_tickers_exchange.json from SEC...');
  const body = await get('https://www.sec.gov/files/company_tickers_exchange.json');
  const raw = JSON.parse(body);
  const map = {};
  for (const entry of Object.values(raw.data || raw)) {
    // format: {cik_str, ticker, name, exchange}  or array [cik, name, ticker, exchange]
    const cik = String(entry.cik_str || entry[0]).padStart(10, '0');
    const ticker = (entry.ticker || entry[2] || '').toUpperCase();
    const name = entry.name || entry[1] || '';
    const exchange = entry.exchange || entry[3] || '';
    if (ticker && (exchange === 'Nasdaq' || exchange === 'NYSE' || exchange === 'NYSE MKT' || exchange === 'BATS')) {
      map[cik] = { ticker, name, exchange };
    }
  }
  try { fs.writeFileSync(cacheFile, JSON.stringify(map)); } catch { }
  console.log(`[universe] CIK→ticker map: ${Object.keys(map).length} US-listed companies`);
  return map;
}

// ── Step 2: EDGAR SIC sweep — get all CIKs for a SIC code ───────────────────
async function fetchCIKsForSIC(sicCode, cikMap) {
  const results = [];
  let start = 0;
  while (true) {
    const url = `https://efts.sec.gov/LATEST/search-index?q=&forms=10-K,20-F&dateRange=custom&startdt=2021-01-01&hits.hits._source=period_of_report,entity_name,file_date,form_type,entity_id&hits.hits.total.value=true&hits.hits.highlight.enabled=false&category=form-type&_source=entity_id,entity_name&from=${start}&size=100`;
    // Use EDGAR full-text search with SIC filter via the company search HTML
    break; // EFTS doesn't filter by SIC — use the company search endpoint instead
  }

  // EDGAR company search by SIC (returns HTML, parse for CIKs). SEC caps count at 100 → paginate.
  try {
    const seen = new Set();
    for (let start = 0; start <= 400; start += 100) {
      const url = `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&SIC=${sicCode}&type=10-K&dateb=&owner=include&count=100&start=${start}`;
      const html = await get(url, { headers: { 'User-Agent': 'LucasINT/1.0 (contact: lucas@geojob.com)', 'Accept': 'text/html' } });
      // Links look like: ?action=getcompany&CIK=0001234567&type=10-K…  (CIK may be padded or not)
      const cikRegex = /CIK=(\d{4,10})(?=&|")/g;
      let m, pageHits = 0;
      while ((m = cikRegex.exec(html)) !== null) {
        const cik = m[1].padStart(10, '0');
        if (seen.has(cik)) continue;
        seen.add(cik); pageHits++;
        const entry = cikMap[cik];
        if (entry) results.push({ cik, ...entry, source: 'edgar' });
      }
      if (pageHits < 90) break;   // last page reached
      await sleep(400);
    }
  } catch(e) {
    console.warn(`[universe] SIC ${sicCode} sweep failed: ${e.message}`);
  }
  return results;
}

// ── ASX company list sweeper ─────────────────────────────────────────────────
// ASX publishes a full CSV of all listed companies with GICS industry groups.
// Free, no auth, updated daily. We filter by relevant GICS groups.
const ASX_GICS_MAP = {
  'Metals & Mining':                  'Critical Minerals',
  'Energy':                           'Critical Minerals',  // uranium miners sit here
  'Materials':                        'Critical Minerals',
  'Semiconductor':                    'Semiconductor Equipment',
  'Technology Hardware & Equipment':  'Semiconductor Equipment',
  'Software & Services':              'AI Software & Platforms',
  'Capital Goods':                    'Robotics & Automation',
  'Electronic Equipment':             'Semiconductor Equipment',
};

async function fetchASXUniverse() {
  const results = [];
  try {
    const csv = await get('https://www.asx.com.au/asx/research/ASXListedCompanies.csv');
    const lines = csv.split('\n').slice(2); // skip header rows
    for (const line of lines) {
      const parts = line.split(',');
      if (parts.length < 3) continue;
      const name = parts[0].replace(/"/g, '').trim();
      const code = parts[1].replace(/"/g, '').trim();
      const gics = parts[2].replace(/"/g, '').trim();
      if (!code || !gics) continue;
      const sector = ASX_GICS_MAP[gics];
      if (!sector) continue; // not in our sectors
      results.push({ ticker: `${code}.AX`, name, sector, source: 'asx', exchange: 'ASX' });
    }
    console.log(`[universe] ASX sweep: ${results.length} companies in target sectors`);
  } catch(e) {
    console.warn(`[universe] ASX sweep failed: ${e.message}`);
  }
  return results;
}

// ── Step 3: Build full universe ──────────────────────────────────────────────
async function buildUniverse() {
  console.log('[universe] Building dynamic universe...');
  const cikMap = await loadCikToTickerMap();
  const universe = {}; // ticker → {name, sector, cik, source}

  for (const [sector, cfg] of Object.entries(SECTOR_CFG)) {
    console.log(`[universe] Processing sector: ${sector}`);

    // Add ETF seeds
    for (const ticker of (cfg.etf_seeds || [])) {
      if (!universe[ticker]) {
        universe[ticker] = { name: ticker, sector, cik: null, source: 'seed' };
      }
    }

    // EDGAR SIC sweep (US companies)
    for (const sic of (cfg.sic || [])) {
      await sleep(500);
      const companies = await fetchCIKsForSIC(sic, cikMap);
      let added = 0;
      for (const co of companies) {
        if (!universe[co.ticker]) {
          universe[co.ticker] = { name: co.name, sector, cik: co.cik, source: 'edgar', exchange: co.exchange };
          added++;
        } else if (!universe[co.ticker].cik) {
          universe[co.ticker].cik = co.cik;
        }
      }
      console.log(`  SIC ${sic}: ${companies.length} companies found, ${added} new to universe`);
    }
  }

  // ASX sweep (Australian-listed companies)
  const asxCompanies = await fetchASXUniverse();
  let asxAdded = 0;
  for (const co of asxCompanies) {
    if (!universe[co.ticker]) {
      universe[co.ticker] = { name: co.name, sector: co.sector, source: 'asx', exchange: 'ASX' };
      asxAdded++;
    }
  }
  console.log(`[universe] ASX: ${asxAdded} new tickers added`);

  const total = Object.keys(universe).length;
  const edgarOnly = Object.values(universe).filter(v => v.source === 'edgar').length;
  console.log(`[universe] Total: ${total} tickers (${edgarOnly} EDGAR-discovered, ${total - edgarOnly} seeded)`);

  fs.writeFileSync(UNIVERSE_FILE, JSON.stringify(universe, null, 2));
  return universe;
}

// ── Load or build universe ───────────────────────────────────────────────────
async function getUniverse(forceRefresh = false) {
  if (!forceRefresh) {
    try {
      const st = fs.statSync(UNIVERSE_FILE);
      // Refresh weekly
      if (Date.now() - st.mtimeMs < 7 * 24 * 3600 * 1000) {
        return JSON.parse(fs.readFileSync(UNIVERSE_FILE, 'utf8'));
      }
    } catch { /* build fresh */ }
  }
  return buildUniverse();
}

module.exports = { getUniverse, buildUniverse };
