/** Yahoo Finance fetchers — quote + daily price history. No API key needed. */
const UA = { headers: { 'User-Agent': 'Mozilla/5.0 (LucasINT research; personal use)' } };

async function fetchQuote(ticker) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=1d&interval=1d&includePrePost=false`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo ${r.status}`);
  const j = await r.json();
  const meta = j?.chart?.result?.[0]?.meta;
  if (!meta) throw new Error('no chart meta');
  return {
    ticker, price: meta.regularMarketPrice, prevClose: meta.chartPreviousClose,
    currency: meta.currency, exchange: meta.exchangeName, _fetchedAt: new Date().toISOString(),
  };
}

/** Fundamentals now come from SEC EDGAR (Yahoo quoteSummary v10 requires crumb
 *  auth and returns nulls). Same return shape + fcfPerShare/fcfGrowth5y/roic/eps.
 *  Pass the current price (from fetchQuote) so PE and marketCap can be derived. */
const { fetchFundamentalsEdgar } = require('./edgar');
async function fetchFundamentals(ticker, price = null) {
  return fetchFundamentalsEdgar(ticker, price);
}

/** Daily closes for ~N years. Returns { dates:[], closes:[] } oldest→newest. */
async function fetchHistory(ticker, years = 3) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=${years}y&interval=1d`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo hist ${r.status}`);
  const j = await r.json();
  const res = j?.chart?.result?.[0];
  if (!res) throw new Error('no history');
  const ts = res.timestamp || [];
  const closes = res.indicators?.quote?.[0]?.close || [];
  const dates = [], px = [];
  for (let i = 0; i < ts.length; i++) if (closes[i] != null) { dates.push(ts[i] * 1000); px.push(closes[i]); }
  return { ticker, dates, closes: px };
}

module.exports = { fetchQuote, fetchFundamentals, fetchHistory };
