/**
 * Minimal Yahoo Finance fetcher (unofficial, no key). Returns the fundamentals
 * the screener needs. If Yahoo changes structure this is the file to fix.
 * Fields map to the same shape the PWA/scoring model expects.
 */
async function fetchQuote(ticker) {
  const url = `https://query1.finance.yahoo.com/v10/finance/quoteSummary/${ticker}?modules=price,summaryDetail,financialData,defaultKeyStatistics`;
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
  if (!r.ok) throw new Error(`Yahoo ${r.status} for ${ticker}`);
  const d = await r.json();
  const res = d?.quoteSummary?.result?.[0];
  if (!res) throw new Error(`No data for ${ticker}`);
  const price = res.price?.regularMarketPrice?.raw ?? null;
  const fd = res.financialData || {};
  const ks = res.defaultKeyStatistics || {};
  const sd = res.summaryDetail || {};
  return {
    ticker,
    price,
    pe: sd.trailingPE?.raw ?? null,
    revGrowth: fd.revenueGrowth?.raw != null ? +(fd.revenueGrowth.raw * 100).toFixed(1) : null,
    grossMargin: fd.grossMargins?.raw != null ? +(fd.grossMargins.raw * 100).toFixed(1) : null,
    roic: null, // ROIC needs balance-sheet calc; placeholder — compute separately
    debtToEquity: fd.debtToEquity?.raw != null ? +(fd.debtToEquity.raw / 100).toFixed(2) : null,
    currentRatio: fd.currentRatio?.raw ?? null,
    mktCap: res.price?.marketCap?.raw ?? null,
    shortPctFloat: sd.shortPercentOfFloat?.raw != null ? +(sd.shortPercentOfFloat.raw * 100).toFixed(1) : null,
    _fetchedAt: Date.now(),
  };
}
module.exports = { fetchQuote };
