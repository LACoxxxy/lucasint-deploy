/** Yahoo Finance fetchers — quote + daily price history. No API key needed.
 *  Works for all Yahoo-supported exchanges: use suffix for non-US tickers.
 *  e.g. PLS.AX (ASX), 8035.T (Tokyo), LYC.AX, LAC.TO, 6954.T (FANUC)
 */
const UA = { headers: { 'User-Agent': 'Mozilla/5.0 (LucasINT research; personal use)' } };

async function fetchQuote(ticker) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=1d&interval=1d&includePrePost=false`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo ${r.status}`);
  const j = await r.json();
  const meta = j?.chart?.result?.[0]?.meta;
  if (!meta || !meta.regularMarketPrice) throw new Error('no quote data');
  return {
    ticker,
    price:      meta.regularMarketPrice,
    prevClose:  meta.chartPreviousClose,
    currency:   meta.currency,
    exchange:   meta.exchangeName,
    // Basic fundamentals from chart meta — available for ALL markets, no auth needed
    // These supplement EDGAR (US) or serve as the only source (international)
    pe:         meta.trailingPE       ?? null,
    eps:        meta.regularMarketEPS ?? null,
    marketCap:  meta.marketCap        ?? null,
    high52w:    meta.fiftyTwoWeekHigh ?? null,
    low52w:     meta.fiftyTwoWeekLow  ?? null,
    shortName:  meta.shortName        ?? null,
    _fetchedAt: new Date().toISOString(),
  };
}

/** Fundamentals: EDGAR for US filers, Yahoo quote meta fallback for international.
 *  Pass the quote object (not just price) so Yahoo-sourced PE/marketCap can be used. */
const { fetchFundamentalsEdgar } = require('./edgar');
async function fetchFundamentals(ticker, priceOrQuote = null) {
  const price = (priceOrQuote && typeof priceOrQuote === 'object') ? priceOrQuote.price : priceOrQuote;
  const quoteFields = (priceOrQuote && typeof priceOrQuote === 'object') ? priceOrQuote : null;

  // Try EDGAR first (US domestic + 20-F foreign filers)
  try {
    const edgarResult = await fetchFundamentalsEdgar(ticker, price);
    // Patch in Yahoo quote fields if EDGAR didn't get them
    if (quoteFields) {
      if (edgarResult.pe == null && quoteFields.pe != null) edgarResult.pe = quoteFields.pe;
      if (edgarResult.eps == null && quoteFields.eps != null) edgarResult.eps = quoteFields.eps;
      if (edgarResult.marketCap == null && quoteFields.marketCap != null) edgarResult.marketCap = quoteFields.marketCap;
    }
    return edgarResult;
  } catch (e) {
    // EDGAR failed (non-filer, international, or network issue)
    // Fall back to Yahoo chart meta for basic fundamentals
    if (quoteFields && (quoteFields.pe != null || quoteFields.marketCap != null)) {
      return {
        pe: quoteFields.pe ?? null,
        eps: quoteFields.eps ?? null,
        marketCap: quoteFields.marketCap ?? null,
        revGrowth: null, grossMargin: null, roic: null,
        fcfPerShare: null, fcfGrowth5y: null, freeCashflow: null,
        debtToEquity: null, currentRatio: null, shortPctFloat: null,
        _source: 'yahoo-quote', _asOf: quoteFields._fetchedAt,
      };
    }
    throw e;
  }
}

/** Daily closes for ~N years. Returns { dates:[], closes:[] } oldest→newest. */
async function fetchHistory(ticker, years = 3) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=${years}y&interval=1d`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo hist ${r.status}`);
  const j = await r.json();
  const res = j?.chart?.result?.[0];
  if (!res) throw new Error('no history');
  const ts = res.timestamp || [];
  const closes = res.indicators?.quote?.[0]?.close || [];
  const dates = [], px = [];
  for (let i = 0; i < ts.length; i++) if (closes[i] != null) { dates.push(ts[i] * 1000); px.push(closes[i]); }
  return { ticker, dates, closes: px };
}

module.exports = { fetchQuote, fetchFundamentals, fetchHistory };
