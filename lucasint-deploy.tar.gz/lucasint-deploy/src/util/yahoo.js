/** Yahoo Finance fetchers — quote + daily price history. No API key needed. */
const UA = { headers: { 'User-Agent': 'Mozilla/5.0 (LucasINT research; personal use)' } };

async function fetchQuote(ticker) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=1d&interval=1d&includePrePost=false`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo ${r.status}`);
  const j = await r.json();
  const meta = j?.chart?.result?.[0]?.meta;
  if (!meta) throw new Error('no chart meta');
  return {
    ticker, price: meta.regularMarketPrice, prevClose: meta.chartPreviousClose,
    currency: meta.currency, exchange: meta.exchangeName, _fetchedAt: new Date().toISOString(),
  };
}

/** quoteSummary: fundamentals (PE, growth, margins, balance sheet). Some fields may be null. */
async function fetchFundamentals(ticker) {
  const mods = 'defaultKeyStatistics,financialData,summaryDetail';
  const url = `https://query1.finance.yahoo.com/v10/finance/quoteSummary/${encodeURIComponent(ticker)}?modules=${mods}`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo qs ${r.status}`);
  const j = await r.json();
  const res = j?.quoteSummary?.result?.[0];
  if (!res) throw new Error('no quoteSummary');
  const fd = res.financialData || {}, ks = res.defaultKeyStatistics || {}, sd = res.summaryDetail || {};
  const num = x => (x && typeof x.raw === 'number') ? x.raw : null;
  return {
    ticker,
    pe: num(sd.trailingPE) ?? num(ks.forwardPE),
    revGrowth: num(fd.revenueGrowth) != null ? +(num(fd.revenueGrowth) * 100).toFixed(1) : null,
    grossMargin: num(fd.grossMargins) != null ? +(num(fd.grossMargins) * 100).toFixed(1) : null,
    debtToEquity: num(fd.debtToEquity) != null ? +(num(fd.debtToEquity) / 100).toFixed(2) : null,
    currentRatio: num(fd.currentRatio),
    freeCashflow: num(fd.freeCashflow),
    sharesOutstanding: num(ks.sharesOutstanding),
    shortPctFloat: num(ks.shortPercentOfFloat) != null ? +(num(ks.shortPercentOfFloat) * 100).toFixed(1) : null,
    marketCap: num(sd.marketCap) ?? num(ks.enterpriseValue),
  };
}

/** Daily closes for ~N years. Returns { dates:[], closes:[] } oldest→newest. */
async function fetchHistory(ticker, years = 3) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=${years}y&interval=1d`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo hist ${r.status}`);
  const j = await r.json();
  const res = j?.chart?.result?.[0];
  if (!res) throw new Error('no history');
  const ts = res.timestamp || [];
  const closes = res.indicators?.quote?.[0]?.close || [];
  const dates = [], px = [];
  for (let i = 0; i < ts.length; i++) if (closes[i] != null) { dates.push(ts[i] * 1000); px.push(closes[i]); }
  return { ticker, dates, closes: px };
}

module.exports = { fetchQuote, fetchFundamentals, fetchHistory };
