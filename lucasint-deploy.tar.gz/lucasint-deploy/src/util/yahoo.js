/** Yahoo Finance fetchers — quote + daily price history. No API key needed.
 *  Works for all Yahoo-supported exchanges: use suffix for non-US tickers.
 *  e.g. PLS.AX (ASX), 8035.T (Tokyo), LYC.AX, LAC.TO, 6954.T (FANUC)
 */
const UA = { headers: { 'User-Agent': 'Mozilla/5.0 (LucasINT research; personal use)' } };

async function fetchQuote(ticker) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=1d&interval=1d&includePrePost=false`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo ${r.status}`);
  const j = await r.json();
  const meta = j?.chart?.result?.[0]?.meta;
  if (!meta || !meta.regularMarketPrice) throw new Error('no quote data');
  return {
    ticker,
    price:      meta.regularMarketPrice,
    prevClose:  meta.chartPreviousClose,
    currency:   meta.currency,
    exchange:   meta.exchangeName,
    // Basic fundamentals from chart meta — available for ALL markets, no auth needed
    // These supplement EDGAR (US) or serve as the only source (international)
    pe:         meta.trailingPE       ?? null,
    eps:        meta.regularMarketEPS ?? null,
    marketCap:  meta.marketCap        ?? null,
    high52w:    meta.fiftyTwoWeekHigh ?? null,
    low52w:     meta.fiftyTwoWeekLow  ?? null,
    shortName:  meta.shortName        ?? null,
    _fetchedAt: new Date().toISOString(),
  };
}

/** Fundamentals: EDGAR (US filers, multi-year depth) merged with Yahoo crumb
 *  quoteSummary (global coverage + short % of float). Runs both in parallel;
 *  EDGAR wins on overlapping fields, crumb fills the gaps — so international
 *  tickers (.AX/.TO/.T/.DE/…) now get real revGrowth/margins/FCF/D-E, and US
 *  tickers finally get shortPctFloat. Falls back to quote-meta basics if both fail. */
const { fetchFundamentalsEdgar } = require('./edgar');
const { fetchFundamentalsYahoo } = require('./yahoo-crumb');

async function fetchFundamentals(ticker, priceOrQuote = null) {
  const price = (priceOrQuote && typeof priceOrQuote === 'object') ? priceOrQuote.price : priceOrQuote;
  const quoteFields = (priceOrQuote && typeof priceOrQuote === 'object') ? priceOrQuote : null;
  const isUS = !ticker.includes('.');   // suffix ⇒ international ⇒ EDGAR won't have it

  const [edgarR, yahooR] = await Promise.allSettled([
    isUS ? fetchFundamentalsEdgar(ticker, price) : Promise.reject(new Error('non-US, skip EDGAR')),
    fetchFundamentalsYahoo(ticker),
  ]);
  const edgar = edgarR.status === 'fulfilled' ? edgarR.value : null;
  const yahoo = yahooR.status === 'fulfilled' ? yahooR.value : null;

  if (!edgar && !yahoo) {
    // Last resort: basic fields from the chart-meta quote
    if (quoteFields && (quoteFields.pe != null || quoteFields.marketCap != null)) {
      return {
        pe: quoteFields.pe ?? null, eps: quoteFields.eps ?? null, marketCap: quoteFields.marketCap ?? null,
        revGrowth: null, grossMargin: null, roic: null, fcfPerShare: null, fcfGrowth5y: null,
        freeCashflow: null, debtToEquity: null, currentRatio: null, shortPctFloat: null,
        _source: 'yahoo-quote', _asOf: quoteFields._fetchedAt,
      };
    }
    throw new Error(`no fundamentals for ${ticker} (edgar: ${edgarR.reason?.message?.slice(0,60)}; yahoo: ${yahooR.reason?.message?.slice(0,60)})`);
  }

  // Merge: EDGAR value wins when present (deeper, filing-sourced); crumb fills the rest.
  const pick = (k) => (edgar && edgar[k] != null) ? edgar[k] : (yahoo ? yahoo[k] ?? null : null);
  const merged = {
    pe: pick('pe'), eps: pick('eps'), marketCap: pick('marketCap'),
    revGrowth: pick('revGrowth'), grossMargin: pick('grossMargin'),
    roic: pick('roic'), roe: yahoo?.roe ?? null,
    debtToEquity: pick('debtToEquity'), currentRatio: pick('currentRatio'),
    freeCashflow: pick('freeCashflow'), fcfPerShare: pick('fcfPerShare'),
    fcfGrowth5y: pick('fcfGrowth5y'),
    shortPctFloat: yahoo?.shortPctFloat ?? edgar?.shortPctFloat ?? null, // crumb is the live source
    hasRevenue: yahoo?.hasRevenue ?? ((edgar && (edgar.revGrowth != null || edgar.grossMargin != null)) ? true : null),
    _source: edgar && yahoo ? 'edgar+yahoo' : edgar ? edgar._source : 'yahoo-crumb',
    _asOf: (edgar || yahoo)._asOf,
  };
  // Patch remaining holes from quote meta
  if (quoteFields) {
    if (merged.pe == null && quoteFields.pe != null) merged.pe = quoteFields.pe;
    if (merged.eps == null && quoteFields.eps != null) merged.eps = quoteFields.eps;
    if (merged.marketCap == null && quoteFields.marketCap != null) merged.marketCap = quoteFields.marketCap;
  }
  return merged;
}

/** Daily closes for ~N years. Returns { dates:[], closes:[] } oldest→newest. */
async function fetchHistory(ticker, years = 3) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=${years}y&interval=1d`;
  const r = await fetch(url, UA);
  if (!r.ok) throw new Error(`yahoo hist ${r.status}`);
  const j = await r.json();
  const res = j?.chart?.result?.[0];
  if (!res) throw new Error('no history');
  const ts = res.timestamp || [];
  const closes = res.indicators?.quote?.[0]?.close || [];
  const dates = [], px = [];
  for (let i = 0; i < ts.length; i++) if (closes[i] != null) { dates.push(ts[i] * 1000); px.push(closes[i]); }
  return { ticker, dates, closes: px };
}

module.exports = { fetchQuote, fetchFundamentals, fetchHistory };
