/**
 * longterm-claude.js — the QUALITATIVE long-term layer.
 *
 * The quantitative moat proxy (moat.js) tells you IF a durable advantage exists in
 * the numbers. This tells you WHY, HOW BIG the opportunity is, and WHO threatens it —
 * the parts that never appear in a filing's XBRL facts:
 *   • moat TYPE  — Morningstar's five sources (intangibles, switching costs,
 *                  network effect, cost advantage, efficient scale)
 *   • market gap — TAM, its growth, the company's penetration and runway
 *   • competition — Porter-style rivalry, entrants, supplier/buyer power, substitutes
 *
 * Uses Claude with web search server-side (key stays on the Beelink). Output is
 * structured, confidence-rated, and CACHED (default 30 days) — this is a slow-moving
 * layer, so it runs weekly, not on every screen. Honesty rule: if Claude can't
 * substantiate a field it returns null with a note; nothing is invented.
 */
const fs = require('fs');
const path = require('path');
const { askClaude } = require('./claude');

const CACHE_DIR = path.join(__dirname, '..', 'data', 'longterm');
const TTL_MS = 30 * 24 * 3600 * 1000;

const SYSTEM = `You are a long-horizon equity analyst. Assess a company's DURABLE competitive position, not short-term price action. Be sceptical and specific. If you cannot substantiate a claim, set the field to null and say so — never guess a number. Return ONLY valid JSON, no prose, no markdown fences.`;

function prompt(ticker, name, sector) {
  return `Company: ${name} (${ticker}) — ${sector}.
Assess its long-term investment quality. Return JSON exactly:
{
  "moatType": ["one or more of: intangibles, switching_costs, network_effect, cost_advantage, efficient_scale, none"],
  "moatRationale": "1-2 sentences on the primary durable advantage, or why none exists",
  "tam": { "sizeUsd": number|null, "cagrPct": number|null, "companyPenetrationPct": number|null, "runwayNote": "string" },
  "competition": { "intensity": "low|moderate|high", "position": "leader|challenger|niche|laggard", "keyRivals": ["..."], "threatNote": "string" },
  "structuralTailwinds": ["..."],
  "structuralRisks": ["..."],
  "longTermVerdict": "compounder|solid|speculative|avoid",
  "confidence": 0.0-1.0,
  "asOf": "YYYY-MM"
}`;
}

function cachePath(t) { return path.join(CACHE_DIR, `${t.toUpperCase()}.json`); }

/** Returns cached assessment if fresh; else null. */
function cached(ticker) {
  try {
    const p = cachePath(ticker), st = fs.statSync(p);
    if (Date.now() - st.mtimeMs < TTL_MS) return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch { /* miss */ }
  return null;
}

/**
 * @param force  bypass cache
 * @returns parsed assessment object (+ _cachedAt), or { error } — never throws into the screen loop.
 */
async function assessLongTerm(ticker, name, sector, { force = false } = {}) {
  if (!force) { const c = cached(ticker); if (c) return { ...c, _fromCache: true }; }
  try {
    const raw = await askClaude({
      system: SYSTEM,
      user: prompt(ticker, name || ticker, sector || 'unknown'),
      model: 'claude-sonnet-4-6',
      maxTokens: 1200,
    });
    const json = raw.trim().replace(/^```json\s*|\s*```$/g, '');
    const parsed = JSON.parse(json);
    parsed._cachedAt = new Date().toISOString();
    try { fs.mkdirSync(CACHE_DIR, { recursive: true }); fs.writeFileSync(cachePath(ticker), JSON.stringify(parsed)); } catch { /* ro fs */ }
    return parsed;
  } catch (e) {
    return { error: e.message, longTermVerdict: null, confidence: 0 };
  }
}

/** Blend the qualitative verdict with the quantitative moat score into one 0-100 long-term conviction. */
function longTermConviction(moat, qual) {
  if (!moat || moat.score == null) return { score: null, note: 'Insufficient data for long-term conviction.' };
  let s = moat.score;                                   // quantitative backbone
  const v = qual && qual.longTermVerdict;
  if (v === 'compounder') s += 8; else if (v === 'avoid') s -= 12; else if (v === 'speculative') s -= 4;
  if (qual && qual.competition && qual.competition.intensity === 'high') s -= 4;
  if (qual && Array.isArray(qual.structuralTailwinds) && qual.structuralTailwinds.length >= 2) s += 4;
  // trust the blend only as far as the qualitative confidence allows
  const conf = qual && typeof qual.confidence === 'number' ? qual.confidence : 0;
  const blended = Math.round(moat.score * (1 - 0.3 * conf) + s * (0.3 * conf));
  return { score: Math.max(0, Math.min(99, blended)), moatScore: moat.score, verdict: v || 'unknown', confidence: conf };
}

module.exports = { assessLongTerm, longTermConviction, cached };
