/**
 * buzz.js — real social buzz + direction from the StockTwits public API.
 * ───────────────────────────────────────────────────────────────────────────
 * Returns:
 *   activity       0-100 magnitude — a ROUGH proxy from recent message flow.
 *                  (StockTwits only exposes the latest ~30 messages unauthenticated,
 *                   so treat magnitude as directional-ish, not precise volume.)
 *   socialPolarity -1..+1 from the bullish/bearish tags investors attach to posts.
 *                  Only returned when enough tagged posts exist to be meaningful.
 *   putCallRatio   null for now (Yahoo options needs the crumb handshake — like
 *                  fundamentals; deferred to a later pass).
 *
 * Design rule (matches sentiment-direction.js): magnitude is not direction, and
 * we NEVER fabricate. If StockTwits blocks/rate-limits the box, every field comes
 * back null and the app honestly shows "pending" — no change to prior behaviour.
 */
const https = require('https');

function getJSON(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; lucasint/1.0)', 'Accept': 'application/json' },
      timeout: 8000,
    }, res => {
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      let d = '';
      res.on('data', c => (d += c));
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch (e) { reject(new Error('parse: ' + e.message)); } });
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}

async function fetchBuzz(ticker) {
  const empty = { activity: null, socialPolarity: null, putCallRatio: null, source: null, msgCount: 0, bull: 0, bear: 0 };
  try {
    const j = await getJSON(`https://api.stocktwits.com/api/2/streams/symbol/${encodeURIComponent(ticker)}.json`);
    const msgs = Array.isArray(j.messages) ? j.messages : [];
    let bull = 0, bear = 0;
    for (const m of msgs) {
      const b = m && m.entities && m.entities.sentiment && m.entities.sentiment.basic;
      if (b === 'Bullish') bull++;
      else if (b === 'Bearish') bear++;
    }
    const msgCount = msgs.length;
    const tagged = bull + bear;
    // Rough magnitude: recent message flow + how many carried an explicit stance.
    const activity = msgCount ? Math.min(100, Math.round(msgCount * 2 + tagged * 2)) : 0;
    // Direction only when enough tagged posts to be meaningful (else null → stays "unknown").
    const socialPolarity = tagged >= 5 ? +(((bull - bear) / tagged).toFixed(2)) : null;
    return { activity, socialPolarity, putCallRatio: null, source: 'stocktwits', msgCount, bull, bear };
  } catch (e) {
    return { ...empty, error: e.message };
  }
}

module.exports = { fetchBuzz };
