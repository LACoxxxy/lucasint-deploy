/**
 * govt-contracts.js — Federal contract-award signal (demand visibility / govt tailwind).
 *
 * Source: USASpending.gov API (free, no key). Sums federal award obligations to a
 * recipient over the trailing window and flags material DoD/agency exposure — highly
 * relevant for the rare-earth, quantum and defense-adjacent names in the universe.
 * Absent data → null (pending), never fabricated.
 */
const UA = { headers: { 'User-Agent': 'LucasINT research lucas@geojob.com', 'Content-Type': 'application/json' } };
const US_URL = 'https://api.usaspending.gov/api/v2/search/spending_by_award/';

async function fetchGovtContracts(recipientName, months = 12) {
  try {
    const start = new Date(Date.now() - months * 30 * 864e5).toISOString().slice(0, 10);
    const end = new Date().toISOString().slice(0, 10);
    const body = {
      filters: {
        award_type_codes: ['A', 'B', 'C', 'D'],                       // contract award types
        recipient_search_text: [recipientName],
        time_period: [{ start_date: start, end_date: end }],
      },
      fields: ['Award Amount', 'Awarding Agency', 'Award Type'],
      limit: 100, page: 1,
    };
    const r = await fetch(US_URL, { method: 'POST', headers: UA.headers, body: JSON.stringify(body) });
    if (!r.ok) throw new Error(`usaspending ${r.status}`);
    const data = await r.json();
    return { ...summarize(data.results || []), recipient: recipientName, _source: 'usaspending' };
  } catch (e) { return { totalObligated: null, error: e.message }; }
}

/** Transform awards → total obligated, count, and whether DoD is a funder. */
function summarize(results) {
  let total = 0; const agencies = new Set();
  for (const a of results) {
    total += Number(a['Award Amount'] || 0);
    if (a['Awarding Agency']) agencies.add(a['Awarding Agency']);
  }
  const dod = [...agencies].some(x => /defense|army|navy|air force|darpa/i.test(x));
  return { totalObligated: Math.round(total), awardCount: results.length, agencies: [...agencies], dod, hasContracts: results.length > 0 };
}

function govtScore(g) {
  if (!g || g.totalObligated == null) return { pts: 0, note: null };
  if (g.dod && g.totalObligated > 1e7) return { pts: 5, note: `DoD-funded, $${(g.totalObligated/1e6).toFixed(0)}M awards` };
  if (g.hasContracts && g.totalObligated > 1e6) return { pts: 3, note: `Federal contracts $${(g.totalObligated/1e6).toFixed(0)}M` };
  return { pts: 0, note: null };
}

module.exports = { fetchGovtContracts, summarize, govtScore };
