/**
 * patents.js — Patent-activity signal (innovation / R&D moat leading indicator).
 *
 * Source: USPTO PatentsView API (free, no key). Counts granted patents per assignee
 * per year and flags a recent SURGE (YoY acceleration) — a leading indicator of R&D
 * investment paying out, especially relevant for the semi/quantum/materials universe.
 * Absent data → null (pending), never fabricated.
 */
const UA = { headers: { 'User-Agent': 'LucasINT research lucas@geojob.com', 'Content-Type': 'application/json' } };
const PV_URL = 'https://search.patentsview.org/api/v1/patent/';

/** Count granted patents by grant year for an assignee organization name. */
async function fetchPatentActivity(assigneeName, years = 4) {
  try {
    const since = `${new Date().getFullYear() - years}-01-01`;
    const q = {
      q: { _and: [ { _gte: { patent_date: since } }, { _text_phrase: { "assignees.assignee_organization": assigneeName } } ] },
      f: ['patent_id', 'patent_date'],
      o: { size: 1000 },
    };
    const r = await fetch(PV_URL, { method: 'POST', headers: UA.headers, body: JSON.stringify(q) });
    if (!r.ok) throw new Error(`patentsview ${r.status}`);
    const data = await r.json();
    const pats = data.patents || [];
    return { ...summarize(pats), assignee: assigneeName, _source: 'patentsview' };
  } catch (e) { return { patentSurge: null, error: e.message }; }
}

/** Transform raw patent list → counts by year + surge flag. */
function summarize(pats) {
  const byYear = {};
  for (const p of pats) { const y = (p.patent_date || '').slice(0, 4); if (y) byYear[y] = (byYear[y] || 0) + 1; }
  const yrs = Object.keys(byYear).sort();               // ascending
  const counts = yrs.map(y => byYear[y]);
  const total = counts.reduce((a, b) => a + b, 0);
  let patentSurge = null, yoy = null;
  if (counts.length >= 2) {
    const last = counts[counts.length - 1], prev = counts[counts.length - 2];
    yoy = prev ? +(((last - prev) / prev) * 100).toFixed(0) : null;
    patentSurge = yoy != null && yoy >= 25;             // ≥25% YoY acceleration = surge
  }
  return { total, byYear, yoyPct: yoy, patentSurge };
}

function patentScore(p) {
  if (!p || p.patentSurge == null) return { pts: 0, note: null };
  if (p.patentSurge) return { pts: 4, note: `Patent surge +${p.yoyPct}% YoY (${p.total} recent grants)` };
  return { pts: 0, note: null };
}

module.exports = { fetchPatentActivity, summarize, patentScore };
