/**
 * edgar.js — Fundamentals from SEC EDGAR companyfacts (XBRL).
 * Replaces Yahoo quoteSummary (v10), which now requires crumb/cookie auth and
 * returns nulls. EDGAR is official, free, no auth — just a descriptive User-Agent.
 *
 * Returns the SAME shape fetchFundamentals used to return, PLUS the fields the
 * DCF/ROIC/allocation pipeline was missing (fcfPerShare, fcfGrowth5y, roic, eps).
 *
 * Honesty rule preserved: any figure we cannot derive from filings is returned
 * as null (→ shows as "pending" downstream). Nothing is fabricated.
 *   - shortPctFloat: NOT in EDGAR (FINRA/exchange data) → always null here.
 */
const fs = require('fs');
const path = require('path');

const SEC_UA = { headers: { 'User-Agent': 'LucasINT/1.0 (contact: lucas@geojob.com)', 'Accept-Encoding': 'gzip, deflate' } };
const CIK_CACHE = path.join(__dirname, '..', 'data', 'cik-map.json');
const CIK_TTL_MS = 30 * 24 * 3600 * 1000; // refresh monthly

// In-process memory cache so a single screen run only reads disk once
let _memMap = null;
let _memMapLoadedAt = 0;

async function getJson(url, timeoutMs = 30000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { ...SEC_UA, signal: ctrl.signal });
    const text = await r.text();
    if (!r.ok) throw new Error(`edgar ${r.status} ${url.split('/').slice(-1)[0]} :: ${text.slice(0, 120)}`);
    try { return JSON.parse(text); }
    catch { throw new Error(`edgar non-JSON ${url.split('/').slice(-1)[0]} :: ${text.slice(0, 120)}`); }
  } catch (e) {
    if (e.name === 'AbortError') throw new Error(`edgar timeout ${url.split('/').slice(-1)[0]}`);
    throw e;
  } finally { clearTimeout(timer); }
}

function loadMapFromDisk() {
  try {
    // Use in-memory cache within process (avoids disk reads per-ticker in screen run)
    if (_memMap && (Date.now() - _memMapLoadedAt) < 10 * 60 * 1000) return _memMap;
    const st = fs.statSync(CIK_CACHE);
    const raw = JSON.parse(fs.readFileSync(CIK_CACHE, 'utf8'));
    _memMap = raw; _memMapLoadedAt = Date.now();
    return raw;
  } catch { return null; }
}

function saveMapToDisk(map) {
  try {
    fs.writeFileSync(CIK_CACHE, JSON.stringify(map));
    _memMap = map; _memMapLoadedAt = Date.now();
  } catch { /* read-only fs */ }
}

async function fetchFullCikMap(retries = 2) {
  for (let i = 0; i <= retries; i++) {
    try {
      const raw = await getJson('https://www.sec.gov/files/company_tickers.json', 45000);
      const map = {};
      for (const k of Object.keys(raw)) {
        const e = raw[k];
        if (e && e.ticker) map[String(e.ticker).toUpperCase()] = String(e.cik_str).padStart(10, '0');
      }
      if (Object.keys(map).length > 1000) return map;
      throw new Error(`CIK map only ${Object.keys(map).length} entries`);
    } catch(e) {
      if (i < retries) { await new Promise(r => setTimeout(r, 3000 * (i + 1))); continue; }
      throw e;
    }
  }
}

/** ticker → 10-digit CIK. Checks in-memory cache first, then disk, then SEC API. */
async function cikFor(ticker) {
  const key = ticker.toUpperCase();

  // 1. Check in-memory/disk cache — if ticker is there, return immediately (even if map is small)
  const existing = loadMapFromDisk();
  if (existing && existing[key]) return existing[key];

  // 2. Cache is missing OR ticker not found. Fetch full map from SEC (with retry).
  console.log(`  [edgar] CIK cache miss for ${key} — fetching full company_tickers.json`);
  const fullMap = await fetchFullCikMap();

  // 3. Merge with existing curated entries (don't clobber manually-added CIKs)
  const merged = { ...(existing || {}), ...fullMap };
  saveMapToDisk(merged);

  if (!merged[key]) throw new Error(`no CIK for ${ticker} (non-US filer or not in SEC database)`);
  return merged[key];
}

/**
 * Pull annual (FY) datapoints for a us-gaap/dei concept, newest→oldest.
 * Tries multiple tag names (companies label the same idea differently).
 * Supports both 10-K (US domestic) and 20-F (foreign private issuers like ARM, QBTS).
 * Returns [{ end, val, fy }] sorted newest-first, or [] if none found.
 */
function annualSeries(facts, tags, taxonomies = ['us-gaap', 'dei', 'ifrs-full']) {
  for (const tax of taxonomies) {
    const grp = facts.facts?.[tax];
    if (!grp) continue;
    for (const tag of tags) {
      const units = grp[tag]?.units;
      if (!units) continue;
      const unitKey = Object.keys(units)[0];
      const pts = units[unitKey]
        .filter(p => (p.form === '10-K' || p.form === '20-F') && p.fp === 'FY' && p.val != null)
        .map(p => ({ end: p.end, val: p.val, fy: p.fy }));
      if (pts.length) {
        const byEnd = {};
        for (const p of pts) byEnd[p.end] = p;
        return Object.values(byEnd).sort((a, b) => (a.end < b.end ? 1 : -1));
      }
    }
  }
  return [];
}

const latest = s => (s.length ? s[0].val : null);
const prior  = s => (s.length > 1 ? s[1].val : null);

/**
 * @param ticker
 * @param price  latest price (from Yahoo chart fetchQuote) — needed for PE & marketCap.
 */
async function fetchFundamentalsEdgar(ticker, price = null) {
  const cik = await cikFor(ticker);
  const facts = await getJson(`https://data.sec.gov/api/xbrl/companyfacts/CIK${cik}.json`);

  // ── raw series ──
  const revS   = annualSeries(facts, ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues', 'SalesRevenueNet', 'RevenueFromContractWithCustomerIncludingAssessedTax']);
  const grossS = annualSeries(facts, ['GrossProfit']);
  const cogsS  = annualSeries(facts, ['CostOfGoodsAndServicesSold', 'CostOfRevenue', 'CostOfGoodsSold']);
  const opInc  = annualSeries(facts, ['OperatingIncomeLoss']);
  const preTax = annualSeries(facts, ['IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest', 'IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments']);
  const taxS   = annualSeries(facts, ['IncomeTaxExpenseBenefit']);
  const equityS= annualSeries(facts, ['StockholdersEquity', 'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest']);
  const curAst = annualSeries(facts, ['AssetsCurrent']);
  const curLia = annualSeries(facts, ['LiabilitiesCurrent']);
  const cashS  = annualSeries(facts, ['CashAndCashEquivalentsAtCarryingValue', 'CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents']);
  const ltDebt = annualSeries(facts, ['LongTermDebtNoncurrent', 'LongTermDebt']);
  const stDebt = annualSeries(facts, ['LongTermDebtCurrent', 'DebtCurrent']);
  const epsS   = annualSeries(facts, ['EarningsPerShareDiluted', 'EarningsPerShareBasic']);
  const niS    = annualSeries(facts, ['NetIncomeLoss']);
  const cfoS   = annualSeries(facts, ['NetCashProvidedByUsedInOperatingActivities', 'NetCashProvidedByUsedInOperatingActivitiesContinuingOperations']);
  const capexS = annualSeries(facts, ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets']);
  const shrDei = annualSeries(facts, ['EntityCommonStockSharesOutstanding'], ['dei']);
  const shrWtd = annualSeries(facts, ['WeightedAverageNumberOfDilutedSharesOutstanding', 'WeightedAverageNumberOfSharesOutstandingBasic']);

  const n = (x, d = 1) => (x == null ? null : +x.toFixed(d));

  // ── shares ──
  const shares = latest(shrDei) ?? latest(shrWtd);

  // ── revenue growth ──
  const rev = latest(revS), revPrev = prior(revS);
  const revGrowth = (rev != null && revPrev) ? n(((rev - revPrev) / Math.abs(revPrev)) * 100) : null;

  // ── gross margin (GrossProfit if present, else revenue - COGS) ──
  let gross = latest(grossS);
  if (gross == null && rev != null && latest(cogsS) != null) gross = rev - latest(cogsS);
  const grossMargin = (gross != null && rev) ? n((gross / rev) * 100) : null;

  // ── free cash flow + per share ──
  const cfo = latest(cfoS), capex = latest(capexS);
  const fcf = (cfo != null) ? (cfo - (capex ?? 0)) : null;   // capex tag is positive outflow
  const fcfPerShare = (fcf != null && shares) ? n(fcf / shares, 2) : null;

  // ── fcf 5y CAGR (needs ≥2 positive-ish annual points) ──
  let fcfGrowth5y = null;
  if (cfoS.length >= 2) {
    const capexByEnd = {}; for (const c of capexS) capexByEnd[c.end] = c.val;
    const pts = cfoS.slice(0, 6).map(c => ({ end: c.end, fcf: c.val - (capexByEnd[c.end] ?? 0) })); // newest→oldest
    const newest = pts[0], oldest = pts[pts.length - 1];
    const yrs = (new Date(newest.end) - new Date(oldest.end)) / (365.25 * 864e5);
    if (newest.fcf > 0 && oldest.fcf > 0 && yrs >= 0.9) fcfGrowth5y = n((Math.pow(newest.fcf / oldest.fcf, 1 / yrs) - 1) * 100);
  }

  // ── EPS → PE ──
  let eps = latest(epsS);
  if (eps == null && latest(niS) != null && shares) eps = latest(niS) / shares;
  const pe = (price != null && eps && eps > 0) ? n(price / eps, 1) : null;

  // ── debt / equity ──
  const equity = latest(equityS);
  const totalDebt = (latest(ltDebt) ?? 0) + (latest(stDebt) ?? 0);
  const haveDebt = latest(ltDebt) != null || latest(stDebt) != null;
  const debtToEquity = (haveDebt && equity && equity > 0) ? n(totalDebt / equity, 2) : null;

  // ── current ratio ──
  const currentRatio = (latest(curAst) != null && latest(curLia)) ? n(latest(curAst) / latest(curLia), 2) : null;

  // ── ROIC = NOPAT / invested capital ──
  let roic = null;
  const oi = latest(opInc);
  if (oi != null && equity) {
    const pt = latest(preTax), tx = latest(taxS);
    let taxRate = (pt && pt !== 0 && tx != null) ? tx / pt : 0.21;
    taxRate = Math.min(0.35, Math.max(0, taxRate));
    const nopat = oi * (1 - taxRate);
    const invested = equity + totalDebt - (latest(cashS) ?? 0);
    if (invested > 0) roic = n((nopat / invested) * 100);
  }

  const marketCap = (price != null && shares) ? Math.round(price * shares) : null;

  // ── multi-year series for moat detection (year-indexed, newest→oldest) ──
  const byEnd = (s) => { const m = {}; for (const p of s) m[p.end] = p.val; return m; };
  const eqE = byEnd(equityS), dLtE = byEnd(ltDebt), dStE = byEnd(stDebt), cashE = byEnd(cashS),
        oiE = byEnd(opInc), ptE = byEnd(preTax), txE = byEnd(taxS),
        revE = byEnd(revS), grE = byEnd(grossS), cogsE = byEnd(cogsS),
        cfoE = byEnd(cfoS), capexE = byEnd(capexS);
  const roicHist = [], gmHist = [], fcfHist = [], revHist = [];
  for (const p of equityS.slice(0, 6)) {           // up to 6 fiscal years
    const end = p.end, eq = eqE[end];
    const dbt = (dLtE[end] ?? 0) + (dStE[end] ?? 0);
    if (oiE[end] != null && eq) {
      let tr = (ptE[end] && ptE[end] !== 0 && txE[end] != null) ? txE[end] / ptE[end] : 0.21;
      tr = Math.min(0.35, Math.max(0, tr));
      const inv = eq + dbt - (cashE[end] ?? 0);
      if (inv > 0) roicHist.push({ end, val: n((oiE[end] * (1 - tr) / inv) * 100) });
    }
  }
  for (const p of revS.slice(0, 6)) {
    const end = p.end, rev0 = p.val;
    let g = grE[end]; if (g == null && cogsE[end] != null) g = rev0 - cogsE[end];
    if (g != null && rev0) gmHist.push({ end, val: n((g / rev0) * 100) });
    revHist.push({ end, val: rev0 });
  }
  for (const p of cfoS.slice(0, 6)) fcfHist.push({ end: p.end, val: p.val - (capexE[p.end] ?? 0) });

  return {
    ticker,
    pe,
    eps: eps != null ? n(eps, 2) : null,
    revGrowth,
    grossMargin,
    debtToEquity,
    currentRatio,
    freeCashflow: fcf != null ? Math.round(fcf) : null,
    fcfPerShare,
    fcfGrowth5y,
    roic,
    roicHist, gmHist, fcfHist, revHist,   // multi-year — feeds moat detection
    sharesOutstanding: shares ?? null,
    shortPctFloat: null,   // EDGAR has no short interest — honest pending (FINRA feed later)
    marketCap,
    _source: 'edgar',
    _asOf: latest(revS) != null ? revS[0].end : null,
  };
}

module.exports = { fetchFundamentalsEdgar, cikFor, annualSeries };
