/**
 * short-interest.js — Short % of float + days-to-cover (the CONTRARIAN factor).
 *
 * Source: FINRA consolidated short interest (published twice monthly, free). EDGAR
 * does not carry this. High short interest is a contrarian tailwind for names with a
 * real thesis (short-squeeze fuel); it's a risk flag when the thesis is weak.
 *
 * FINRA's data platform endpoint returns records per symbol; map to the fields the
 * scoring model already expects (shortPctFloat). On first run against the live feed,
 * confirm the endpoint shape — the transform below is validated against the documented
 * record schema. Absent data → null (pending), never fabricated.
 */
const UA = { headers: { 'User-Agent': 'LucasINT research lucas@geojob.com', 'Accept': 'application/json' } };
const FINRA_URL = 'https://api.finra.org/data/group/otcMarket/name/consolidatedShortInterest';

/** Map a FINRA short-interest record → our normalized shape. */
function normalize(rec, floatShares = null) {
  const si = Number(rec.currentShortPositionQuantity ?? rec.shortInterest ?? null);
  const avgVol = Number(rec.averageDailyVolumeQuantity ?? rec.avgDailyVolume ?? null);
  const settlement = rec.settlementDate ?? rec.settlement_date ?? null;
  const daysToCover = (si && avgVol) ? +(si / avgVol).toFixed(1) : null;
  const shortPctFloat = (si && floatShares) ? +((si / floatShares) * 100).toFixed(1) : null;
  return { shortInterest: si || null, daysToCover, shortPctFloat, settlementDate: settlement };
}

/**
 * @param ticker
 * @param floatShares  shares outstanding from EDGAR (used to derive % of float)
 */
async function fetchShortInterest(ticker, floatShares = null) {
  try {
    const body = { limit: 1, compareFilters: [{ compareType: 'EQUAL', fieldName: 'symbolCode', fieldValue: ticker.toUpperCase() }],
      sortFields: ['-settlementDate'] };
    const r = await fetch(FINRA_URL, { method: 'POST', headers: { ...UA.headers, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!r.ok) throw new Error(`finra ${r.status}`);
    const rows = await r.json();
    const rec = Array.isArray(rows) ? rows[0] : (rows.data || [])[0];
    if (!rec) return { shortPctFloat: null, note: 'No short-interest record.' };
    return { ...normalize(rec, floatShares), _source: 'finra' };
  } catch (e) { return { shortPctFloat: null, error: e.message }; }
}

/** Contrarian scoring: high short % with a real thesis is fuel; scoring model already
 *  adds +4 at ≥15%. Here we also surface days-to-cover for the squeeze read. */
function shortSignal(s) {
  if (!s || s.shortPctFloat == null) return { flag: null };
  if (s.shortPctFloat >= 20) return { flag: 'high_short_squeeze_fuel', note: `${s.shortPctFloat}% short, ${s.daysToCover ?? '?'}d to cover` };
  if (s.shortPctFloat >= 10) return { flag: 'elevated_short', note: `${s.shortPctFloat}% short` };
  return { flag: 'normal' };
}

module.exports = { fetchShortInterest, shortSignal, normalize };
