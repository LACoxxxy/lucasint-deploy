/** Verifies each configured key/source actually works. Run: npm run test-keys */
require('dotenv').config();
const { askClaude } = require('./claude');

(async () => {
  console.log('\nLucasINT — connectivity check\n' + '─'.repeat(40));

  // 1. Claude
  process.stdout.write('Claude API … ');
  try {
    if (!process.env.ANTHROPIC_API_KEY) throw new Error('no key set');
    const t = await askClaude({ system: 'Reply with exactly: OK', user: 'test', maxTokens: 10 });
    console.log(t.includes('OK') ? '✓ connected' : `⚠ unexpected reply: ${t}`);
  } catch (e) { console.log(`✗ ${e.message}`); }

  // 2. Yahoo Finance (no key) — sanity fetch
  process.stdout.write('Yahoo Finance … ');
  try {
    const r = await fetch('https://query1.finance.yahoo.com/v8/finance/chart/AAPL?interval=1d&range=1d', { headers: { 'User-Agent': 'Mozilla/5.0' } });
    console.log(r.ok ? '✓ reachable' : `⚠ status ${r.status}`);
  } catch (e) { console.log(`✗ ${e.message}`); }

  // 3. SEC EDGAR (needs User-Agent)
  process.stdout.write('SEC EDGAR … ');
  try {
    const r = await fetch('https://data.sec.gov/submissions/CIK0000320193.json', { headers: { 'User-Agent': process.env.SEC_USER_AGENT || 'LucasINT test' } });
    console.log(r.ok ? '✓ reachable' : `⚠ status ${r.status} (check SEC_USER_AGENT)`);
  } catch (e) { console.log(`✗ ${e.message}`); }

  // 4. Telegram
  process.stdout.write('Telegram bot … ');
  try {
    if (!process.env.TELEGRAM_BOT_TOKEN) throw new Error('no token set (set up in Telegram chat first)');
    const r = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/getMe`);
    const d = await r.json();
    console.log(d.ok ? `✓ @${d.result.username}` : `✗ ${d.description}`);
  } catch (e) { console.log(`✗ ${e.message}`); }

  console.log('─'.repeat(40));
  console.log('Fill any ✗/⚠ in .env, then re-run. Yahoo + Claude are the minimum to start.\n');
})();
