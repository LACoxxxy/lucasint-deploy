/**
 * yahoo-crumb.js — Yahoo Finance quoteSummary v10 with the crumb/cookie handshake.
 *
 * Yahoo locked quoteSummary behind an auth dance:
 *   1. GET https://fc.yahoo.com          → returns 404 BUT sets the A3 cookie
 *   2. GET /v1/test/getcrumb (w/ cookie) → returns a short crumb token
 *   3. All v10 quoteSummary calls need BOTH: Cookie header + &crumb= param
 *
 * The session (cookie+crumb) is cached in-process for 30 min and refreshed
 * automatically on 401/403. This restores GLOBAL fundamentals — revenue growth,
 * margins, FCF, debt/equity, short % of float — for every Yahoo-tracked market
 * (.AX, .TO, .T, .DE, .L, .KS, .TW …), which EDGAR cannot provide.
 *
 * Honesty rule preserved: anything Yahoo doesn't report comes back null.
 */

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

let _session = null; // { cookie, crumb, at }

function extractCookies(setCookieHeader) {
  if (!setCookieHeader) return '';
  // Node's fetch folds multiple Set-Cookie headers into one comma-joined string.
  // Split carefully (cookie values can contain commas in Expires=) — take name=value before first ';'.
  return setCookieHeader
    .split(/,(?=\s*\w+=)/)            // split only where a new cookie starts
    .map(c => c.split(';')[0].trim())
    .filter(Boolean)
    .join('; ');
}

async function fetchSession(force = false) {
  if (!force && _session && (Date.now() - _session.at) < 30 * 60 * 1000) return _session;

  // 1. Cookie — fc.yahoo.com 404s but sets A3
  let cookie = '';
  try {
    const r1 = await fetch('https://fc.yahoo.com', { headers: { 'User-Agent': UA }, redirect: 'manual' });
    cookie = extractCookies(r1.headers.get('set-cookie'));
  } catch { /* fall through */ }

  // Fallback: finance.yahoo.com home page also sets cookies
  if (!cookie) {
    const r2 = await fetch('https://finance.yahoo.com', { headers: { 'User-Agent': UA } });
    cookie = extractCookies(r2.headers.get('set-cookie'));
  }
  if (!cookie) throw new Error('yahoo-crumb: could not obtain session cookie');

  // 2. Crumb
  const r3 = await fetch('https://query2.finance.yahoo.com/v1/test/getcrumb', {
    headers: { 'User-Agent': UA, 'Cookie': cookie },
  });
  const crumb = (await r3.text()).trim();
  if (!r3.ok || !crumb || crumb.length > 30 || crumb.includes('<')) {
    throw new Error(`yahoo-crumb: crumb fetch failed (${r3.status}: ${crumb.slice(0, 60)})`);
  }

  _session = { cookie, crumb, at: Date.now() };
  console.log('[yahoo-crumb] session established');
  return _session;
}

/** Raw quoteSummary call with auto session refresh on auth failure. */
async function quoteSummary(ticker, modules) {
  let s = await fetchSession();
  const mk = sess => `https://query2.finance.yahoo.com/v10/finance/quoteSummary/${encodeURIComponent(ticker)}?modules=${modules.join('%2C')}&crumb=${encodeURIComponent(sess.crumb)}`;

  let r = await fetch(mk(s), { headers: { 'User-Agent': UA, 'Cookie': s.cookie } });
  if (r.status === 401 || r.status === 403) {           // stale session → one retry with fresh crumb
    s = await fetchSession(true);
    r = await fetch(mk(s), { headers: { 'User-Agent': UA, 'Cookie': s.cookie } });
  }
  if (r.status === 429) {                                // rate-limited → backoff and retry twice
    for (const wait of [2500, 6000]) {
      await new Promise(res => setTimeout(res, wait));
      r = await fetch(mk(s), { headers: { 'User-Agent': UA, 'Cookie': s.cookie } });
      if (r.status !== 429) break;
    }
  }
  if (!r.ok) throw new Error(`yahoo-crumb: quoteSummary ${r.status} for ${ticker}`);
  const j = await r.json();
  const res = j?.quoteSummary?.result?.[0];
  if (!res) throw new Error(`yahoo-crumb: empty result for ${ticker}`);
  return res;
}

const raw = v => (v && typeof v === 'object' ? v.raw : v) ?? null;
const pct = v => { const x = raw(v); return x == null ? null : +(x * 100).toFixed(1); };

/**
 * Full fundamentals for ANY Yahoo-tracked ticker (global).
 * Requests the raw statements too, so when financialData is sparse (common for
 * ASX/small-caps) we DERIVE the metrics from income statement + balance sheet.
 */
async function fetchFundamentalsYahoo(ticker) {
  const res = await quoteSummary(ticker, ['financialData', 'defaultKeyStatistics', 'summaryDetail', 'incomeStatementHistory', 'balanceSheetHistory']);
  const fd = res.financialData || {};
  const ks = res.defaultKeyStatistics || {};
  const sd = res.summaryDetail || {};
  const inc = res.incomeStatementHistory?.incomeStatementHistory || [];
  const bal = res.balanceSheetHistory?.balanceSheetStatements || [];

  const freeCashflow = raw(fd.freeCashflow);
  const shares = raw(ks.sharesOutstanding);
  const fcfPerShare = (freeCashflow != null && shares) ? +(freeCashflow / shares).toFixed(2) : null;

  // revGrowth: financialData first; else derive YoY from the income statements
  let revGrowth = pct(fd.revenueGrowth);
  if (revGrowth == null && inc.length >= 2) {
    const r0 = raw(inc[0]?.totalRevenue), r1 = raw(inc[1]?.totalRevenue);
    if (r0 != null && r1) revGrowth = +(((r0 - r1) / Math.abs(r1)) * 100).toFixed(1);
  }
  // grossMargin: financialData first; else grossProfit / totalRevenue
  let grossMargin = pct(fd.grossMargins);
  if ((grossMargin == null || grossMargin === 0) && inc.length) {
    const gp = raw(inc[0]?.grossProfit), tr = raw(inc[0]?.totalRevenue);
    if (gp != null && tr) grossMargin = +((gp / tr) * 100).toFixed(1);
  }
  // debtToEquity: financialData (given as %) first; else totalLiab / equity
  let debtToEquity = raw(fd.debtToEquity) != null ? +(raw(fd.debtToEquity) / 100).toFixed(2) : null;
  if (debtToEquity == null && bal.length) {
    const tl = raw(bal[0]?.totalLiab), eq = raw(bal[0]?.totalStockholderEquity);
    if (tl != null && eq) debtToEquity = +(tl / eq).toFixed(2);
  }
  // currentRatio: financialData first; else currentAssets / currentLiabilities
  let currentRatio = raw(fd.currentRatio);
  if (currentRatio == null && bal.length) {
    const ca = raw(bal[0]?.totalCurrentAssets), cl = raw(bal[0]?.totalCurrentLiabilities);
    if (ca != null && cl) currentRatio = +(ca / cl).toFixed(2);
  }

  return {
    pe:            raw(sd.trailingPE) ?? raw(ks.forwardPE) ?? null,
    eps:           raw(ks.trailingEps) ?? null,
    marketCap:     raw(sd.marketCap) ?? null,
    revGrowth,
    grossMargin,
    roic:          null,                          // not derivable from quoteSummary — honest null
    roe:           pct(fd.returnOnEquity),        // extra context field
    debtToEquity,
    currentRatio,
    freeCashflow,
    fcfPerShare,
    fcfGrowth5y:   null,                          // needs multi-year history — EDGAR only
    shortPctFloat: pct(ks.shortPercentOfFloat),   // ← finally! also works for US names
    _source: 'yahoo-crumb',
    _asOf: new Date().toISOString(),
  };
}

module.exports = { fetchFundamentalsYahoo, quoteSummary, fetchSession };
