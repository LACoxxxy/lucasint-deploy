/**
 * yahoo-crumb.js — Yahoo Finance quoteSummary v10 with the crumb/cookie handshake.
 *
 * Yahoo locked quoteSummary behind an auth dance:
 *   1. GET https://fc.yahoo.com          → returns 404 BUT sets the A3 cookie
 *   2. GET /v1/test/getcrumb (w/ cookie) → returns a short crumb token
 *   3. All v10 quoteSummary calls need BOTH: Cookie header + &crumb= param
 *
 * The session (cookie+crumb) is cached in-process for 30 min and refreshed
 * automatically on 401/403. This restores GLOBAL fundamentals — revenue growth,
 * margins, FCF, debt/equity, short % of float — for every Yahoo-tracked market
 * (.AX, .TO, .T, .DE, .L, .KS, .TW …), which EDGAR cannot provide.
 *
 * Honesty rule preserved: anything Yahoo doesn't report comes back null.
 */

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

let _session = null; // { cookie, crumb, at }

function extractCookies(setCookieHeader) {
  if (!setCookieHeader) return '';
  // Node's fetch folds multiple Set-Cookie headers into one comma-joined string.
  // Split carefully (cookie values can contain commas in Expires=) — take name=value before first ';'.
  return setCookieHeader
    .split(/,(?=\s*\w+=)/)            // split only where a new cookie starts
    .map(c => c.split(';')[0].trim())
    .filter(Boolean)
    .join('; ');
}

async function fetchSession(force = false) {
  if (!force && _session && (Date.now() - _session.at) < 30 * 60 * 1000) return _session;

  // 1. Cookie — fc.yahoo.com 404s but sets A3
  let cookie = '';
  try {
    const r1 = await fetch('https://fc.yahoo.com', { headers: { 'User-Agent': UA }, redirect: 'manual' });
    cookie = extractCookies(r1.headers.get('set-cookie'));
  } catch { /* fall through */ }

  // Fallback: finance.yahoo.com home page also sets cookies
  if (!cookie) {
    const r2 = await fetch('https://finance.yahoo.com', { headers: { 'User-Agent': UA } });
    cookie = extractCookies(r2.headers.get('set-cookie'));
  }
  if (!cookie) throw new Error('yahoo-crumb: could not obtain session cookie');

  // 2. Crumb
  const r3 = await fetch('https://query2.finance.yahoo.com/v1/test/getcrumb', {
    headers: { 'User-Agent': UA, 'Cookie': cookie },
  });
  const crumb = (await r3.text()).trim();
  if (!r3.ok || !crumb || crumb.length > 30 || crumb.includes('<')) {
    throw new Error(`yahoo-crumb: crumb fetch failed (${r3.status}: ${crumb.slice(0, 60)})`);
  }

  _session = { cookie, crumb, at: Date.now() };
  console.log('[yahoo-crumb] session established');
  return _session;
}

/** Raw quoteSummary call with auto session refresh on auth failure. */
async function quoteSummary(ticker, modules) {
  let s = await fetchSession();
  const mk = sess => `https://query2.finance.yahoo.com/v10/finance/quoteSummary/${encodeURIComponent(ticker)}?modules=${modules.join('%2C')}&crumb=${encodeURIComponent(sess.crumb)}`;

  let r = await fetch(mk(s), { headers: { 'User-Agent': UA, 'Cookie': s.cookie } });
  if (r.status === 401 || r.status === 403) {           // stale session → one retry with fresh crumb
    s = await fetchSession(true);
    r = await fetch(mk(s), { headers: { 'User-Agent': UA, 'Cookie': s.cookie } });
  }
  if (!r.ok) throw new Error(`yahoo-crumb: quoteSummary ${r.status} for ${ticker}`);
  const j = await r.json();
  const res = j?.quoteSummary?.result?.[0];
  if (!res) throw new Error(`yahoo-crumb: empty result for ${ticker}`);
  return res;
}

const raw = v => (v && typeof v === 'object' ? v.raw : v) ?? null;
const pct = v => { const x = raw(v); return x == null ? null : +(x * 100).toFixed(1); };

/**
 * Full fundamentals for ANY Yahoo-tracked ticker (global).
 * Returns the same shape as fetchFundamentalsEdgar so the pipeline is agnostic.
 */
async function fetchFundamentalsYahoo(ticker) {
  const res = await quoteSummary(ticker, ['financialData', 'defaultKeyStatistics', 'summaryDetail']);
  const fd = res.financialData || {};
  const ks = res.defaultKeyStatistics || {};
  const sd = res.summaryDetail || {};

  const freeCashflow = raw(fd.freeCashflow);
  const shares = raw(ks.sharesOutstanding);
  const fcfPerShare = (freeCashflow != null && shares) ? +(freeCashflow / shares).toFixed(2) : null;

  return {
    pe:            raw(sd.trailingPE) ?? raw(ks.forwardPE) ?? null,
    eps:           raw(ks.trailingEps) ?? null,
    marketCap:     raw(sd.marketCap) ?? null,
    revGrowth:     pct(fd.revenueGrowth),         // % YoY
    grossMargin:   pct(fd.grossMargins),          // %
    roic:          null,                          // not derivable from quoteSummary — honest null
    roe:           pct(fd.returnOnEquity),        // extra context field
    debtToEquity:  raw(fd.debtToEquity) != null ? +(raw(fd.debtToEquity) / 100).toFixed(2) : null, // yahoo gives % → ratio
    currentRatio:  raw(fd.currentRatio) ?? null,
    freeCashflow,
    fcfPerShare,
    fcfGrowth5y:   null,                          // needs multi-year history — EDGAR only
    shortPctFloat: pct(ks.shortPercentOfFloat),   // ← finally! also works for US names
    _source: 'yahoo-crumb',
    _asOf: new Date().toISOString(),
  };
}

module.exports = { fetchFundamentalsYahoo, quoteSummary, fetchSession };
