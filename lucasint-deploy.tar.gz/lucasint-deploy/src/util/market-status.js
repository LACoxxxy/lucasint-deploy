/**
 * market-status.js
 * ───────────────────────────────────────────────────────────────────────────
 * Knows the trading hours of the major global exchanges, computes whether each
 * is OPEN or CLOSED right now, and the ETA to the next open (if closed) or to
 * close (if open). Timezone-aware, DST-aware via the JS Intl engine.
 *
 * IMPORTANT HONESTY:
 *  - Hours logic is exact (uses each exchange's local timezone + the system clock).
 *  - Public/exchange HOLIDAYS are NOT modelled here (would need a maintained
 *    holiday calendar per exchange). So a market may show "open" on a holiday.
 *    Holidays are flagged as a known limitation — wire a holiday feed later if needed.
 *  - Lunch breaks (Tokyo, HK, Taiwan, Korea have midday closes) ARE modelled.
 * ───────────────────────────────────────────────────────────────────────────
 */

// Each market: timezone (IANA), regular session(s) in local time, Yahoo suffix.
// sessions = array of [openHHMM, closeHHMM] to support lunch breaks.
const MARKETS = {
  US:      { name: 'US (NYSE/Nasdaq)', tz: 'America/New_York',   sessions: [['09:30','16:00']], days: [1,2,3,4,5], suffix: '',      currency: 'USD' },
  ASX:     { name: 'Australia (ASX)',  tz: 'Australia/Sydney',   sessions: [['10:00','16:00']], days: [1,2,3,4,5], suffix: '.AX',   currency: 'AUD' },
  LSE:     { name: 'London (LSE)',     tz: 'Europe/London',      sessions: [['08:00','16:30']], days: [1,2,3,4,5], suffix: '.L',    currency: 'GBP' },
  EURONEXT:{ name: 'Euronext (Paris)', tz: 'Europe/Paris',       sessions: [['09:00','17:30']], days: [1,2,3,4,5], suffix: '.PA',   currency: 'EUR' },
  XETRA:   { name: 'Frankfurt (Xetra)',tz: 'Europe/Berlin',      sessions: [['09:00','17:30']], days: [1,2,3,4,5], suffix: '.DE',   currency: 'EUR' },
  TSE:     { name: 'Tokyo (TSE)',      tz: 'Asia/Tokyo',         sessions: [['09:00','11:30'],['12:30','15:00']], days: [1,2,3,4,5], suffix: '.T', currency: 'JPY' },
  TWSE:    { name: 'Taiwan (TWSE)',    tz: 'Asia/Taipei',        sessions: [['09:00','13:30']], days: [1,2,3,4,5], suffix: '.TW',   currency: 'TWD' },
  KRX:     { name: 'Korea (KRX)',      tz: 'Asia/Seoul',         sessions: [['09:00','15:30']], days: [1,2,3,4,5], suffix: '.KS',   currency: 'KRW' },
  HKEX:    { name: 'Hong Kong (HKEX)', tz: 'Asia/Hong_Kong',     sessions: [['09:30','12:00'],['13:00','16:00']], days: [1,2,3,4,5], suffix: '.HK', currency: 'HKD' },
  SGX:     { name: 'Singapore (SGX)',  tz: 'Asia/Singapore',     sessions: [['09:00','17:00']], days: [1,2,3,4,5], suffix: '.SI',   currency: 'SGD' },
  TSX:     { name: 'Toronto (TSX)',    tz: 'America/Toronto',    sessions: [['09:30','16:00']], days: [1,2,3,4,5], suffix: '.TO',   currency: 'CAD' },
  NSE:     { name: 'India (NSE)',      tz: 'Asia/Kolkata',       sessions: [['09:15','15:30']], days: [1,2,3,4,5], suffix: '.NS',   currency: 'INR' },
};

// Get the current wall-clock time in a given IANA timezone as {dow, minutes}.
function nowInTz(tz, now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
  }).formatToParts(now);
  const wd = parts.find(p => p.type === 'weekday').value;
  const hh = parseInt(parts.find(p => p.type === 'hour').value, 10) % 24;
  const mm = parseInt(parts.find(p => p.type === 'minute').value, 10);
  const dowMap = { Sun:0, Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6 };
  return { dow: dowMap[wd], minutes: hh * 60 + mm };
}

const toMin = hhmm => { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; };
const fmtETA = mins => {
  if (mins == null) return null;
  const d = Math.floor(mins / 1440), h = Math.floor((mins % 1440) / 60), m = mins % 60;
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
};

/**
 * Status of one market right now.
 * Returns { code, name, open, phase, etaCloseMin, etaOpenMin, etaText, asOfNote }
 */
function marketStatus(code, now = new Date()) {
  const M = MARKETS[code];
  if (!M) return null;
  const { dow, minutes } = nowInTz(M.tz, now);
  const tradingDay = M.days.includes(dow);

  // Are we inside any session right now?
  let open = false, etaCloseMin = null, inLunch = false;
  if (tradingDay) {
    for (const [o, c] of M.sessions) {
      if (minutes >= toMin(o) && minutes < toMin(c)) { open = true; etaCloseMin = toMin(c) - minutes; break; }
    }
    // detect lunch gap (between two sessions)
    if (!open && M.sessions.length > 1) {
      const firstClose = toMin(M.sessions[0][1]), secondOpen = toMin(M.sessions[1][0]);
      if (minutes >= firstClose && minutes < secondOpen) inLunch = true;
    }
  }

  // Compute ETA to next open if closed. Walk forward minute-buckets across days.
  let etaOpenMin = null;
  if (!open) {
    // minutes until the next session open, scanning up to 8 days ahead
    const allOpensToday = M.sessions.map(s => toMin(s[0]));
    let found = null;
    for (let dayAhead = 0; dayAhead <= 8 && found == null; dayAhead++) {
      const checkDow = (dow + dayAhead) % 7;
      if (!M.days.includes(checkDow)) continue;
      for (const openMin of allOpensToday) {
        const absolute = dayAhead * 1440 + openMin;
        const nowAbsolute = (dayAhead === 0) ? minutes : minutes; // offset handled below
        const delta = absolute - minutes;
        if (delta > 0) { found = delta; break; }
      }
    }
    etaOpenMin = found;
  }

  const phase = open ? 'OPEN' : inLunch ? 'LUNCH BREAK' : tradingDay ? (minutes < toMin(M.sessions[0][0]) ? 'PRE-OPEN' : 'CLOSED') : 'WEEKEND';

  return {
    code, name: M.name, tz: M.tz, currency: M.currency, suffix: M.suffix,
    open, phase,
    etaCloseMin: open ? etaCloseMin : null,
    etaOpenMin: !open ? etaOpenMin : null,
    etaText: open
      ? `closes in ${fmtETA(etaCloseMin)}`
      : (etaOpenMin != null ? `opens in ${fmtETA(etaOpenMin)}` : 'next open unknown'),
    holidayCaveat: true, // hours don't account for public holidays
  };
}

// All markets at once (for a global status bar)
function allMarketStatus(now = new Date()) {
  return Object.keys(MARKETS).map(code => marketStatus(code, now));
}

// Infer which market a ticker belongs to from its Yahoo suffix (.AX, .L, etc).
// No suffix → assume US. Suffix → map to correct exchange clock.
function marketForTicker(ticker) {
  const t = ticker.toUpperCase();
  if (t.endsWith('.AX'))  return 'ASX';
  if (t.endsWith('.TO') || t.endsWith('.V') || t.endsWith('.TSX')) return 'TSX';
  if (t.endsWith('.L') || t.endsWith('.AIM')) return 'LSE';
  if (t.endsWith('.DE') || t.endsWith('.XETRA')) return 'XETRA';
  if (t.endsWith('.PA') || t.endsWith('.NX')) return 'EURONEXT';
  if (t.endsWith('.T'))  return 'TSE';
  if (t.endsWith('.HK')) return 'HKEX';
  if (t.endsWith('.SW')) return 'SIX';
  if (t.endsWith('.KS') || t.endsWith('.KQ')) return 'KRX';
  if (t.endsWith('.TW') || t.endsWith('.TWO')) return 'TWSE';
  return 'US';
}
}

// Given a ticker + its price timestamp, produce an honest data-freshness note.
function dataFreshness(ticker, priceFetchedAtMs, now = new Date()) {
  const code = marketForTicker(ticker);
  const st = marketStatus(code, now);
  const ageMin = priceFetchedAtMs ? Math.round((now - priceFetchedAtMs) / 60000) : null;
  let note;
  if (st.open) {
    note = ageMin != null && ageMin <= 20
      ? `${st.name} OPEN — price live (${ageMin}m old), ${st.etaText}`
      : `${st.name} OPEN — price ${ageMin}m old, may lag; ${st.etaText}`;
  } else {
    note = `${st.name} ${st.phase} — showing last close; fundamentals current, price not moving. ${st.etaText}.`;
  }
  return { market: code, marketName: st.name, open: st.open, phase: st.phase, etaText: st.etaText, priceAgeMin: ageMin, note, holidayCaveat: st.holidayCaveat };
}

module.exports = { MARKETS, marketStatus, allMarketStatus, marketForTicker, dataFreshness };
