const fs = require('fs');
const path = require('path');
const FILE = path.join(__dirname, '..', '..', 'data', 'store.json');
function loadStore() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); }
  catch { return {}; }
}
function saveStore(obj) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(obj, null, 2));
}
module.exports = { loadStore, saveStore };
