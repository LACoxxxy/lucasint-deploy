/**
 * LucasINT — main server
 * Serves the PWA, proxies Claude API (keeps key server-side), exposes
 * screening + portfolio endpoints, and schedules the screen loop + 6pm digest.
 */
require('dotenv').config();
const express = require('express');
const cron = require('node-cron');
const path = require('path');
const fs = require('fs');

const { runScreen } = require('./jobs/screen');
const { runDigest } = require('./jobs/digest');
const { askClaude } = require('./util/claude');
const { loadStore, saveStore } = require('./util/store');
const { allMarketStatus, dataFreshness } = require('./util/market-status');

const app = express();
app.use(express.json({ limit: '1mb' }));

// ── Serve the PWA ──────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── Health check ────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ ok: true, mode: process.env.TRADING_MODE || 'research', ts: new Date().toISOString() });
});

// ── Global market status (open/closed + ETA) ───────────────────────────────
app.get('/api/markets', (req, res) => {
  res.json({ ts: new Date().toISOString(), markets: allMarketStatus() });
});

// ── Latest screen results (cached; refreshed by the cron job) ────────────────
app.get('/api/screen', (req, res) => {
  const store = loadStore();
  res.json({ asOf: store.screenAsOf || null, results: store.screenResults || [] });
});

// ── On-demand AI deep analysis (key stays here, never in the browser) ────────
app.post('/api/analyse', async (req, res) => {
  try {
    const { system, user } = req.body;
    if (!system || !user) return res.status(400).json({ error: 'system and user required' });
    const text = await askClaude({ system, user, maxTokens: 1000 });
    res.json({ text });
  } catch (e) {
    console.error('analyse error:', e.message);
    res.status(500).json({ error: 'analysis failed', detail: e.message });
  }
});

// ── Manual portfolio (until broker API is wired) ─────────────────────────────
app.get('/api/validated', (req, res) => {
  const store = loadStore();
  res.json({ asOf: store.harnessAsOf || null, note: store.harnessNote || null, strategies: store.harnessResults || [] });
});

app.post('/api/harness-run', async (req, res) => {
  try { const { runHarnessJob } = require('./jobs/harness-run'); const r = await runHarnessJob(); res.json({ ok: true, strategies: r }); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.get('/api/portfolio', (req, res) => {
  const store = loadStore();
  res.json({ positions: store.portfolio || [] });
});
app.post('/api/portfolio', (req, res) => {
  const store = loadStore();
  store.portfolio = store.portfolio || [];
  store.portfolio.push({ ...req.body, addedAt: new Date().toISOString() });
  saveStore(store);
  res.json({ ok: true, positions: store.portfolio });
});

// ── Trigger a screen run manually ────────────────────────────────────────────
app.post('/api/screen/run', async (req, res) => {
  try { const r = await runScreen(); res.json({ ok: true, count: r.length }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`\n  LucasINT running → http://localhost:${PORT}`);
  console.log(`  Mode: ${process.env.TRADING_MODE || 'research'}`);
  console.log(`  PWA served from /public\n`);
});

// ── Scheduled jobs (server timezone — set TZ on the Beelink) ─────────────────
// Screen every weekday at market-relevant times. Adjust to your timezone.
cron.schedule('0 7,12,16 * * 1-5', () => {
  console.log('[cron] running scheduled screen…');
  runScreen().catch(e => console.error('[cron] screen failed:', e.message));
});
// 6pm daily digest (your shared digest infra)
cron.schedule('0 18 * * *', () => {
  console.log('[cron] running 6pm digest…');
  runDigest().catch(e => console.error('[cron] digest failed:', e.message));
});

console.log('[cron] scheduled: screens 7am/12pm/4pm weekdays, digest 6pm daily');
