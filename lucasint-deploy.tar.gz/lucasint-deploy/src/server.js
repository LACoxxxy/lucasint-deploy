/**
 * LucasINT — main server
 * Serves the PWA, proxies Claude API (keeps key server-side), exposes
 * screening + portfolio endpoints, and schedules the screen loop + 6pm digest.
 */
require('dotenv').config();
const express = require('express');
const cron    = require('node-cron');
const path    = require('path');
const fs      = require('fs');

const { runScreen }  = require('./jobs/screen');
const { initEdgar }  = require('./scripts/init-edgar');
const { runDiscover } = require('./jobs/discover');
const { runDigest }  = require('./jobs/digest');
const { askClaude }  = require('./util/claude');
const { loadStore, saveStore } = require('./util/store');
const { allMarketStatus, dataFreshness } = require('./util/market-status');

const app = express();
app.use(express.json({ limit: '1mb' }));

// ── Serve the PWA ──────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── Health check ────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ ok: true, mode: process.env.TRADING_MODE || 'research', ts: new Date().toISOString() });
});

// ── Global market status ───────────────────────────────────────────────────
app.get('/api/markets', (req, res) => {
  res.json({ ts: new Date().toISOString(), markets: allMarketStatus() });
});

// ── Latest screen results (cached) ──────────────────────────────────────────
app.get('/api/screen', (req, res) => {
  const store = loadStore();
  res.json({ asOf: store.screenAsOf || null, results: store.screenResults || [] });
});

// ── On-demand AI deep analysis ───────────────────────────────────────────────
app.post('/api/analyse', async (req, res) => {
  try {
    const { system, user } = req.body;
    if (!system || !user) return res.status(400).json({ error: 'system and user required' });
    const text = await askClaude({ system, user, maxTokens: 1000 });
    res.json({ text });
  } catch (e) {
    console.error('analyse error:', e.message);
    res.status(500).json({ error: 'analysis failed', detail: e.message });
  }
});

app.get('/api/validated', (req, res) => {
  const store = loadStore();
  res.json({ asOf: store.harnessAsOf || null, note: store.harnessNote || null, strategies: store.harnessResults || [] });
});

// ── Backtest harness ─────────────────────────────────────────────────────────
// ~4-5 min (500 tickers × 3y history) → responds immediately, runs in background,
// server Telegrams the verdicts when done. ?wait=1 restores blocking behaviour.
let harnessRunning = false;
app.post('/api/harness-run', async (req, res) => {
  const { runHarnessJob } = require('./jobs/harness-run');
  if (req.query.wait === '1') {
    try { const r = await runHarnessJob(); return res.json({ ok: true, strategies: r }); }
    catch (e) { return res.status(500).json({ ok: false, error: e.message }); }
  }
  if (harnessRunning) return res.json({ ok: true, note: 'already running' });
  harnessRunning = true;
  res.json({ ok: true, note: 'backtest started — verdicts via Telegram in ~5 min' });
  runHarnessJob()
    .then(r => {
      if (!r) return sendTelegram('❌ Backtest aborted: no screen results yet — run /rebuild first.');
      const lines = r.map(x => `${x.grade === 'SURVIVED' ? '✅' : '❌'} [${x.grade}] ${x.label} — OOS hit ${x.outOfSample?.hitRate ?? '?'}, excess ${x.outOfSample?.avgExcess ?? '?'}%`);
      return sendTelegram(`🧪 Backtest complete (${r.length} hypotheses):\n${lines.join('\n')}\n\nSurvivors now power VALIDATION EVIDENCE in the app.`);
    })
    .catch(e => sendTelegram(`❌ Backtest failed: ${String(e.message || e).slice(0, 200)}`))
    .finally(() => { harnessRunning = false; });
});

// ── 5-year historical scoring backtest + weight optimisation ────────────────
// Heavy research job (~10-15 min: 350 tickers × 10y prices + EDGAR facts).
// Responds immediately; server Telegrams the full verdict when done.
let bt5yRunning = false;
app.post('/api/research/backtest5y', async (req, res) => {
  const { runBacktest5y } = require('./jobs/backtest5y');
  if (bt5yRunning) return res.json({ ok: true, note: 'already running' });
  bt5yRunning = true;
  res.json({ ok: true, note: '5y backtest started — full verdict via Telegram in ~10-15 min' });
  runBacktest5y()
    .then(out => {
      const fmt = (k) => {
        const r = out.results[k];
        if (!r || r.note) return `${k}: ${r?.note || 'n/a'}`;
        const b = r.baseline, w = r.best;
        return `${k}\n  current system: ${b.avgExcess > 0 ? '+' : ''}${b.avgExcess}% excess/period · hit ${Math.round(b.hitRate * 100)}% · n=${b.periods}\n  best mix (${w.name}): IS ${w.inSample.avgExcess > 0 ? '+' : ''}${w.inSample.avgExcess}% → OOS ${w.outSample.avgExcess != null ? (w.outSample.avgExcess > 0 ? '+' : '') + w.outSample.avgExcess + '%' : w.outSample.note}`;
      };
      const keys = Object.keys(out.results);
      return sendTelegram(`🧪 5-YEAR SCORING BACKTEST (${out.universe} US names)\n\n${keys.map(fmt).join('\n\n')}\n\n⚠ Survivorship-biased (upper bounds). 5y horizon indicative only. Winning weights saved to store.`);
    })
    .catch(e => sendTelegram(`❌ 5y backtest failed: ${String(e.message || e).slice(0, 200)}`))
    .finally(() => { bt5yRunning = false; });
});

app.get('/api/research/backtest5y', (req, res) => {
  const store = loadStore();
  res.json(store.backtest5y || { note: 'not run yet — POST to this endpoint to start' });
});

app.get('/api/portfolio', (req, res) => {
  const store = loadStore();
  res.json({ positions: store.portfolio || [] });
});

app.post('/api/portfolio', (req, res) => {
  const store = loadStore();
  store.portfolio = store.portfolio || [];
  store.portfolio.push({ ...req.body, addedAt: new Date().toISOString() });
  saveStore(store);
  res.json({ ok: true, positions: store.portfolio });
});

// ── EDGAR CIK map init (run once after fresh deploy) ────────────────────────
app.post('/api/admin/init-edgar', async (req, res) => {
  try { const r = await initEdgar(); res.json(r); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/admin/discover', async (req, res) => {
  try { const r = await runDiscover(); res.json(r); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ── Trigger a screen run ─────────────────────────────────────────────────────
// Long-running (30-45 min at full universe) → responds immediately and runs in
// the background; the SERVER sends the Telegram completion ping so no client
// has to hold a connection open. ?wait=1 restores the old blocking behaviour.
const { sendTelegram } = require('./util/telegram');
let screenRunning = false;
app.post('/api/screen/run', async (req, res) => {
  if (req.query.wait === '1') {
    try { const r = await runScreen(); return res.json({ ok: true, count: r.length }); }
    catch (e) { return res.status(500).json({ error: e.message }); }
  }
  if (screenRunning) return res.json({ ok: true, count: '(already running — tap /screen for progress)' });
  screenRunning = true;
  res.json({ ok: true, count: '(running in background — I will message when done)' });
  runScreen()
    .then(r => sendTelegram(`✅ Screen complete: ${r.filter(x => x.score != null).length} stocks scored. Reload the app.`))
    .catch(e => sendTelegram(`❌ Screen run failed: ${String(e.message || e).slice(0, 200)}`))
    .finally(() => { screenRunning = false; });
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`\n  LucasINT running → http://localhost:${PORT}`);
  console.log(`  Mode: ${process.env.TRADING_MODE || 'research'}`);
  console.log(`  PWA served from /public\n`);

  // Auto-init CIK map if thin (fresh deploy or cache missing)
  try {
    const ckMap = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'cik-map.json'), 'utf8'));
    if (Object.keys(ckMap).length < 100) {
      console.log('[startup] CIK map thin — running init-edgar in background');
      initEdgar().catch(e => console.error('[startup] init-edgar:', e.message));
    }
  } catch {
    console.log('[startup] No CIK cache — running init-edgar in background');
    initEdgar().catch(e => console.error('[startup] init-edgar:', e.message));
  }
});

// ── Scheduled jobs ─────────────────────────────────────────────────────────
cron.schedule('0 7,12,16 * * 1-5', () => {
  console.log('[cron] running scheduled screen…');
  runScreen().catch(e => console.error('[cron] screen failed:', e.message));
});
cron.schedule('0 6 * * 0', () => {
  console.log('[cron] running weekly universe discovery…');
  runDiscover().catch(e => console.error('[cron] discover failed:', e.message));
});
cron.schedule('0 7 * * 0', () => {
  console.log('[cron] running weekly backtest harness…');
  const { runHarnessJob } = require('./jobs/harness-run');
  runHarnessJob()
    .then(r => r && sendTelegram(`🧪 Weekly backtest refreshed: ${r.filter(x => x.grade === 'SURVIVED').length}/${r.length} strategies survived.`))
    .catch(e => console.error('[cron] harness failed:', e.message));
});

// First-run activation: if the 5y scoring backtest has never run, fire it
// automatically 10 min after boot (after the harness has had its turn).
setTimeout(() => {
  try {
    const st = loadStore();
    if ((!st.backtest5y || (st.backtest5y.version || 1) < 2) && (st.screenResults || []).length) {
      console.log('[startup] No 5y backtest yet — running in background');
      const { runBacktest5y } = require('./jobs/backtest5y');
      runBacktest5y()
        .then(out => {
          const fmt = (k) => {
            const r = out.results[k];
            if (!r || r.note) return `${k}: ${r?.note || 'n/a'}`;
            const b = r.baseline, w = r.best;
            return `${k}\n  current system: ${b.avgExcess > 0 ? '+' : ''}${b.avgExcess}% excess/period · hit ${Math.round(b.hitRate * 100)}% · n=${b.periods}\n  best mix (${w.name}): IS ${w.inSample.avgExcess > 0 ? '+' : ''}${w.inSample.avgExcess}% → OOS ${w.outSample.avgExcess != null ? (w.outSample.avgExcess > 0 ? '+' : '') + w.outSample.avgExcess + '%' : w.outSample.note}`;
          };
          return sendTelegram(`🧪 5-YEAR SCORING BACKTEST (${out.universe} US names)\n\n${Object.keys(out.results).map(fmt).join('\n\n')}\n\n⚠ Survivorship-biased (upper bounds). 5y horizon indicative only.`);
        })
        .catch(e => console.error('[startup] bt5y:', e.message));
    }
  } catch (e) { /* store unreadable — manual endpoint still available */ }
}, 10 * 60 * 1000);

// First-run activation: if the harness has never produced verdicts, run it
// automatically 2 min after boot (lets the server settle first).
setTimeout(() => {
  try {
    const st = loadStore();
    if (!st.harnessAsOf && (st.screenResults || []).length) {
      console.log('[startup] No backtest verdicts yet — running harness in background');
      const { runHarnessJob } = require('./jobs/harness-run');
      runHarnessJob()
        .then(r => r && sendTelegram(`🧪 First backtest complete: ${r.filter(x => x.grade === 'SURVIVED').length}/${r.length} strategies survived. Verdicts now live in the app.`))
        .catch(e => console.error('[startup] harness:', e.message));
    }
  } catch (e) { /* store not readable yet — weekly cron will catch it */ }
}, 2 * 60 * 1000);
cron.schedule('0 18 * * *', () => {
  console.log('[cron] running 6pm digest…');
  runDigest().catch(e => console.error('[cron] digest failed:', e.message));
});

console.log('[cron] scheduled: screens 7am/12pm/4pm weekdays, digest 6pm daily');
