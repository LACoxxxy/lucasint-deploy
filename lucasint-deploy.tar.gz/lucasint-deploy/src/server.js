/**
 * LucasINT — main server
 * Serves the PWA, proxies Claude API (keeps key server-side), exposes
 * screening + portfolio endpoints, and schedules the screen loop + 6pm digest.
 */
require('dotenv').config();
const express = require('express');
const cron    = require('node-cron');
const path    = require('path');
const fs      = require('fs');

const { runScreen }  = require('./jobs/screen');
const { initEdgar }  = require('./scripts/init-edgar');
const { runDiscover } = require('./jobs/discover');
const { runDigest }  = require('./jobs/digest');
const { askClaude }  = require('./util/claude');
const { loadStore, saveStore } = require('./util/store');
const { allMarketStatus, dataFreshness } = require('./util/market-status');

const app = express();
app.use(express.json({ limit: '1mb' }));

// ── Serve the PWA ──────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '..', 'public')));

// ── Health check ────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ ok: true, mode: process.env.TRADING_MODE || 'research', ts: new Date().toISOString() });
});

// ── Global market status ───────────────────────────────────────────────────
app.get('/api/markets', (req, res) => {
  res.json({ ts: new Date().toISOString(), markets: allMarketStatus() });
});

// ── Latest screen results (cached) ──────────────────────────────────────────
app.get('/api/screen', (req, res) => {
  const store = loadStore();
  res.json({ asOf: store.screenAsOf || null, results: store.screenResults || [] });
});

// ── On-demand AI deep analysis ───────────────────────────────────────────────
app.post('/api/analyse', async (req, res) => {
  try {
    const { system, user } = req.body;
    if (!system || !user) return res.status(400).json({ error: 'system and user required' });
    const text = await askClaude({ system, user, maxTokens: 1000 });
    res.json({ text });
  } catch (e) {
    console.error('analyse error:', e.message);
    res.status(500).json({ error: 'analysis failed', detail: e.message });
  }
});

app.get('/api/validated', (req, res) => {
  const store = loadStore();
  res.json({ asOf: store.harnessAsOf || null, note: store.harnessNote || null, strategies: store.harnessResults || [] });
});

// ── Backtest harness ─────────────────────────────────────────────────────────
// ~4-5 min (500 tickers × 3y history) → responds immediately, runs in background,
// server Telegrams the verdicts when done. ?wait=1 restores blocking behaviour.
let harnessRunning = false;
app.post('/api/harness-run', async (req, res) => {
  const { runHarnessJob } = require('./jobs/harness-run');
  if (req.query.wait === '1') {
    try { const r = await runHarnessJob(); return res.json({ ok: true, strategies: r }); }
    catch (e) { return res.status(500).json({ ok: false, error: e.message }); }
  }
  if (harnessRunning) return res.json({ ok: true, note: 'already running' });
  harnessRunning = true;
  res.json({ ok: true, note: 'backtest started — verdicts via Telegram in ~5 min' });
  runHarnessJob()
    .then(r => {
      if (!r) return sendTelegram('❌ Backtest aborted: no screen results yet — run /rebuild first.');
      const lines = r.map(x => `${x.grade === 'SURVIVED' ? '✅' : '❌'} [${x.grade}] ${x.label} — OOS hit ${x.outOfSample?.hitRate ?? '?'}, excess ${x.outOfSample?.avgExcess ?? '?'}%`);
      return sendTelegram(`🧪 Backtest complete (${r.length} hypotheses):\n${lines.join('\n')}\n\nSurvivors now power VALIDATION EVIDENCE in the app.`);
    })
    .catch(e => sendTelegram(`❌ Backtest failed: ${String(e.message || e).slice(0, 200)}`))
    .finally(() => { harnessRunning = false; });
});

app.get('/api/portfolio', (req, res) => {
  const store = loadStore();
  res.json({ positions: store.portfolio || [] });
});

app.post('/api/portfolio', (req, res) => {
  const store = loadStore();
  store.portfolio = store.portfolio || [];
  store.portfolio.push({ ...req.body, addedAt: new Date().toISOString() });
  saveStore(store);
  res.json({ ok: true, positions: store.portfolio });
});

// ── EDGAR CIK map init (run once after fresh deploy) ────────────────────────
app.post('/api/admin/init-edgar', async (req, res) => {
  try { const r = await initEdgar(); res.json(r); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

app.post('/api/admin/discover', async (req, res) => {
  try { const r = await runDiscover(); res.json(r); }
  catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ── Trigger a screen run ─────────────────────────────────────────────────────
// Long-running (30-45 min at full universe) → responds immediately and runs in
// the background; the SERVER sends the Telegram completion ping so no client
// has to hold a connection open. ?wait=1 restores the old blocking behaviour.
const { sendTelegram } = require('./util/telegram');
let screenRunning = false;
app.post('/api/screen/run', async (req, res) => {
  if (req.query.wait === '1') {
    try { const r = await runScreen(); return res.json({ ok: true, count: r.length }); }
    catch (e) { return res.status(500).json({ error: e.message }); }
  }
  if (screenRunning) return res.json({ ok: true, count: '(already running — tap /screen for progress)' });
  screenRunning = true;
  res.json({ ok: true, count: '(running in background — I will message when done)' });
  runScreen()
    .then(r => sendTelegram(`✅ Screen complete: ${r.filter(x => x.score != null).length} stocks scored. Reload the app.`))
    .catch(e => sendTelegram(`❌ Screen run failed: ${String(e.message || e).slice(0, 200)}`))
    .finally(() => { screenRunning = false; });
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`\n  LucasINT running → http://localhost:${PORT}`);
  console.log(`  Mode: ${process.env.TRADING_MODE || 'research'}`);
  console.log(`  PWA served from /public\n`);

  // Auto-init CIK map if thin (fresh deploy or cache missing)
  try {
    const ckMap = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'cik-map.json'), 'utf8'));
    if (Object.keys(ckMap).length < 100) {
      console.log('[startup] CIK map thin — running init-edgar in background');
      initEdgar().catch(e => console.error('[startup] init-edgar:', e.message));
    }
  } catch {
    console.log('[startup] No CIK cache — running init-edgar in background');
    initEdgar().catch(e => console.error('[startup] init-edgar:', e.message));
  }
});

// ── Scheduled jobs ─────────────────────────────────────────────────────────
cron.schedule('0 7,12,16 * * 1-5', () => {
  console.log('[cron] running scheduled screen…');
  runScreen().catch(e => console.error('[cron] screen failed:', e.message));
});
cron.schedule('0 6 * * 0', () => {
  console.log('[cron] running weekly universe discovery…');
  runDiscover().catch(e => console.error('[cron] discover failed:', e.message));
});
cron.schedule('0 7 * * 0', () => {
  console.log('[cron] running weekly backtest harness…');
  const { runHarnessJob } = require('./jobs/harness-run');
  runHarnessJob()
    .then(r => r && sendTelegram(`🧪 Weekly backtest refreshed: ${r.filter(x => x.grade === 'SURVIVED').length}/${r.length} strategies survived.`))
    .catch(e => console.error('[cron] harness failed:', e.message));
});

// First-run activation: if the harness has never produced verdicts, run it
// automatically 2 min after boot (lets the server settle first).
setTimeout(() => {
  try {
    const st = loadStore();
    if (!st.harnessAsOf && (st.screenResults || []).length) {
      console.log('[startup] No backtest verdicts yet — running harness in background');
      const { runHarnessJob } = require('./jobs/harness-run');
      runHarnessJob()
        .then(r => r && sendTelegram(`🧪 First backtest complete: ${r.filter(x => x.grade === 'SURVIVED').length}/${r.length} strategies survived. Verdicts now live in the app.`))
        .catch(e => console.error('[startup] harness:', e.message));
    }
  } catch (e) { /* store not readable yet — weekly cron will catch it */ }
}, 2 * 60 * 1000);
cron.schedule('0 18 * * *', () => {
  console.log('[cron] running 6pm digest…');
  runDigest().catch(e => console.error('[cron] digest failed:', e.message));
});

console.log('[cron] scheduled: screens 7am/12pm/4pm weekdays, digest 6pm daily');
