/**
 * moat.js — Quantitative economic-moat proxy (LONG-TERM conviction, not short-term buzz).
 *
 * Best-practice basis (Morningstar / Buffett-style durable-advantage screening):
 *   • A moat shows up as a SUSTAINED spread of ROIC over cost of capital (WACC).
 *     Long-term ROIC > ~15% and consistently above WACC ⇒ structural advantage.
 *   • Gross-margin STABILITY (low variance) proxies pricing power / durability.
 *   • Consistent positive free cash flow ⇒ can reinvest to defend the moat.
 *   • Moat TREND matters as much as level: rising ROIC/margins = widening;
 *     falling = narrowing (the early warning of erosion).
 *
 * This is the QUANTITATIVE half. The moat TYPE (network effect, switching costs,
 * intangibles, cost advantage, efficient scale), TAM/market-gap and competitive
 * position are qualitative — see util/longterm-claude.js. Absent data → 'unknown',
 * never fabricated.
 */
const WACC_PROXY = 9;          // default hurdle rate (%). Tunable per risk profile.
const STRONG_ROIC = 15;        // classic moat threshold
const GM_STABLE_SD = 4;        // gross-margin std-dev (pts) below which pricing power is "durable"

const mean = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : null;
const sd = a => { if (a.length < 2) return null; const m = mean(a); return Math.sqrt(mean(a.map(x => (x - m) ** 2))); };
const n1 = x => x == null ? null : +x.toFixed(1);

/**
 * @param f fundamentals object from edgar.js (needs roicHist, gmHist, fcfHist, revHist)
 * @param wacc optional hurdle rate override
 * @returns { width, trend, score, spread, gmStability, fcfConsistency, coverageYears, drivers, warnings }
 */
function assessMoat(f, wacc = WACC_PROXY) {
  const roic = (f.roicHist || []).map(p => p.val);   // newest→oldest
  const gm   = (f.gmHist   || []).map(p => p.val);
  const fcf  = (f.fcfHist  || []).map(p => p.val);
  const rev  = (f.revHist  || []).map(p => p.val);
  const years = roic.length;

  if (years < 2) {
    return { width: 'unknown', trend: 'unknown', score: null, coverageYears: years,
      drivers: [], warnings: ['Insufficient filing history for a moat read (need ≥2 fiscal years).'] };
  }

  const drivers = [], warnings = [];

  // ── ROIC spread & consistency ──
  const roicMean = mean(roic);
  const spread = n1(roicMean - wacc);
  const yearsAboveWacc = roic.filter(r => r > wacc).length;
  const yearsStrong = roic.filter(r => r >= STRONG_ROIC).length;
  const consistentAbove = yearsAboveWacc / years;              // 0..1

  // ── gross-margin durability (pricing power) ──
  const gmSd = gm.length >= 2 ? n1(sd(gm)) : null;
  const gmMean = gm.length ? n1(mean(gm)) : null;
  const pricingPower = gmSd != null && gmSd <= GM_STABLE_SD && gmMean >= 40;

  // ── FCF consistency (reinvestment ability) ──
  const fcfConsistency = fcf.length ? +(fcf.filter(x => x > 0).length / fcf.length).toFixed(2) : null;

  // ── TREND: recent vs older ROIC + margin compression (only meaningful with a real spread) ──
  let trend = 'unknown';
  if (years >= 3 && roicMean > wacc) {
    const recent = mean(roic.slice(0, Math.ceil(years / 2)));
    const older  = mean(roic.slice(Math.ceil(years / 2)));
    const dRoic = recent - older;
    const dGm = gm.length >= 3 ? mean(gm.slice(0, Math.ceil(gm.length / 2))) - mean(gm.slice(Math.ceil(gm.length / 2))) : 0;
    if (dRoic > 2 && dGm >= -1) trend = 'widening';
    else if (dRoic < -3 || dGm < -3) trend = 'narrowing';
    else trend = 'stable';
    if (trend === 'narrowing') warnings.push(`Moat eroding: ROIC ${n1(dRoic)}pts, margin ${n1(dGm)}pts vs earlier years.`);
  } else if (roicMean <= wacc) {
    trend = 'n/a';   // no advantage to have a trend in
  }

  // ── WIDTH classification ──
  let width = 'none';
  if (spread > 8 && consistentAbove >= 0.8 && yearsStrong >= Math.max(2, years - 1)) width = 'wide';
  else if (spread > 2 && consistentAbove >= 0.6) width = 'narrow';
  if (roicMean < 0) width = 'none';

  // ── drivers (why) ──
  if (spread > 0) drivers.push(`ROIC ${n1(roicMean)}% vs ~${wacc}% cost of capital (+${spread}pts) across ${years}y`);
  if (yearsStrong) drivers.push(`${yearsStrong}/${years} years with ROIC ≥ ${STRONG_ROIC}%`);
  if (pricingPower) drivers.push(`Gross margin ${gmMean}% ±${gmSd} — stable pricing power`);
  else if (gmSd != null && gmSd > GM_STABLE_SD) warnings.push(`Gross margin volatile (±${gmSd}pts) — weak pricing power`);
  if (fcfConsistency != null && fcfConsistency >= 0.8) drivers.push(`Positive FCF in ${Math.round(fcfConsistency * 100)}% of years`);
  else if (fcfConsistency != null && fcfConsistency < 0.5) warnings.push('Inconsistent free cash flow — limited reinvestment power');

  // ── long-term quality SCORE (0-100), separate from short-term conviction ──
  let sc = 0;
  sc += Math.max(-10, Math.min(45, spread * 2.2));                 // ROIC spread is the backbone
  sc += consistentAbove * 20;                                       // consistency
  sc += pricingPower ? 15 : (gmSd != null && gmSd <= GM_STABLE_SD * 2 ? 7 : 0);
  sc += (fcfConsistency ?? 0) * 12;
  sc += trend === 'widening' ? 8 : trend === 'narrowing' ? -12 : 0;
  const score = Math.max(0, Math.min(99, Math.round(40 + sc)));

  return {
    width, trend, score, spread, roicMean: n1(roicMean),
    gmStability: gmSd, gmMean, fcfConsistency, yearsStrong, coverageYears: years,
    drivers, warnings,
  };
}

module.exports = { assessMoat, WACC_PROXY };
