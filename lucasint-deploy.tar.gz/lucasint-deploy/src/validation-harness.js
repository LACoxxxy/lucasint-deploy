/**
 * validation-harness.js
 * ───────────────────────────────────────────────────────────────────────────
 * A rig whose job is to DISPROVE trading hypotheses before money is risked.
 *
 * It validates STRATEGIES (rule-sets), not individual stocks. A strategy is a
 * predicate like "insiderCluster>=3 AND peg<0.7 AND relStrength>5". The harness
 * asks: did stocks matching this rule actually outperform, out-of-sample, after
 * costs, after correcting for how many rules we tried — or did we fool ourselves?
 *
 * REQUIRES historical data:
 *   - point-in-time fundamentals (what was KNOWN on each date, not restated)
 *   - forward price returns (what happened AFTER)
 *   - a universe that INCLUDES delisted/dead names (survivorship)
 * Until the Beelink supplies this, runHarness() returns {status:'pending'}.
 *
 * PHILOSOPHY: the harness is hostile to your idea. It earns a rare "yes" by
 * being relentless with "no". A passing grade lowers — never removes — the
 * chance you're fooling yourself.
 * ───────────────────────────────────────────────────────────────────────────
 */

const HARNESS_CONFIG = {
  oosSplit: 0.5,            // fraction of history reserved for out-of-sample
  walkForwardWindows: 5,    // rolling train/test windows
  minToleratedHitRate: 0.5, // a coin flip; below this the edge is nothing
  // Multiple-testing: the more hypotheses tried, the higher the bar.
  // We track a running count and apply a Bonferroni-style correction.
  baseSignificance: 0.05,
  // Realistic frictions for small-cap trading (your universe)
  transactionCostPct: 0.1,  // per side
  slippagePct: 0.3,         // small-cap market impact estimate
  minSampleSize: 30,        // fewer matches than this = untrustworthy
};

// Running tally of how many hypotheses have been tested this session.
// Multiple-testing correction uses this — searching harder demands more proof.
let HYPOTHESES_TESTED = 0;

/**
 * Evaluate a hypothesis against historical data.
 * @param hypothesis { id, label, predicate(stockSnapshot)->bool }
 * @param history  array of { date, snapshots:[{ticker, ...fundamentals}], forwardReturns:{ticker: pct}, sectorReturns:{sector: pct} }
 * @returns a verdict object — honest, caveat-laden.
 */
function runHarness(hypothesis, history) {
  if (!history || history.length === 0) {
    return { status: 'pending', message: 'No historical data yet — runs on the Beelink once point-in-time history is wired.' };
  }
  HYPOTHESES_TESTED++;

  const warnings = [];

  // ── Split: develop on first half, test on held-out second half ──
  const splitIdx = Math.floor(history.length * HARNESS_CONFIG.oosSplit);
  const inSample = history.slice(0, splitIdx);
  const outSample = history.slice(splitIdx);

  const evalWindow = (windowData) => {
    let matches = 0, wins = 0, excessReturnSum = 0;
    for (const period of windowData) {
      for (const snap of period.snapshots) {
        let hit;
        try { hit = hypothesis.predicate(snap); } catch { hit = false; }
        if (!hit) continue;
        matches++;
        const fwd = period.forwardReturns?.[snap.ticker];
        const sect = period.sectorReturns?.[snap.sector] ?? 0;
        if (fwd == null) continue;
        // excess return vs the stock's own sector = "did it OUTPERFORM its sector"
        const excess = fwd - sect - (HARNESS_CONFIG.transactionCostPct + HARNESS_CONFIG.slippagePct);
        excessReturnSum += excess;
        if (excess > 0) wins++;
      }
    }
    return { matches, wins, hitRate: matches ? wins / matches : 0, avgExcess: matches ? excessReturnSum / matches : 0 };
  };

  const isr = evalWindow(inSample);
  const oos = evalWindow(outSample);

  // ── Sample-size guard ──
  if (oos.matches < HARNESS_CONFIG.minSampleSize) {
    warnings.push(`Only ${oos.matches} out-of-sample matches (<${HARNESS_CONFIG.minSampleSize}). Too few to trust — result is likely noise.`);
  }

  // ── Walk-forward: does it hold across rolling windows, not just one era? ──
  const wfWindows = [];
  const chunk = Math.floor(history.length / (HARNESS_CONFIG.walkForwardWindows + 1));
  if (chunk > 0) {
    for (let i = 0; i < HARNESS_CONFIG.walkForwardWindows; i++) {
      const testStart = chunk * (i + 1);
      const testData = history.slice(testStart, testStart + chunk);
      const r = evalWindow(testData);
      wfWindows.push({ window: i + 1, hitRate: +r.hitRate.toFixed(2), avgExcess: +r.avgExcess.toFixed(2), n: r.matches });
    }
  }
  const wfPassed = wfWindows.filter(w => w.hitRate > HARNESS_CONFIG.minToleratedHitRate && w.avgExcess > 0).length;

  // ── In-sample vs out-of-sample decay (overfitting detector) ──
  const decay = isr.avgExcess - oos.avgExcess;
  const overfitSuspected = isr.avgExcess > 0 && oos.avgExcess < isr.avgExcess * 0.4;
  if (overfitSuspected) warnings.push(`Strong in-sample (${isr.avgExcess.toFixed(1)}%) but weak out-of-sample (${oos.avgExcess.toFixed(1)}%) — classic overfitting signature. The pattern probably doesn't generalise.`);

  // ── Multiple-testing correction ──
  const correctedThreshold = HARNESS_CONFIG.baseSignificance / HYPOTHESES_TESTED;
  warnings.push(`Multiple-testing: this is hypothesis #${HYPOTHESES_TESTED} this session. Significance bar tightened to ${correctedThreshold.toFixed(4)} (the more you test, the more luck masquerades as signal).`);

  // ── Verdict (deliberately conservative) ──
  let grade, verdict;
  const oosGood = oos.hitRate > HARNESS_CONFIG.minToleratedHitRate && oos.avgExcess > 0 && oos.matches >= HARNESS_CONFIG.minSampleSize;
  const wfGood = wfPassed >= Math.ceil(HARNESS_CONFIG.walkForwardWindows * 0.6);
  if (oosGood && wfGood && !overfitSuspected) {
    grade = 'SURVIVED';
    verdict = `Held out-of-sample (${(oos.hitRate*100).toFixed(0)}% hit, +${oos.avgExcess.toFixed(1)}% avg excess) across ${wfPassed}/${HARNESS_CONFIG.walkForwardWindows} windows after costs. Worth a small, monitored allocation — not a guarantee.`;
  } else if (oos.avgExcess > 0 && (wfPassed >= 2)) {
    grade = 'WEAK';
    verdict = `Some out-of-sample signal but inconsistent. Treat with caution; not enough to act on alone.`;
  } else {
    grade = 'FAILED';
    verdict = `Did not survive honest testing. Most likely noise or overfitting. Do not act on this pattern.`;
  }

  return {
    status: 'complete',
    hypothesis: hypothesis.label,
    grade, verdict, warnings,
    inSample: { hitRate: +isr.hitRate.toFixed(2), avgExcess: +isr.avgExcess.toFixed(2), n: isr.matches },
    outOfSample: { hitRate: +oos.hitRate.toFixed(2), avgExcess: +oos.avgExcess.toFixed(2), n: oos.matches },
    walkForward: wfWindows,
    overfitSuspected,
    hypothesesTestedThisSession: HYPOTHESES_TESTED,
  };
}

/**
 * Per-stock EVIDENCE classification — the honest version of a "harness score".
 * Does NOT predict the stock. It reports whether the stock currently matches
 * any strategy that has SURVIVED validation, so you know if its conviction
 * ranking rests on validated patterns or unvalidated guesses.
 *
 * @param stock        the current stock snapshot
 * @param validatedStrategies  array of { hypothesis, grade } from prior runHarness calls
 * @returns { tier, label, matchedStrategies }
 */
function evidenceForStock(stock, validatedStrategies = []) {
  if (!validatedStrategies.length) {
    return { tier: 'untested', label: 'UNVALIDATED', note: 'Conviction score rests on plausible but untested factors. No strategy has been validated yet.' };
  }
  const matched = validatedStrategies.filter(vs => {
    try { return vs.predicate(stock); } catch { return false; }
  });
  const survived = matched.filter(m => m.grade === 'SURVIVED');
  const weak = matched.filter(m => m.grade === 'WEAK');
  if (survived.length) {
    return { tier: 'validated', label: `EVIDENCE-BACKED (${survived.length})`, matchedStrategies: survived.map(s => s.label),
      note: `Matches ${survived.length} strategy(ies) that survived out-of-sample validation. Higher confidence the ranking means something — still not a guarantee.` };
  }
  if (weak.length) {
    return { tier: 'weak', label: 'WEAK EVIDENCE', matchedStrategies: weak.map(s => s.label),
      note: 'Matches only weakly-validated patterns. Treat ranking with caution.' };
  }
  return { tier: 'untested', label: 'UNVALIDATED', note: 'Does not match any validated strategy. Ranking rests on untested factors.' };
}

function resetHypothesisCounter() { HYPOTHESES_TESTED = 0; }

module.exports = { HARNESS_CONFIG, runHarness, evidenceForStock, resetHypothesisCounter };
