/**
 * sentiment-direction.js
 * ───────────────────────────────────────────────────────────────────────────
 * Turns raw "attention" into DIRECTIONAL sentiment — but ONLY when confident.
 *
 * The cardinal rule: magnitude is not direction. High activity can mean euphoria
 * OR panic. This module refuses to assign a direction unless multiple independent
 * directional inputs AGREE with sufficient confidence. Otherwise it returns
 * direction:'unknown' — honestly admitting it cannot tell.
 *
 * Directional inputs (all need live data on the Beelink):
 *   - putCallRatio    : <0.7 bullish skew, >1.0 bearish skew
 *   - socialPolarity  : NLP sentiment of posts, -1..+1 (needs live social text)
 *   - priceConfirm    : is the attention accompanying a rise (+) or fall (-)?
 *
 * Confidence = how strongly the inputs agree. Low agreement → 'unknown'.
 * ───────────────────────────────────────────────────────────────────────────
 */

const SENT_CONFIG = {
  minConfidence: 0.6,        // below this, direction is 'unknown' — we stay honest
  minInputs: 2,              // need ≥2 independent directional inputs to call a direction;
                             // price alone is momentum re-labeled, not sentiment
  putCallBull: 0.7,
  putCallBear: 1.0,
  bearishExitThreshold: -0.4, // sentiment this negative becomes a SELL signal
};

/**
 * @param d {
 *   activity,        // 0-100 magnitude (the old "buzz") — direction-blind
 *   putCallRatio,    // live options skew (null if unavailable)
 *   socialPolarity,  // -1..+1 NLP sentiment (null if unavailable)
 *   priceConfirm,    // -1..+1 recent price direction accompanying the buzz (null if unavailable)
 * }
 * @returns { direction, confidence, label, isExitSignal, note }
 */
function sentimentDirection(d) {
  const inputs = [];
  if (d.putCallRatio != null) {
    inputs.push(d.putCallRatio < SENT_CONFIG.putCallBull ? 1 : d.putCallRatio > SENT_CONFIG.putCallBear ? -1 : 0);
  }
  if (d.socialPolarity != null) inputs.push(Math.max(-1, Math.min(1, d.socialPolarity)));
  if (d.priceConfirm != null)   inputs.push(Math.max(-1, Math.min(1, d.priceConfirm)));

  // No directional data at all → honestly unknown (the prototype's default state)
  if (inputs.length === 0) {
    return { direction: 'unknown', confidence: 0, label: 'ATTENTION (direction unknown)',
      isExitSignal: false, note: `Activity ${d.activity ?? '?'}/100 — magnitude only. Directional sentiment needs live options/social/price data (Beelink).` };
  }

  // Not enough independent inputs to responsibly call a direction (e.g. price only)
  if (inputs.length < SENT_CONFIG.minInputs) {
    return { direction: 'unknown', confidence: 0, label: 'ATTENTION (direction unknown)',
      isExitSignal: false, note: `Only ${inputs.length} directional input available (price). Need options put/call + social NLP to confirm direction — those feeds are pending on the Beelink. Treating as magnitude, not direction.` };
  }

  // Mean signed signal, and agreement = 1 - normalised spread
  const mean = inputs.reduce((a, b) => a + b, 0) / inputs.length;
  const spread = inputs.length > 1 ? Math.max(...inputs) - Math.min(...inputs) : 0;
  const agreement = 1 - spread / 2; // spread of 2 (full disagreement) → 0 confidence
  const confidence = +(Math.abs(mean) * agreement).toFixed(2);

  // Not confident enough → stay honest
  if (confidence < SENT_CONFIG.minConfidence) {
    return { direction: 'unknown', confidence, label: 'MIXED / UNCLEAR',
      isExitSignal: false, note: `Directional inputs disagree (confidence ${confidence}). Refusing to call a direction — treat buzz as noise.` };
  }

  const direction = mean > 0 ? 'positive' : 'negative';
  const isExitSignal = mean <= SENT_CONFIG.bearishExitThreshold && confidence >= SENT_CONFIG.minConfidence;
  return {
    direction, confidence,
    label: direction === 'positive' ? `POSITIVE buzz (conf ${confidence})` : `NEGATIVE buzz (conf ${confidence})`,
    isExitSignal,
    note: direction === 'positive'
      ? `Confident bullish sentiment — but bullish buzz is a weak BUY signal (crowds are often late). Use as context, not trigger.`
      : `Confident bearish sentiment — actionable as an EXIT/reassess signal on holdings.`,
  };
}

module.exports = { SENT_CONFIG, sentimentDirection };
