/**
 * scoring.js — the conviction model ported from the prototype, adapted to LIVE fields.
 * Scores only on factors the live data actually provides, and reports coverage —
 * factors without data contribute nothing (no fabricated inputs, no silent defaults).
 * Absent live signals for now (honest): insider clusters, patents, social, ROIC.
 */
function peg(s){ return (s.pe && s.revGrowth && s.revGrowth > 0) ? +(s.pe / s.revGrowth).toFixed(2) : null; }

function mom6mFromHistory(h){ // ~126 trading days
  if (!h || h.closes.length < 130) return null;
  const now = h.closes[h.closes.length - 1], then = h.closes[h.closes.length - 127];
  return +(((now - then) / then) * 100).toFixed(1);
}

function score(s, sectorPeers) {
  let sc = 0; const bd = []; const covered = []; const missing = [];
  const pg = peg(s);

  // VALUE
  if (pg != null) { covered.push('value');
    if (pg < 0.5) { sc += 18; bd.push(['Value', `PEG ${pg} — very cheap for growth`, 18]); }
    else if (pg < 1) { sc += 12; bd.push(['Value', `PEG ${pg}`, 12]); }
    else if (pg < 2) { sc += 5; bd.push(['Value', `PEG ${pg}`, 5]); }
    else { sc -= 3; bd.push(['Value', `PEG ${pg} — expensive`, -3]); }
  } else missing.push('value(PEG)');
  // sector-relative PE
  const peerPEs = (sectorPeers || []).map(p => p.pe).filter(x => x != null);
  if (s.pe != null && peerPEs.length >= 2) { covered.push('relative-value');
    const avg = peerPEs.reduce((a, b) => a + b, 0) / peerPEs.length;
    if (s.pe < avg * 0.7) { sc += 6; bd.push(['Value', `PE ${s.pe.toFixed(1)} vs sector ~${avg.toFixed(0)}`, 6]); }
    else if (s.pe > avg * 1.5) { sc -= 3; bd.push(['Value', `PE rich vs sector`, -3]); }
  }

  // GROWTH
  if (s.revGrowth != null) { covered.push('growth');
    if (s.revGrowth >= 40) { sc += 16; bd.push(['Growth', `Revenue +${s.revGrowth}%`, 16]); }
    else if (s.revGrowth >= 20) { sc += 10; bd.push(['Growth', `Revenue +${s.revGrowth}%`, 10]); }
    else if (s.revGrowth >= 8) { sc += 4; bd.push(['Growth', `Revenue +${s.revGrowth}%`, 4]); }
    else if (s.revGrowth < 0) { sc -= 6; bd.push(['Growth', `Revenue ${s.revGrowth}%`, -6]); }
  } else missing.push('growth');

  // QUALITY (gross margin; ROIC not in live feed yet)
  if (s.grossMargin != null) { covered.push('quality');
    if (s.grossMargin >= 55) { sc += 10; bd.push(['Quality', `GM ${s.grossMargin}%`, 10]); }
    else if (s.grossMargin >= 40) { sc += 6; bd.push(['Quality', `GM ${s.grossMargin}%`, 6]); }
    else if (s.grossMargin < 20) { sc -= 4; bd.push(['Quality', `GM ${s.grossMargin}% — thin`, -4]); }
  } else missing.push('quality(GM)');
  missing.push('quality(ROIC)'); // not yet live — honest gap

  // MOMENTUM + RELATIVE STRENGTH (computed from real price history)
  if (s.mom6m != null) { covered.push('momentum');
    if (s.mom6m >= 40) { sc += 12; bd.push(['Momentum', `+${s.mom6m}% 6m`, 12]); }
    else if (s.mom6m >= 15) { sc += 7; bd.push(['Momentum', `+${s.mom6m}% 6m`, 7]); }
    else if (s.mom6m < 0) { sc -= 4; bd.push(['Momentum', `${s.mom6m}% 6m`, -4]); }
    const peerMoms = (sectorPeers || []).map(p => p.mom6m).filter(x => x != null);
    if (peerMoms.length >= 2) { covered.push('rel-strength');
      const rs = +(s.mom6m - peerMoms.reduce((a, b) => a + b, 0) / peerMoms.length).toFixed(0);
      s.relStrength = rs;
      if (rs >= 15) { sc += 8; bd.push(['Momentum', `Leading sector +${rs}%`, 8]); }
      else if (rs >= 5) { sc += 4; bd.push(['Momentum', `Outperforming +${rs}%`, 4]); }
      else if (rs < -10) { sc -= 4; bd.push(['Momentum', `Lagging ${rs}%`, -4]); }
    }
  } else missing.push('momentum');

  // SOLVENCY GATE
  let solvencyCapped = false;
  if (s.debtToEquity != null && s.debtToEquity > 2) { sc -= 8; bd.push(['Solvency', `D/E ${s.debtToEquity}`, -8]); }
  if (s.currentRatio != null && s.currentRatio < 1) { sc -= 6; bd.push(['Solvency', `Current ratio ${s.currentRatio}`, -6]); solvencyCapped = true; }

  // CONTRARIAN (short interest)
  if (s.shortPctFloat != null && s.shortPctFloat >= 15) { sc += 4; bd.push(['Contrarian', `Short ${s.shortPctFloat}% of float`, 4]); covered.push('contrarian'); }

  // normalise to 0-99 (base 40 + factors), apply solvency cap
  let final = Math.max(0, Math.min(99, 40 + sc));
  if (solvencyCapped && final > 70) final = 70;

  // signals not live yet — absent, not defaulted
  missing.push('signals(insider/patent/social)');
  return { score: Math.round(final), breakdown: bd, covered, missing, solvencyCapped };
}

module.exports = { score, peg, mom6mFromHistory };
