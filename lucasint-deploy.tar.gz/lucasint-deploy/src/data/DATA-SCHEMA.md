# Data fields the live screen needs to populate

## Live-now factors (already scored in the model)
- `relStrength` — derived: stock 6m return minus sector-average 6m return
- `peHistory` — [low, median, high] of trailing P/E range (compute from price history)
- `insiderCluster` — count of distinct insider buyers in last 90d (SEC Form 4)
- `shareCountTrend` — YoY % change in shares outstanding (+ dilution, - buyback)

## Scaffolded — wire these data sources on the Beelink
- **Earnings revisions** — analyst EPS estimate revision trend (30/90d), % raising.
  Source options: paid estimates feed (Quiver, or broker API). Highest-value add.
- **Catalyst calendar** — earnings dates, product launches, lockup expiries, index
  rebalance windows. Source: earnings calendar API + manual event entry.
- **Backtest** — requires historical price + historical fundamentals snapshots.
  MUST be out-of-sample. Guard against look-ahead/survivorship bias. Treat skeptically.

## Honesty rule
Until a source is wired, the feature shows "pending live data" — never fabricated numbers.

## Validation harness (validation-harness.js)
Validates STRATEGIES, not stocks. Needs:
- Point-in-time fundamental snapshots per historical date (what was KNOWN then).
- Forward returns per ticker (what happened after each snapshot).
- Sector returns per period (to measure OUTPERFORMANCE vs sector).
- A universe INCLUDING delisted/dead tickers (else survivorship bias flatters everything).

Output feeds VALIDATED_STRATEGIES in the PWA, which drives the per-stock
EVIDENCE badge (EVIDENCE-BACKED / WEAK / UNVALIDATED). Until wired, every stock
honestly shows UNVALIDATED — the conviction score is plausible but unproven.

Run discipline: develop hypotheses on in-sample half only; the harness reserves
the out-of-sample half and applies walk-forward + multiple-testing correction.
A "SURVIVED" grade lowers — never removes — the chance of self-deception.

## Exit strategy (exit-strategy.js)
Per held position needs: entryPrice, qty, entryConviction, entryDate, plus live
price, high-water-mark since entry, volatility (for ATR stop), current conviction,
and current solvency status. Tier 1 (monitor) + Tier 2 (suggested levels) are
advisory and live now. Tier 3 (auto-execute) is scaffolded and LOCKED behind
trade-guardrails — never active without deliberate opt-in.

## Directional sentiment (sentiment-direction.js)
Buzz MUST be direction-confident. Needs live: putCallRatio (options skew),
socialPolarity (NLP sentiment -1..+1 of posts), priceConfirm (price direction
accompanying the buzz). Returns a direction ONLY when inputs agree above
confidence threshold; else "unknown". Negative confident sentiment feeds the
exit/sell strategy as a reassess trigger. ALIGNED flag now requires confident
POSITIVE sentiment — until live data exists it shows "pending-sentiment", never
fires on direction-blind activity.
