/**
 * research-guardrails.js
 * ───────────────────────────────────────────────────────────────────────────
 * SAFETY LAYER for the RESEARCH side of the LucasINT agent.
 *
 * The research agent moves no money, so execution guardrails (position limits,
 * loss breakers, kill switch) don't apply. Its failure mode is different and
 * arguably more insidious: it can quietly surface something FALSE that you then
 * believe and act on. These guards target that.
 *
 * THREE PILLARS:
 *   A. INPUT INTEGRITY   — is the raw data fresh, parseable, and plausible?
 *   B. HALLUCINATION GUARD — force the AI to separate FACTS from ANALYST VIEW,
 *                            and never invent specifics.
 *   C. PROVENANCE         — every signal/figure carries its source + freshness,
 *                            so verified filings are distinguishable from inference.
 *
 * DESIGN CHOICES (per Lucas):
 *   - Bad/stale data is SHOWN but flagged LOUDLY as suspect (not hidden/blocked).
 *   - AI output is split into a FACTS section (grounded only in supplied data)
 *     and a separate ANALYST VIEW section (reasoned judgement, clearly labelled).
 * ───────────────────────────────────────────────────────────────────────────
 */

// ============================ CONFIG ========================================
const RESEARCH_CONFIG = {
  // Freshness thresholds
  maxPriceAgeMinutes:        20,
  maxFundamentalAgeHours:    26,
  maxSignalAgeDays:          14,   // a "patent surge" from 3 months ago isn't news

  // Plausibility bounds — values outside these are almost certainly parse errors
  bounds: {
    pe:           { min: 0.5,  max: 500,   label: 'P/E' },
    revGrowth:    { min: -90,  max: 500,   label: 'Revenue growth %' },
    roic:         { min: -100, max: 100,   label: 'ROIC %' },
    grossMargin:  { min: -50,  max: 100,   label: 'Gross margin %' },
    shortInt:     { min: 0,    max: 100,   label: 'Short interest %' },
    mom6m:        { min: -95,  max: 1000,  label: '6m momentum %' },
    debtToEquity: { min: 0,    max: 20,    label: 'Debt/equity' },
    price:        { min: 0.01, max: 100000,label: 'Price' },
  },

  // Cross-field consistency checks (catch internally contradictory data)
  consistencyChecks: true,
};

// ============================ A. INPUT INTEGRITY ============================
/**
 * Validate one stock's raw data. Returns flags — NEVER throws, NEVER hides data.
 * Each flag: { field, severity: 'suspect'|'warn', message }
 */
function validateStockData(stock, meta = {}) {
  const flags = [];
  const B = RESEARCH_CONFIG.bounds;

  // --- Plausibility bounds ---
  const check = (val, key) => {
    if (val == null) return;
    const b = B[key];
    if (!b) return;
    if (!isFinite(val)) flags.push({ field: key, severity: 'suspect', message: `${b.label} is not a number (${val}) — likely a parse/feed error` });
    else if (val < b.min || val > b.max) flags.push({ field: key, severity: 'suspect', message: `${b.label} = ${val} is outside plausible range [${b.min}, ${b.max}] — treat as suspect` });
  };
  check(stock.pe, 'pe');
  check(stock.revGrowth, 'revGrowth');
  check(stock.roic, 'roic');
  check(stock.grossMargin, 'grossMargin');
  check(stock.short, 'shortInt');
  check(stock.mom6m, 'mom6m');
  check(stock.debtToEquity, 'debtToEquity');
  check(stock.price, 'price');

  // --- Freshness ---
  if (meta.priceAgeMinutes != null && meta.priceAgeMinutes > RESEARCH_CONFIG.maxPriceAgeMinutes)
    flags.push({ field: 'price', severity: 'warn', message: `Price is ${meta.priceAgeMinutes}min old (>${RESEARCH_CONFIG.maxPriceAgeMinutes}min) — may be stale` });
  if (meta.fundamentalAgeHours != null && meta.fundamentalAgeHours > RESEARCH_CONFIG.maxFundamentalAgeHours)
    flags.push({ field: 'fundamentals', severity: 'warn', message: `Fundamentals ${meta.fundamentalAgeHours}h old — re-screen recommended` });

  // --- Cross-field consistency ---
  if (RESEARCH_CONFIG.consistencyChecks) {
    // Profitable (P/E exists) but deeply negative ROIC is contradictory
    if (stock.pe != null && stock.pe > 0 && stock.roic != null && stock.roic < -10)
      flags.push({ field: 'roic', severity: 'suspect', message: `Has positive P/E (${stock.pe}) but ROIC ${stock.roic}% — internally inconsistent, verify` });
    // Pre-profit (no P/E) but positive high ROIC is contradictory
    if (stock.pe == null && stock.roic != null && stock.roic > 15)
      flags.push({ field: 'roic', severity: 'suspect', message: `No P/E (pre-profit) but ROIC ${stock.roic}% — verify which is wrong` });
    // Cash runway given for a profitable company (shouldn't need one)
    if (stock.pe != null && stock.pe > 0 && stock.cashRunwayQtrs != null)
      flags.push({ field: 'cashRunwayQtrs', severity: 'warn', message: `Profitable company shows finite cash runway — check classification` });
  }

  return {
    flags,
    hasSuspect: flags.some(f => f.severity === 'suspect'),
    hasWarn: flags.some(f => f.severity === 'warn'),
    // a single banner string for the UI
    banner: flags.length
      ? `${flags.some(f=>f.severity==='suspect') ? '⚠ SUSPECT DATA' : '△ DATA WARNING'}: ${flags.length} issue(s) — figures shown but flagged. Verify before acting.`
      : null,
  };
}

// ============================ B. HALLUCINATION GUARD ========================
/**
 * Build the system prompt + user prompt for the AI deep-dive so that output is
 * forced into a FACTS section (grounded only in supplied data) and a separate
 * ANALYST VIEW section (reasoned, clearly labelled as judgement).
 *
 * The agent calling code uses these instead of an ad-hoc prompt.
 */
function buildGroundedPrompt(stock, derived, dataFlags) {
  const flagNote = dataFlags.flags.length
    ? `\nDATA QUALITY WARNINGS (the figures below may be unreliable — reflect this in confidence):\n${dataFlags.flags.map(f => `  - ${f.message}`).join('\n')}`
    : '\nData quality: no flags raised on input figures.';

  const system =
`You are an elite buy-side investment analyst. You must obey these RULES without exception:

1. OUTPUT TWO CLEARLY SEPARATED SECTIONS, in this exact order:
   === FACTS (from supplied data only) ===
   - Restate ONLY figures and signals explicitly provided below.
   - Do NOT add any number, date, contract name, customer, or metric that is not in the supplied data.
   - If a fact would be useful but is not supplied, write "not provided" — never fill it in from memory.
   === ANALYST VIEW (my reasoned judgement — NOT verified fact) ===
   - Here you may reason, infer, and speculate, but every claim must be recognisably your interpretation.
   - When you reference a historical comparable or external event, explicitly tag it "(from my general knowledge, unverified — user should confirm)".
   - Never present inference as established fact.

2. You have NO web access and NO live data beyond what is supplied. You cannot verify anything. Say so if it matters.

3. If data-quality warnings are present, explicitly lower your stated confidence and say which conclusions are unsafe.

4. Be concise, direct, opinionated — but honesty about uncertainty outranks confidence.

5. This is research tooling, not financial advice. End with a one-line reminder that the user makes the decision.`;

  const user =
`Analyse ${stock.ticker || stock.name} using ONLY the data below.
${flagNote}

SUPPLIED DATA:
- Sector: ${stock.sector}
- Price: ${stock.price != null ? '$'+stock.price : 'not provided'}
- P/E: ${stock.pe ?? 'not provided (pre-profit or unknown)'}
- PEG: ${derived.peg ?? 'not provided'}
- Revenue growth YoY: ${stock.revGrowth != null ? '+'+stock.revGrowth+'%' : 'not provided'}
- ROIC: ${stock.roic != null ? stock.roic+'%' : 'not provided'}
- Gross margin: ${stock.grossMargin != null ? stock.grossMargin+'%' : 'not provided'}
- 6m momentum: ${stock.mom6m != null ? stock.mom6m+'%' : 'not provided'}
- Volatility: ${stock.volatility != null ? stock.volatility+'%' : 'not provided'}
- Short interest: ${stock.short != null ? stock.short+'%' : 'not provided'}
- DCF fair value: ${derived.dcfFairValue != null ? '$'+derived.dcfFairValue+' ('+(derived.dcfUpside>0?'+':'')+derived.dcfUpside+'% vs price)' : 'not meaningful (negative FCF)'}
- Balance sheet: D/E ${stock.debtToEquity ?? 'n/a'}, current ratio ${stock.currentRatio ?? 'n/a'}, cash runway ${stock.cashRunwayQtrs ?? 'profitable/n/a'}
- Fundamental conviction score: ${derived.fundamentalScore ?? 'n/a'}/99
- Speculative/sentiment score: ${derived.speculativeScore ?? 'n/a'}/100${derived.aligned ? ' (ALIGNED)' : ''}
- Active signals (with provenance): ${derived.signalsWithProvenance ?? stock.signals?.join(', ') ?? 'none'}
- Solvency flags: ${derived.solvencyFlags ?? 'none'}
- Thesis (user-supplied): ${stock.thesis ?? 'not provided'}

In the ANALYST VIEW section cover: catalyst (6-18mo), single biggest risk, compounder-vs-trade read, whether the DCF upside rests on a heroic growth assumption, whether any speculative buzz is justified or a trap, one historical comparable (tagged unverified), and a verdict with short-term vs long-term horizon.`;

  return { system, user };
}

/**
 * Lightweight post-check on the AI's returned text. Can't catch every
 * hallucination, but flags the obvious structural failures.
 */
function validateAIResponse(text) {
  const issues = [];
  if (!/FACTS/i.test(text)) issues.push('Missing FACTS section — model ignored grounding structure');
  if (!/ANALYST VIEW/i.test(text)) issues.push('Missing ANALYST VIEW section');
  // crude check for fabricated-looking specifics in the FACTS half
  const factsHalf = text.split(/ANALYST VIEW/i)[0] || '';
  if (/\$\d{2,}(\.\d+)?\s?(million|billion|m|bn)\b/i.test(factsHalf) && !/not provided/i.test(factsHalf)) {
    issues.push('FACTS section contains dollar magnitudes that may not have been supplied — verify against input');
  }
  return {
    ok: issues.length === 0,
    issues,
    banner: issues.length ? `△ AI OUTPUT CHECK: ${issues.join('; ')}` : null,
  };
}

// ============================ C. PROVENANCE =================================
/**
 * Wrap each signal with where it came from + how fresh. In the live build these
 * source/asOf values come from the actual API (SEC EDGAR, USPTO, etc).
 */
const SIGNAL_SOURCES = {
  govt_contract:     { source: 'USASpending.gov / agency award feed', verifiable: true },
  insider_buy:       { source: 'SEC EDGAR Form 4', verifiable: true },
  patent_surge:      { source: 'USPTO PatentsView', verifiable: true },
  academic_pipeline: { source: 'arXiv / Semantic Scholar', verifiable: false },
  etf_threshold:     { source: 'Derived (market cap vs index rules)', verifiable: false },
  supply_chain:      { source: 'Manual / inferred mapping', verifiable: false },
};

function annotateSignals(signals, asOfMap = {}) {
  return signals.map(sig => {
    const meta = SIGNAL_SOURCES[sig] || { source: 'unknown', verifiable: false };
    const asOf = asOfMap[sig];
    const ageDays = asOf ? Math.round((Date.now() - new Date(asOf)) / 86_400_000) : null;
    const stale = ageDays != null && ageDays > RESEARCH_CONFIG.maxSignalAgeDays;
    return {
      signal: sig,
      source: meta.source,
      verifiable: meta.verifiable,          // is this a hard filing or a soft inference?
      asOf: asOf || 'date unknown',
      ageDays,
      stale,
      label: `${sig} [${meta.verifiable ? 'VERIFIABLE' : 'INFERRED'}, ${meta.source}${ageDays!=null ? `, ${ageDays}d old${stale?' ⚠STALE':''}` : ''}]`,
    };
  });
}

module.exports = {
  RESEARCH_CONFIG,
  validateStockData,
  buildGroundedPrompt,
  validateAIResponse,
  annotateSignals,
  SIGNAL_SOURCES,
};
