/**
 * init-edgar.js — One-time CIK map population.
 * Fetches the full SEC company_tickers.json (~4MB) and saves cik-map.json.
 * Run once from the Beelink: node src/scripts/init-edgar.js
 * Also exposed as POST /api/admin/init-edgar on the server.
 */
const fs   = require('fs');
const path = require('path');

const CIK_CACHE = path.join(__dirname, '..', 'data', 'cik-map.json');
const SEC_UA    = { headers: { 'User-Agent': 'LucasINT/1.0 (contact: lucas@geojob.com)' } };

// Watchlist tickers — hardcoded so the most common ones survive even if SEC is slow
const CURATED = {
  ACLS:'0001113232', AMKR:'0001047435', CDNS:'0000813672', COHU:'0000021535',
  ENTG:'0001101302', ETN:'0000031462', FIX:'0000784977',  ICHR:'0001652535',
  IONQ:'0001802665', KLIC:'0000056047', LIN:'0001707092',  LITE:'0001606163',
  MOD:'0000067748',  MP:'0001801170',   MU:'0000723125',   ON:'0001097864',
  ONTO:'0000073309', POWI:'0000833640', PWR:'0001050915',  QRVO:'0001604778',
  ROK:'0001024478',  SNPS:'0000883241', SWKS:'0000004127', TER:'0000097210',
  UCTT:'0001275014', VRT:'0001780788',  WCC:'0001078928',
};

async function initEdgar() {
  console.log('[init-edgar] Loading curated CIK map for known watchlist tickers...');

  // Start with curated map so these always work even if SEC fetch fails
  let existing = {};
  try { existing = JSON.parse(fs.readFileSync(CIK_CACHE, 'utf8')); } catch { }
  const merged = { ...CURATED, ...existing };
  fs.writeFileSync(CIK_CACHE, JSON.stringify(merged));
  console.log(`[init-edgar] Curated map written: ${Object.keys(merged).length} entries`);

  // Try to fetch the full map from SEC in background (catches the remainder)
  console.log('[init-edgar] Fetching full company_tickers.json from SEC (may take 30-45s)...');
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 45000);
    const r = await fetch('https://www.sec.gov/files/company_tickers.json', {
      ...SEC_UA, signal: ctrl.signal
    });
    clearTimeout(timer);
    if (!r.ok) throw new Error(`SEC returned ${r.status}`);
    const raw = await r.json();
    const fullMap = {};
    for (const k of Object.keys(raw)) {
      const e = raw[k];
      if (e && e.ticker) fullMap[String(e.ticker).toUpperCase()] = String(e.cik_str).padStart(10, '0');
    }
    const full = { ...fullMap, ...CURATED }; // curated wins (our corrections override)
    fs.writeFileSync(CIK_CACHE, JSON.stringify(full));
    console.log(`[init-edgar] Full CIK map saved: ${Object.keys(full).length} tickers`);
    return { ok: true, count: Object.keys(full).length, source: 'sec+curated' };
  } catch(e) {
    console.warn(`[init-edgar] Full SEC fetch failed (${e.message}) — curated map still active`);
    return { ok: true, count: Object.keys(merged).length, source: 'curated-only', warn: e.message };
  }
}

if (require.main === module) {
  initEdgar().then(r => { console.log('[init-edgar] Result:', r); process.exit(0); })
    .catch(e => { console.error('[init-edgar] Fatal:', e.message); process.exit(1); });
}

module.exports = { initEdgar, CURATED };
