/**
 * backtest5y.js v2 — historical scoring backtest + large-scale weight search.
 *
 * v2 upgrades (accuracy without luck-amplification):
 *  - Universe: ALL US names with CIKs from the live screen (cap 900), not top-350
 *  - Snapshots QUARTERLY 2019-01 … 2025-04 (~26 entry dates)
 *  - 2,000 random weightings + 5 archetypes + baseline
 *  - THREE-WAY time split per horizon/cohort: 50% train → tune, 25% validation → select,
 *    25% TEST → reported untouched (the winner never saw it at any stage)
 *  - NULL DISTRIBUTION: % of all candidates beating baseline on TEST — the luck yardstick
 *  - STABILITY: winner jittered ±20% ten times; plateau = signal, spike = luck
 *  - Memory-safe: facts processed per-ticker then discarded (never 900 JSONs in RAM)
 *
 * HONEST LIMITS (in every output): survivorship (upper bounds), overlapping windows
 * autocorrelated, 5y horizon tiny-n, US-only (no PIT source for ASX).
 */
const { fetchHistory } = require('../util/yahoo');
const { fetchFactsCached, pitFundamentals } = require('../research/pit');
const { loadStore, saveStore } = require('../util/store');
const fs = require('fs');
const path = require('path');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

const VERSION = 2;
const MAX_TICKERS = 900;
const N_RANDOM = 2000;
const HORIZONS = { '1y': 365, '3y': 1095, '5y': 1825 };

// Quarterly snapshots 2019-01-01 .. 2025-04-01
const SNAP_DATES = (() => {
  const out = [];
  for (let y = 2019; y <= 2025; y++)
    for (const m of ['01', '04', '07', '10']) {
      if (y === 2025 && m > '04') break;
      out.push(`${y}-${m}-01`);
    }
  return out;
})();

// ── price helpers ────────────────────────────────────────────────────────────
function idxAt(h, dateMs) {
  let lo = 0, hi = h.dates.length - 1, ans = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (h.dates[m] <= dateMs) { ans = m; lo = m + 1; } else hi = m - 1; }
  return ans;
}
function retBetween(h, fromMs, toMs) {
  const a = idxAt(h, fromMs), b = idxAt(h, toMs);
  if (a < 0 || b < 0 || b <= a || !h.closes[a]) return null;
  if (Math.abs(h.dates[b] - toMs) > 45 * 86400000) return null;
  return +(((h.closes[b] - h.closes[a]) / h.closes[a]) * 100).toFixed(1);
}
function momBack(h, atMs, days) {
  const b = idxAt(h, atMs), a = idxAt(h, atMs - days * 86400000);
  if (a < 0 || b <= a || !h.closes[a]) return null;
  return +(((h.closes[b] - h.closes[a]) / h.closes[a]) * 100).toFixed(1);
}

// ── factors & scoring ────────────────────────────────────────────────────────
const FACTORS = ['growth', 'quality', 'value', 'momentum', 'relstr', 'solvency'];
function factorise(s) {
  return {
    growth:   s.revGrowth  != null ? clamp(s.revGrowth, -50, 150) / 1.5 : 0,
    quality:  (s.roe != null ? clamp(s.roe, -30, 50) : 0) + (s.grossMargin != null ? clamp(s.grossMargin, 0, 80) / 4 : 0),
    value:    (s.pe != null && s.pe > 0 ? clamp(60 - s.pe, -40, 55) : 0) + (s.fcfYield != null ? clamp(s.fcfYield * 4, -20, 30) : 0),
    momentum: s.mom6m != null ? clamp(s.mom6m, -50, 100) : 0,
    relstr:   s.relStrength != null ? clamp(s.relStrength, -40, 80) : 0,
    solvency: s.dToE != null ? clamp(20 - 10 * s.dToE, -30, 20) : 0,
  };
}
const scoreW = (f, w) => FACTORS.reduce((a, k) => a + f[k] * w[k], 0);

const BASELINE_W = { growth: .20, quality: .20, value: .15, momentum: .25, relstr: .10, solvency: .10 };
const ARCHETYPES = {
  'momentum-heavy': { growth: .10, quality: .10, value: .05, momentum: .50, relstr: .20, solvency: .05 },
  'growth-heavy':   { growth: .45, quality: .15, value: .05, momentum: .20, relstr: .10, solvency: .05 },
  'quality-heavy':  { growth: .15, quality: .45, value: .15, momentum: .10, relstr: .05, solvency: .10 },
  'value-heavy':    { growth: .10, quality: .20, value: .45, momentum: .10, relstr: .05, solvency: .10 },
  'balanced':       { growth: .17, quality: .17, value: .17, momentum: .17, relstr: .16, solvency: .16 },
};
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function randW(rng) {
  const raw = FACTORS.map(() => -Math.log(rng()));
  const sum = raw.reduce((a, b) => a + b, 0);
  return Object.fromEntries(FACTORS.map((k, i) => [k, +(raw[i] / sum).toFixed(3)]));
}
function jitterW(w, rng) {
  const raw = FACTORS.map(k => Math.max(0.001, w[k] * (0.8 + 0.4 * rng())));
  const sum = raw.reduce((a, b) => a + b, 0);
  return Object.fromEntries(FACTORS.map((k, i) => [k, raw[i] / sum]));
}

// ── evaluation ───────────────────────────────────────────────────────────────
// snapsByDate: date -> array of snap rows (with precomputed .fx = factorise(s))
function evalOnDates(w, snapsByDate, horizon, cohortFlag, dates) {
  const perDate = [];
  for (const date of dates) {
    const snaps = snapsByDate[date] || [];
    const cohort = snaps.filter(s => s.hasRevenue === cohortFlag && s[`fwd${horizon}`] != null);
    if (cohort.length < 8) continue;
    const bench = cohort.reduce((a, s) => a + s[`fwd${horizon}`], 0) / cohort.length;
    const N = Math.max(5, Math.floor(cohort.length * 0.15));
    const picks = cohort.map(s => ({ s, sc: scoreW(s.fx, w) })).sort((a, b) => b.sc - a.sc).slice(0, N);
    const port = picks.reduce((a, p) => a + p.s[`fwd${horizon}`], 0) / picks.length;
    perDate.push(+(port - bench).toFixed(1));
  }
  if (!perDate.length) return null;
  return {
    avgExcess: +(perDate.reduce((a, b) => a + b, 0) / perDate.length).toFixed(1),
    hitRate: +(perDate.filter(x => x > 0).length / perDate.length).toFixed(2),
    periods: perDate.length,
  };
}

// ── main ─────────────────────────────────────────────────────────────────────
async function runBacktest5y() {
  const store = loadStore();
  const cikMap = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'cik-map.json'), 'utf8'));
  let entries = (store.screenResults || [])
    .filter(r => r && r.ticker && !r.ticker.includes('.') && cikMap[r.ticker])
    .map(r => ({ t: r.ticker, sector: r.sector, mcap: r.marketCap || 0, cik: cikMap[r.ticker] }));
  const seen = new Set();
  entries = entries.filter(e => !seen.has(e.t) && seen.add(e.t));
  entries.sort((a, b) => b.mcap - a.mcap);
  entries = entries.slice(0, MAX_TICKERS);
  if (entries.length < 40) throw new Error(`only ${entries.length} US tickers with CIKs — run /rebuild first`);
  console.log(`[bt5y v2] universe: ${entries.length} US names, ${SNAP_DATES.length} quarterly snapshots`);

  // 1. Stream per ticker: fetch → compute all-date snapshots → discard facts
  const snapsByDate = {};
  for (const d of SNAP_DATES) snapsByDate[d] = [];
  let done = 0, usable = 0;
  for (const e of entries) {
    let h = null, facts = null;
    try { h = await fetchHistory(e.t, 10); } catch { }
    if (h && h.dates && h.dates.length > 60) {
      try { facts = await fetchFactsCached(e.cik); } catch { }
      if (facts) {
        let any = false;
        for (const dateISO of SNAP_DATES) {
          const dMs = new Date(dateISO).getTime();
          const i = idxAt(h, dMs);
          if (i < 30 || !h.closes[i]) continue;
          const pit = pitFundamentals(facts, dateISO);
          if (!pit) continue;
          const px = h.closes[i];
          const s = {
            ticker: e.t, sector: e.sector,
            hasRevenue: pit.hasRevenue === null ? true : pit.hasRevenue,
            revGrowth: pit.revGrowth, grossMargin: pit.grossMargin, roe: pit.roe, dToE: pit.dToE,
            pe: (pit.eps != null && pit.eps !== 0) ? +(px / pit.eps).toFixed(1) : null,
            fcfYield: (pit.fcfPerShare != null && px) ? +((pit.fcfPerShare / px) * 100).toFixed(1) : null,
            mom6m: momBack(h, dMs, 183), mom12m: momBack(h, dMs, 365),
          };
          for (const [hz, days] of Object.entries(HORIZONS)) s[`fwd${hz}`] = retBetween(h, dMs, dMs + days * 86400000);
          snapsByDate[dateISO].push(s);
          any = true;
        }
        if (any) usable++;
      }
    }
    facts = null; h = null; // free before next ticker
    await sleep(220);
    if (++done % 100 === 0) console.log(`[bt5y v2] data ${done}/${entries.length} (${usable} usable)`);
  }

  // sector rel-strength + precompute factor vectors
  for (const dateISO of SNAP_DATES) {
    const rows = snapsByDate[dateISO];
    const bySec = {};
    rows.forEach(r => { if (r.mom6m != null) (bySec[r.sector] = bySec[r.sector] || []).push(r.mom6m); });
    const secAvg = Object.fromEntries(Object.entries(bySec).map(([k, v]) => [k, v.reduce((a, b) => a + b, 0) / v.length]));
    rows.forEach(r => {
      r.relStrength = (r.mom6m != null && secAvg[r.sector] != null) ? +(r.mom6m - secAvg[r.sector]).toFixed(1) : null;
      r.fx = factorise(r);
    });
    console.log(`[bt5y v2] ${dateISO}: ${rows.length} snaps (${rows.filter(r => r.hasRevenue === false).length} pre-rev)`);
  }

  // 2. Candidates
  const rng = mulberry32(42);
  const candidates = [...Object.entries(ARCHETYPES)];
  for (let i = 0; i < N_RANDOM; i++) candidates.push([`rand-${i}`, randW(rng)]);

  const out = {
    version: VERSION, asOf: new Date().toISOString(), universe: entries.length, usable,
    snapDates: SNAP_DATES, candidates: candidates.length + 1, results: {},
    caveats: [
      'Survivorship bias: universe is today\'s survivors — all returns are optimistic upper bounds.',
      'Overlapping quarterly windows are autocorrelated; effective sample is smaller than period count.',
      '5y horizon: few non-overlapping samples — indicative only.',
      'US names only (EDGAR point-in-time). ASX/international not testable historically.',
      `Winner selected on validation split from ${candidates.length + 1} candidates; TEST split untouched by selection. Null distribution shows the luck scale.`,
    ],
  };

  // 3. Per horizon/cohort: 3-way split → tune, select, test + null + stability
  for (const hz of Object.keys(HORIZONS)) {
    for (const [cohortName, flag] of [['post-rev', true], ['pre-rev', false]]) {
      const key = `${hz}/${cohortName}`;
      // dates with enough cohort data for this horizon
      const okDates = SNAP_DATES.filter(d =>
        (snapsByDate[d] || []).filter(s => s.hasRevenue === flag && s[`fwd${hz}`] != null).length >= 8);
      if (okDates.length < 4) { out.results[key] = { note: `insufficient cohort data (${okDates.length} usable periods)` }; continue; }
      const nTr = Math.max(2, Math.floor(okDates.length * 0.5));
      const nVa = Math.max(1, Math.floor(okDates.length * 0.25));
      const trainD = okDates.slice(0, nTr), valD = okDates.slice(nTr, nTr + nVa), testD = okDates.slice(nTr + nVa);
      if (!testD.length) { out.results[key] = { note: 'no untouched test periods for this horizon' }; continue; }

      const baseline = {
        train: evalOnDates(BASELINE_W, snapsByDate, hz, flag, trainD),
        val:   evalOnDates(BASELINE_W, snapsByDate, hz, flag, valD),
        test:  evalOnDates(BASELINE_W, snapsByDate, hz, flag, testD),
      };

      // tune on train → top 25 → select on validation
      const trained = [];
      for (const [name, w] of candidates) {
        const r = evalOnDates(w, snapsByDate, hz, flag, trainD);
        if (r) trained.push({ name, w, train: r });
      }
      trained.sort((a, b) => b.train.avgExcess - a.train.avgExcess);
      const finalists = trained.slice(0, 25)
        .map(c => ({ ...c, val: evalOnDates(c.w, snapsByDate, hz, flag, valD) }))
        .filter(c => c.val);
      finalists.sort((a, b) => b.val.avgExcess - a.val.avgExcess);
      const winner = finalists[0] || null;
      const winnerTest = winner ? evalOnDates(winner.w, snapsByDate, hz, flag, testD) : null;

      // null distribution: ALL candidates on the test split (not used for selection — pure yardstick)
      let beat = 0, n = 0; const testVals = [];
      for (const [, w] of candidates) {
        const r = evalOnDates(w, snapsByDate, hz, flag, testD);
        if (!r) continue;
        n++; testVals.push(r.avgExcess);
        if (baseline.test && r.avgExcess > baseline.test.avgExcess) beat++;
      }
      testVals.sort((a, b) => a - b);
      const nullStats = n ? {
        pctBeatBaseline: +((beat / n) * 100).toFixed(0),
        medianTest: testVals[Math.floor(n / 2)],
      } : null;

      // stability: jitter winner ±20% × 10
      let stability = null;
      if (winner && winnerTest) {
        const js = [];
        for (let i = 0; i < 10; i++) {
          const r = evalOnDates(jitterW(winner.w, rng), snapsByDate, hz, flag, testD);
          if (r) js.push(r.avgExcess);
        }
        if (js.length) stability = { meanTest: +(js.reduce((a, b) => a + b, 0) / js.length).toFixed(1), minTest: Math.min(...js) };
      }

      out.results[key] = {
        periods: { train: trainD.length, val: valD.length, test: testD.length },
        baseline,
        winner: winner ? { name: winner.name, weights: winner.w, train: winner.train, val: winner.val, test: winnerTest } : null,
        runnersUp: finalists.slice(1, 5).map(c => ({ name: c.name, val: c.val.avgExcess })),
        null: nullStats, stability,
      };
      console.log(`[bt5y v2] ${key}: base test ${baseline.test?.avgExcess ?? '—'}% | winner(${winner?.name}) test ${winnerTest?.avgExcess ?? '—'}% | null beat ${nullStats?.pctBeatBaseline ?? '—'}%`);
    }
  }

  store.backtest5y = out;
  saveStore(store);
  return out;
}

if (require.main === module) runBacktest5y().then(r => { console.log(JSON.stringify(r.results, null, 1)); process.exit(0); });
module.exports = { runBacktest5y };
