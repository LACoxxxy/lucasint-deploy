/**
 * backtest5y.js — "If the scoring system picked stocks 5 years ago, how did they do?"
 * Then: which metric weightings would have picked the BEST performers over 1y/3y/5y —
 * evaluated separately for pre-revenue and post-revenue cohorts.
 *
 * METHOD
 *  - US names only (EDGAR point-in-time fundamentals; filed-date respected → no look-ahead)
 *  - Snapshot dates every 6 months, 2019-07 … 2025-01
 *  - At each date: PIT fundamentals + price momentum + sector rel-strength → parameterised score
 *  - Portfolio = top picks per cohort per date → forward 1y/3y/5y excess return vs cohort average
 *  - Weight search: 5 archetypes + 150 random weightings, tuned IN-SAMPLE (entries ≤ 2022-01),
 *    winner re-tested OUT-OF-SAMPLE (entries ≥ 2022-07) — reported separately, no cheating.
 *
 * HONEST LIMITS (attached to every result):
 *  - Survivorship: universe = today's survivors; dead companies absent → returns are UPPER bounds
 *  - 5y horizon has ~1 non-overlapping sample → indicative only
 *  - Overlapping 6-monthly windows are autocorrelated → effective n is smaller than it looks
 */
const { fetchHistory } = require('../util/yahoo');
const { fetchFactsCached, pitFundamentals } = require('../research/pit');
const { loadStore, saveStore } = require('../util/store');
const fs = require('fs');
const path = require('path');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

const SNAP_DATES = ['2019-07-01','2020-01-01','2020-07-01','2021-01-01','2021-07-01','2022-01-01','2022-07-01','2023-01-01','2023-07-01','2024-01-01','2024-07-01','2025-01-01'];
const IN_SAMPLE_CUTOFF = '2022-01-02';   // entries before this train the weights
const HORIZONS = { '1y': 365, '3y': 1095, '5y': 1825 };
const MAX_TICKERS = 350;

// ── price helpers ────────────────────────────────────────────────────────────
function idxAt(h, dateMs) { // last index with date <= target
  let lo = 0, hi = h.dates.length - 1, ans = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (h.dates[m] <= dateMs) { ans = m; lo = m + 1; } else hi = m - 1; }
  return ans;
}
function retBetween(h, fromMs, toMs) {
  const a = idxAt(h, fromMs), b = idxAt(h, toMs);
  if (a < 0 || b < 0 || b <= a || !h.closes[a]) return null;
  // require the end price to be within 45 days of target (else series ended — delisted/too recent)
  if (Math.abs(h.dates[b] - toMs) > 45 * 86400000) return null;
  return +(((h.closes[b] - h.closes[a]) / h.closes[a]) * 100).toFixed(1);
}
function momBack(h, atMs, days) {
  const b = idxAt(h, atMs), a = idxAt(h, atMs - days * 86400000);
  if (a < 0 || b <= a || !h.closes[a]) return null;
  return +(((h.closes[b] - h.closes[a]) / h.closes[a]) * 100).toFixed(1);
}

// ── parameterised scoring (mirrors the live composite's factor families) ────
const FACTORS = ['growth', 'quality', 'value', 'momentum', 'relstr', 'solvency'];
function factorise(s) {
  return {
    growth:   s.revGrowth  != null ? clamp(s.revGrowth, -50, 150) / 1.5 : 0,
    quality:  (s.roe != null ? clamp(s.roe, -30, 50) : 0) + (s.grossMargin != null ? clamp(s.grossMargin, 0, 80) / 4 : 0),
    value:    (s.pe != null && s.pe > 0 ? clamp(60 - s.pe, -40, 55) : 0) + (s.fcfYield != null ? clamp(s.fcfYield * 4, -20, 30) : 0),
    momentum: s.mom6m != null ? clamp(s.mom6m, -50, 100) : 0,
    relstr:   s.relStrength != null ? clamp(s.relStrength, -40, 80) : 0,
    solvency: s.dToE != null ? clamp(20 - 10 * s.dToE, -30, 20) : 0,
  };
}
const scoreW = (f, w) => FACTORS.reduce((a, k) => a + f[k] * w[k], 0);

const BASELINE_W = { growth: .20, quality: .20, value: .15, momentum: .25, relstr: .10, solvency: .10 }; // ≈ current system's emphasis
const ARCHETYPES = {
  'momentum-heavy': { growth: .10, quality: .10, value: .05, momentum: .50, relstr: .20, solvency: .05 },
  'growth-heavy':   { growth: .45, quality: .15, value: .05, momentum: .20, relstr: .10, solvency: .05 },
  'quality-heavy':  { growth: .15, quality: .45, value: .15, momentum: .10, relstr: .05, solvency: .10 },
  'value-heavy':    { growth: .10, quality: .20, value: .45, momentum: .10, relstr: .05, solvency: .10 },
  'balanced':       { growth: .17, quality: .17, value: .17, momentum: .17, relstr: .16, solvency: .16 },
};
function randW(rng) {
  const raw = FACTORS.map(() => -Math.log(rng()));
  const sum = raw.reduce((a, b) => a + b, 0);
  return Object.fromEntries(FACTORS.map((k, i) => [k, +(raw[i] / sum).toFixed(3)]));
}
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

// ── portfolio evaluation ─────────────────────────────────────────────────────
function evalWeights(w, snapsByDate, horizon, cohortFlag, dateFilter) {
  const perDate = [];
  for (const [date, snaps] of Object.entries(snapsByDate)) {
    if (!dateFilter(date)) continue;
    const cohort = snaps.filter(s => s.hasRevenue === cohortFlag && s[`fwd${horizon}`] != null);
    if (cohort.length < 8) continue;
    const bench = cohort.reduce((a, s) => a + s[`fwd${horizon}`], 0) / cohort.length;
    const N = Math.max(5, Math.floor(cohort.length * 0.15));
    const picks = cohort.map(s => ({ s, sc: scoreW(factorise(s), w) })).sort((a, b) => b.sc - a.sc).slice(0, N);
    const port = picks.reduce((a, p) => a + p.s[`fwd${horizon}`], 0) / picks.length;
    perDate.push({ date, n: cohort.length, picks: N, port: +port.toFixed(1), bench: +bench.toFixed(1), excess: +(port - bench).toFixed(1) });
  }
  if (!perDate.length) return null;
  const avgExcess = +(perDate.reduce((a, d) => a + d.excess, 0) / perDate.length).toFixed(1);
  const hitRate = +(perDate.filter(d => d.excess > 0).length / perDate.length).toFixed(2);
  return { avgExcess, hitRate, periods: perDate.length, detail: perDate };
}

// ── main ─────────────────────────────────────────────────────────────────────
async function runBacktest5y(progress = () => {}) {
  const store = loadStore();
  const cikMap = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'cik-map.json'), 'utf8'));
  let entries = (store.screenResults || [])
    .filter(r => r && r.ticker && !r.ticker.includes('.') && cikMap[r.ticker])
    .map(r => ({ t: r.ticker, sector: r.sector, mcap: r.marketCap || 0, cik: cikMap[r.ticker] }));
  const seen = new Set();
  entries = entries.filter(e => !seen.has(e.t) && seen.add(e.t));
  entries.sort((a, b) => b.mcap - a.mcap);
  entries = entries.slice(0, MAX_TICKERS);
  if (entries.length < 40) throw new Error(`only ${entries.length} US tickers with CIKs — run /rebuild first`);
  console.log(`[bt5y] universe: ${entries.length} US names (survivorship caveat applies)`);

  // 1. Prices (10y) + EDGAR facts, cached
  const hist = {}, facts = {};
  let done = 0;
  for (const e of entries) {
    try { hist[e.t] = await fetchHistory(e.t, 10); } catch { }
    try { facts[e.t] = await fetchFactsCached(e.cik); } catch { }
    await sleep(250);
    if (++done % 50 === 0) { console.log(`[bt5y] data ${done}/${entries.length}`); progress(done, entries.length); }
  }

  // 2. Build snapshots per date
  const snapsByDate = {};
  for (const dateISO of SNAP_DATES) {
    const dMs = new Date(dateISO).getTime();
    const rows = [];
    for (const e of entries) {
      const h = hist[e.t]; const f = facts[e.t];
      if (!h || !f || !h.dates?.length) continue;
      const i = idxAt(h, dMs);
      if (i < 30 || !h.closes[i]) continue;               // not listed yet at snapshot
      const pit = pitFundamentals(f, dateISO);
      if (!pit) continue;                                  // nothing filed by then
      const px = h.closes[i];
      const s = {
        ticker: e.t, sector: e.sector,
        hasRevenue: pit.hasRevenue === null ? true : pit.hasRevenue, // unknown → treat as post-rev (conservative)
        revGrowth: pit.revGrowth, grossMargin: pit.grossMargin, roe: pit.roe, dToE: pit.dToE,
        pe: (pit.eps != null && pit.eps !== 0) ? +(px / pit.eps).toFixed(1) : null,
        fcfYield: (pit.fcfPerShare != null && px) ? +((pit.fcfPerShare / px) * 100).toFixed(1) : null,
        mom6m: momBack(h, dMs, 183), mom12m: momBack(h, dMs, 365),
      };
      for (const [hz, days] of Object.entries(HORIZONS)) s[`fwd${hz}`] = retBetween(h, dMs, dMs + days * 86400000);
      rows.push(s);
    }
    // sector relative strength
    const bySec = {};
    rows.forEach(r => { if (r.mom6m != null) (bySec[r.sector] = bySec[r.sector] || []).push(r.mom6m); });
    const secAvg = Object.fromEntries(Object.entries(bySec).map(([k, v]) => [k, v.reduce((a, b) => a + b, 0) / v.length]));
    rows.forEach(r => { r.relStrength = (r.mom6m != null && secAvg[r.sector] != null) ? +(r.mom6m - secAvg[r.sector]).toFixed(1) : null; });
    snapsByDate[dateISO] = rows;
    console.log(`[bt5y] ${dateISO}: ${rows.length} snapshots (${rows.filter(r => r.hasRevenue === false).length} pre-rev)`);
  }

  // 3. Baseline + weight search, per horizon per cohort
  const inS = d => d < IN_SAMPLE_CUTOFF, ooS = d => d >= IN_SAMPLE_CUTOFF, all = () => true;
  const rng = mulberry32(42);
  const candidates = [['baseline', BASELINE_W], ...Object.entries(ARCHETYPES)];
  for (let i = 0; i < 150; i++) candidates.push([`rand-${i}`, randW(rng)]);

  const out = { asOf: new Date().toISOString(), universe: entries.length, snapDates: SNAP_DATES, results: {}, caveats: [
    'Survivorship bias: universe is today\'s survivors — dead/delisted names absent, so all returns are optimistic upper bounds.',
    '5y horizon ≈ one non-overlapping sample — indicative only, not statistics.',
    'Overlapping 6-month windows are autocorrelated; effective sample smaller than period count.',
    'US names only (EDGAR point-in-time). International cohort not testable without PIT filings.',
  ] };

  for (const hz of Object.keys(HORIZONS)) {
    for (const [cohortName, flag] of [['post-rev', true], ['pre-rev', false]]) {
      const key = `${hz}/${cohortName}`;
      const baseline = evalWeights(BASELINE_W, snapsByDate, hz, flag, all);
      if (!baseline) { out.results[key] = { note: 'insufficient cohort data' }; continue; }
      // train in-sample
      let best = null;
      for (const [name, w] of candidates) {
        const r = evalWeights(w, snapsByDate, hz, flag, inS);
        if (r && (!best || r.avgExcess > best.is.avgExcess)) best = { name, w, is: r };
      }
      const bestOOS = best ? evalWeights(best.w, snapsByDate, hz, flag, ooS) : null;
      out.results[key] = {
        baseline: { avgExcess: baseline.avgExcess, hitRate: baseline.hitRate, periods: baseline.periods },
        best: best ? { name: best.name, weights: best.w, inSample: { avgExcess: best.is.avgExcess, hitRate: best.is.hitRate, periods: best.is.periods },
          outSample: bestOOS ? { avgExcess: bestOOS.avgExcess, hitRate: bestOOS.hitRate, periods: bestOOS.periods } : { note: 'no OOS periods for this horizon' } } : null,
      };
      console.log(`[bt5y] ${key}: baseline ${baseline.avgExcess}% | best(${best?.name}) IS ${best?.is.avgExcess}% OOS ${bestOOS?.avgExcess ?? '—'}%`);
    }
  }

  store.backtest5y = out;
  saveStore(store);
  return out;
}

if (require.main === module) runBacktest5y().then(r => { console.log(JSON.stringify(r.results, null, 1)); process.exit(0); });
module.exports = { runBacktest5y };
