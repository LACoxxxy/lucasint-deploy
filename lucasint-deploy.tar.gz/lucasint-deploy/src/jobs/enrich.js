/**
 * enrich.js — WEEKLY slow-signal enrichment.
 *
 * These sources move slowly (Form 4 clusters, patent grants, contract awards, moat
 * narrative), so running them on every 3×/day screen would waste API budget and hit
 * rate limits. This job runs once a week, computes the signals, and writes them to
 * store.enrichments[ticker]. The fast screen job then merges them in when scoring.
 *
 * Every source degrades gracefully: a failure for one ticker/source leaves that field
 * absent (pending), never fabricated, and never blocks the others.
 */
require('dotenv').config({ path: require('path').join(__dirname, '..', '..', '.env') }); // Claude key for long-term layer
const { insiderActivity, insiderScore } = require('../insider');
const { fetchShortInterest } = require('../util/short-interest');
const { fetchPatentActivity, patentScore } = require('../util/patents');
const { fetchGovtContracts, govtScore } = require('../util/govt-contracts');
const { assessLongTerm, longTermConviction } = require('../util/longterm-claude');
const { assessMoat } = require('../moat');
const { fetchFundamentals } = require('../util/yahoo');
const { loadStore, saveStore } = require('../util/store');
const watchlist = require('../data/watchlist.json');
const meta = require('../data/ticker-meta.json');

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function runEnrich({ withLongTerm = true } = {}) {
  const tickers = Object.entries(watchlist).flatMap(([sector, ts]) => ts.map(t => ({ t, sector })));
  const store = loadStore();
  const enrichments = store.enrichments || {};
  console.log(`  enrich: ${tickers.length} tickers (weekly slow signals)…`);

  for (const { t, sector } of tickers) {
    const name = meta[t]?.name || t;
    const e = { _asOf: new Date().toISOString() };
    try {
      const insider = await insiderActivity(t).catch(() => null);
      if (insider) { const s = insiderScore(insider); e.insider = insider; e.insiderPts = s.pts; e.insiderNote = s.note; }
      await sleep(400);

      const short = await fetchShortInterest(t, meta[t]?.floatShares || null).catch(() => null);
      if (short && short.shortPctFloat != null) e.shortPctFloat = short.shortPctFloat;
      await sleep(400);

      const patents = await fetchPatentActivity(name).catch(() => null);
      if (patents) { const s = patentScore(patents); e.patents = patents; e.patentPts = s.pts; e.patentNote = s.note; }
      await sleep(400);

      const govt = await fetchGovtContracts(name).catch(() => null);
      if (govt) { const s = govtScore(govt); e.govt = govt; e.govtPts = s.pts; e.govtNote = s.note; }
      await sleep(400);

      if (withLongTerm) {
        const f = await fetchFundamentals(t).catch(() => ({}));
        const moat = assessMoat(f);
        const qual = await assessLongTerm(t, name, sector).catch(() => null);
        e.longTerm = { moat, qualitative: qual };
        e.longTermConviction = longTermConviction(moat, qual);
        await sleep(600);
      }
      enrichments[t] = e;
      console.log(`  enrich: ${t} — insider ${e.insiderPts||0} patents ${e.patentPts||0} govt ${e.govtPts||0} LTconv ${e.longTermConviction?.score ?? 'n/a'}`);
    } catch (err) { console.error(`  enrich: ${t} — ${err.message}`); enrichments[t] = { ...enrichments[t], _error: err.message }; }
  }
  store.enrichments = enrichments; store.enrichAsOf = new Date().toISOString();
  saveStore(store);
  return enrichments;
}

if (require.main === module) runEnrich().then(() => process.exit(0));
module.exports = { runEnrich };
