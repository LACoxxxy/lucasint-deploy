/**
 * screen.js — Dynamic screener: reads universe.json (built by universe.js from
 * EDGAR SIC sweeps + ETF seeds) instead of a static watchlist.
 *
 * Screens in batches of 20 with pacing to respect rate limits.
 * EDGAR fundamentals are cached per-ticker (24h TTL) so 3x-daily runs
 * only re-fetch price quotes and buzz — keeping each run fast.
 */
const { fetchQuote, fetchFundamentals, fetchHistory } = require('../util/yahoo');
const { score, momFromHistory, realizedVol } = require('../scoring');
const { sentimentDirection } = require('../sentiment-direction');
const { fetchBuzz }   = require('../util/buzz');
const { assessMoat }  = require('../moat');
const { loadStore, saveStore } = require('../util/store');
const { dataFreshness }        = require('../util/market-status');
const { getUniverse }          = require('../util/universe');
const meta = require('../data/ticker-meta.json');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const BATCH  = 12;    // tickers per batch — gentler on Yahoo's crumb endpoint
const DELAY  = 2500;  // ms between batches
const FUND_TTL = 24 * 3600 * 1000; // 24h cache for fundamentals
const FUND_FIELDS = ['revGrowth', 'grossMargin', 'roic', 'fcfPerShare', 'pe', 'debtToEquity'];
const fundRichness = d => FUND_FIELDS.filter(k => d && d[k] != null).length + (d && d.roe != null ? 1 : 0);

async function runScreen() {
  // ── 1. Load universe ───────────────────────────────────────────────────
  const universe = await getUniverse();
  const tickers = Object.entries(universe); // [[ticker, {name, sector, cik, source}], ...]
  console.log(`[screen] Universe: ${tickers.length} tickers from EDGAR + seeds`);

  // ── 2. Load caches ─────────────────────────────────────────────────────
  const store = loadStore();
  const fundCache  = store.fundCache  || {};  // ticker → {data, cachedAt}
  // Self-heal: purge poisoned entries (failed fetches that got cached as empty)
  let purged = 0;
  for (const [k, v] of Object.entries(fundCache)) {
    if (fundRichness(v && v.data) < 2) { delete fundCache[k]; purged++; }
  }
  if (purged) console.log(`[screen] purged ${purged} empty cached fundamentals — will refetch`);
  const prevResult = {};                       // ticker → last screen row (for score continuity)
  for (const r of (store.screenResults || [])) prevResult[r.ticker] = r;

  const rows = [];
  const bySector = {};

  // ── 3. Screen in batches ───────────────────────────────────────────────
  for (let i = 0; i < tickers.length; i += BATCH) {
    const batch = tickers.slice(i, i + BATCH);
    await Promise.all(batch.map(async ([t, info]) => {
      try {
        const q = await fetchQuote(t);
        if (!q.price) return; // unlisted / delisted — skip silently

        // EDGAR fundamentals: use cache if fresh, else fetch
        // Pass the full quote object so Yahoo-sourced PE/marketCap can serve as fallback for international tickers
        let f = {};
        const cached = fundCache[t];
        if (cached && (Date.now() - cached.cachedAt) < FUND_TTL) {
          f = cached.data;
          // Still patch in fresh Yahoo quote fields (PE can change daily)
          if (q.pe != null && f.pe == null) f.pe = q.pe;
          if (q.marketCap != null && f.marketCap == null) f.marketCap = q.marketCap;
        } else {
          await sleep(Math.random() * 1500);   // stagger within batch — avoids 429 bursts
          f = await fetchFundamentals(t, q).catch(e => {
            console.warn(`  fund ${t}: ${e.message}`);
            return {};
          });
          // Only cache results with real data — failures retry on the next run
          if (fundRichness(f) >= 2) fundCache[t] = { data: f, cachedAt: Date.now() };
        }

        const h   = await fetchHistory(t, 3).catch(() => null);
        const m1  = momFromHistory(h, 21);
        const priceConfirm = m1 == null ? null : Math.max(-1, Math.min(1, m1 / 15));
        const bz  = await fetchBuzz(t).catch(() => ({ activity: null, socialPolarity: null, putCallRatio: null, source: null }));
        const buzz = sentimentDirection({ activity: bz.activity, putCallRatio: bz.putCallRatio, socialPolarity: bz.socialPolarity, priceConfirm });

        const sector = info.sector;
        const row = {
          ticker: t, sector,
          name: meta[t]?.name || (info.name && info.name !== t ? info.name : null) || q.shortName || t,
          discoveredBy: info.source, // 'seed' | 'edgar'
          price: q.price, currency: q.currency,
          pe: f.pe ?? null, eps: f.eps ?? null,
          revGrowth: f.revGrowth ?? null, grossMargin: f.grossMargin ?? null,
          debtToEquity: f.debtToEquity ?? null, currentRatio: f.currentRatio ?? null,
          roic: f.roic ?? null, roe: f.roe ?? null, fcfPerShare: f.fcfPerShare ?? null,
          fcfGrowth5y: f.fcfGrowth5y ?? null, freeCashflow: f.freeCashflow ?? null,
          shortPctFloat: f.shortPctFloat ?? null, marketCap: f.marketCap ?? null,
          fundSource: f._source ?? null, fundAsOf: f._asOf ?? null,
          mom1m: m1, mom3m: momFromHistory(h, 63),
          mom6m: momFromHistory(h, 126), mom12m: momFromHistory(h, 251),
          volatility: realizedVol(h),
          buzz, buzzActivity: bz.activity, socialPolarity: bz.socialPolarity,
          putCallRatio: bz.putCallRatio, priceConfirm, buzzSource: bz.source,
          _fetchedAt: q._fetchedAt,
        };

        row.moat = assessMoat(f);
        const fresh = dataFreshness(t, q._fetchedAt);
        row.market = fresh.market; row.marketOpen = fresh.open;

        // Enrich with weekly signals (insider/patent/govt) if available
        const e = (store.enrichments || {})[t];
        if (e) {
          Object.assign(row, {
            insiderPts: e.insiderPts, insiderNote: e.insiderNote,
            patentPts: e.patentPts,   patentNote: e.patentNote,
            govtPts: e.govtPts,       govtNote: e.govtNote,
            insider: e.insider, patents: e.patents, govt: e.govt,
            longTerm: e.longTerm, longTermConviction: e.longTermConviction,
          });
          if (e.shortPctFloat != null && row.shortPctFloat == null) row.shortPctFloat = e.shortPctFloat;
        }

        (bySector[sector] = bySector[sector] || []).push(row);
        rows.push(row);
      } catch (e) {
        // Don't push error rows for universe stocks — too noisy at 400+ scale
        if (e.message && !e.message.includes('No fundamentals')) {
          console.warn(`  screen: ${t} — ${e.message.slice(0, 80)}`);
        }
      }
    }));

    if (i + BATCH < tickers.length) await sleep(DELAY);
    console.log(`  screen: ${Math.min(i + BATCH, tickers.length)}/${tickers.length} processed…`);
  }

  // ── 3b. Second-chance pass: retry thin fundamentals slowly ─────────────
  // Rows that came through with <2 fundamentals were likely rate-limited, not
  // truly data-less. Retry them sequentially with generous spacing.
  const thin = rows.filter(r => fundRichness(r) < 2);
  if (thin.length) {
    console.log(`[screen] second-chance pass: retrying ${thin.length} thin rows…`);
    let recovered = 0;
    for (const row of thin.slice(0, 300)) {
      await sleep(400);
      try {
        const f = await fetchFundamentals(row.ticker, { price: row.price, pe: row.pe, eps: row.eps, marketCap: row.marketCap, _fetchedAt: row._fetchedAt });
        if (fundRichness(f) >= 2) {
          row.pe = f.pe ?? row.pe; row.eps = f.eps ?? row.eps; row.marketCap = f.marketCap ?? row.marketCap;
          row.revGrowth = f.revGrowth ?? null; row.grossMargin = f.grossMargin ?? null;
          row.roic = f.roic ?? null; row.roe = f.roe ?? null;
          row.debtToEquity = f.debtToEquity ?? null; row.currentRatio = f.currentRatio ?? null;
          row.freeCashflow = f.freeCashflow ?? null; row.fcfPerShare = f.fcfPerShare ?? null;
          row.fcfGrowth5y = f.fcfGrowth5y ?? null;
          row.shortPctFloat = f.shortPctFloat ?? row.shortPctFloat;
          row.fundSource = f._source; row.fundAsOf = f._asOf;
          fundCache[row.ticker] = { data: f, cachedAt: Date.now() };
          recovered++;
        }
      } catch (e) { /* still thin — coverage cap handles it honestly */ }
    }
    console.log(`[screen] second-chance recovered ${recovered}/${thin.length}`);
  }

  // ── 4. Score with sector peers ──────────────────────────────────────────
  for (const row of rows) {
    const peers = (bySector[row.sector] || []).filter(p => p.ticker !== row.ticker);
    const s = score(row, peers);
    row.score = s.score; row.breakdown = s.breakdown;
    // ── DATA-COVERAGE CAP ─────────────────────────────────────────────────
    // A score is only as trustworthy as the evidence behind it. Stocks with
    // most fundamentals missing were pinning 99 on momentum alone — absence
    // of evidence must not read as strength. Cap by fundamental coverage:
    //   ≤1 of 6 core fundamentals → max 69 (can never read STRONG)
    //   ≤3 of 6                   → max 84
    const FUND_FIELDS = ['revGrowth', 'grossMargin', 'roic', 'fcfPerShare', 'pe', 'debtToEquity'];
    const have = FUND_FIELDS.filter(k => row[k] != null || (k === 'roic' && row.roe != null)).length;
    row.fundCoverage = `${have}/${FUND_FIELDS.length}`;
    if (have <= 1 && row.score > 69) { row.score = 69; row.coverageCapped = true; }
    else if (have <= 3 && row.score > 84) { row.score = 84; row.coverageCapped = true; }
    row.covered = s.covered; row.missing = s.missing;
    row.solvencyCapped = s.solvencyCapped;
  }

  // ── 5. Save ─────────────────────────────────────────────────────────────
  store.screenResults = rows;
  store.screenAsOf    = new Date().toISOString();
  store.fundCache     = fundCache;  // persist fundamentals cache
  saveStore(store);

  const ok  = rows.filter(r => r.score != null);
  const cov = k => rows.filter(r => r[k] != null).length;
  console.log(`[screen] coverage — revGrowth:${cov('revGrowth')} grossMargin:${cov('grossMargin')} roe:${cov('roe')} roic:${cov('roic')} D/E:${cov('debtToEquity')} short%:${cov('shortPctFloat')} of ${rows.length}`);
  const top = ok.sort((a, b) => b.score - a.score).slice(0, 5).map(r => `${r.ticker}:${r.score}`).join(' ');
  const edgarHits = ok.filter(r => r.discoveredBy === 'edgar').length;
  console.log(`[screen] ${ok.length} scored / ${rows.length} total. EDGAR-discovered: ${edgarHits}. Top: ${top}`);
  return rows;
}

if (require.main === module) runScreen().then(() => process.exit(0));
module.exports = { runScreen };


if (require.main === module) runScreen().then(() => process.exit(0));
module.exports = { runScreen };
