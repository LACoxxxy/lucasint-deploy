/**
 * screen.js — Dynamic screener: reads universe.json (built by universe.js from
 * EDGAR SIC sweeps + ETF seeds) instead of a static watchlist.
 *
 * Screens in batches of 20 with pacing to respect rate limits.
 * EDGAR fundamentals are cached per-ticker (24h TTL) so 3x-daily runs
 * only re-fetch price quotes and buzz — keeping each run fast.
 */
const { fetchQuote, fetchFundamentals, fetchHistory } = require('../util/yahoo');
const { score, momFromHistory, realizedVol } = require('../scoring');
const { sentimentDirection } = require('../sentiment-direction');
const { fetchBuzz }   = require('../util/buzz');
const { assessMoat }  = require('../moat');
const { loadStore, saveStore } = require('../util/store');
const { dataFreshness }        = require('../util/market-status');
const { getUniverse }          = require('../util/universe');
const meta = require('../data/ticker-meta.json');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const BATCH  = 20;    // tickers per batch
const DELAY  = 2000;  // ms between batches — polite to Yahoo + SEC
const FUND_TTL = 24 * 3600 * 1000; // 24h cache for EDGAR fundamentals

async function runScreen() {
  // ── 1. Load universe ───────────────────────────────────────────────────
  const universe = await getUniverse();
  const tickers = Object.entries(universe); // [[ticker, {name, sector, cik, source}], ...]
  console.log(`[screen] Universe: ${tickers.length} tickers from EDGAR + seeds`);

  // ── 2. Load caches ─────────────────────────────────────────────────────
  const store = loadStore();
  const fundCache  = store.fundCache  || {};  // ticker → {data, cachedAt}
  const prevResult = {};                       // ticker → last screen row (for score continuity)
  for (const r of (store.screenResults || [])) prevResult[r.ticker] = r;

  const rows = [];
  const bySector = {};

  // ── 3. Screen in batches ───────────────────────────────────────────────
  for (let i = 0; i < tickers.length; i += BATCH) {
    const batch = tickers.slice(i, i + BATCH);
    await Promise.all(batch.map(async ([t, info]) => {
      try {
        const q = await fetchQuote(t);
        if (!q.price) return; // unlisted / delisted — skip silently

        // EDGAR fundamentals: use cache if fresh, else fetch
        let f = {};
        const cached = fundCache[t];
        if (cached && (Date.now() - cached.cachedAt) < FUND_TTL) {
          f = cached.data;
        } else {
          f = await fetchFundamentals(t, q.price).catch(e => {
            console.warn(`  fund ${t}: ${e.message}`);
            return {};
          });
          fundCache[t] = { data: f, cachedAt: Date.now() };
        }

        const h   = await fetchHistory(t, 3).catch(() => null);
        const m1  = momFromHistory(h, 21);
        const priceConfirm = m1 == null ? null : Math.max(-1, Math.min(1, m1 / 15));
        const bz  = await fetchBuzz(t).catch(() => ({ activity: null, socialPolarity: null, putCallRatio: null, source: null }));
        const buzz = sentimentDirection({ activity: bz.activity, putCallRatio: bz.putCallRatio, socialPolarity: bz.socialPolarity, priceConfirm });

        const sector = info.sector;
        const row = {
          ticker: t, sector,
          name: meta[t]?.name || info.name || t,
          discoveredBy: info.source, // 'seed' | 'edgar'
          price: q.price, currency: q.currency,
          pe: f.pe ?? null, eps: f.eps ?? null,
          revGrowth: f.revGrowth ?? null, grossMargin: f.grossMargin ?? null,
          debtToEquity: f.debtToEquity ?? null, currentRatio: f.currentRatio ?? null,
          roic: f.roic ?? null, fcfPerShare: f.fcfPerShare ?? null,
          fcfGrowth5y: f.fcfGrowth5y ?? null, freeCashflow: f.freeCashflow ?? null,
          shortPctFloat: f.shortPctFloat ?? null, marketCap: f.marketCap ?? null,
          fundSource: f._source ?? null, fundAsOf: f._asOf ?? null,
          mom1m: m1, mom3m: momFromHistory(h, 63),
          mom6m: momFromHistory(h, 126), mom12m: momFromHistory(h, 251),
          volatility: realizedVol(h),
          buzz, buzzActivity: bz.activity, socialPolarity: bz.socialPolarity,
          putCallRatio: bz.putCallRatio, priceConfirm, buzzSource: bz.source,
          _fetchedAt: q._fetchedAt,
        };

        row.moat = assessMoat(f);
        const fresh = dataFreshness(t, q._fetchedAt);
        row.market = fresh.market; row.marketOpen = fresh.open;

        // Enrich with weekly signals (insider/patent/govt) if available
        const e = (store.enrichments || {})[t];
        if (e) {
          Object.assign(row, {
            insiderPts: e.insiderPts, insiderNote: e.insiderNote,
            patentPts: e.patentPts,   patentNote: e.patentNote,
            govtPts: e.govtPts,       govtNote: e.govtNote,
            insider: e.insider, patents: e.patents, govt: e.govt,
            longTerm: e.longTerm, longTermConviction: e.longTermConviction,
          });
          if (e.shortPctFloat != null && row.shortPctFloat == null) row.shortPctFloat = e.shortPctFloat;
        }

        (bySector[sector] = bySector[sector] || []).push(row);
        rows.push(row);
      } catch (e) {
        // Don't push error rows for universe stocks — too noisy at 400+ scale
        if (e.message && !e.message.includes('No fundamentals')) {
          console.warn(`  screen: ${t} — ${e.message.slice(0, 80)}`);
        }
      }
    }));

    if (i + BATCH < tickers.length) await sleep(DELAY);
    console.log(`  screen: ${Math.min(i + BATCH, tickers.length)}/${tickers.length} processed…`);
  }

  // ── 4. Score with sector peers ──────────────────────────────────────────
  for (const row of rows) {
    const peers = (bySector[row.sector] || []).filter(p => p.ticker !== row.ticker);
    const s = score(row, peers);
    row.score = s.score; row.breakdown = s.breakdown;
    row.covered = s.covered; row.missing = s.missing;
    row.solvencyCapped = s.solvencyCapped;
  }

  // ── 5. Save ─────────────────────────────────────────────────────────────
  store.screenResults = rows;
  store.screenAsOf    = new Date().toISOString();
  store.fundCache     = fundCache;  // persist fundamentals cache
  saveStore(store);

  const ok  = rows.filter(r => r.score != null);
  const top = ok.sort((a, b) => b.score - a.score).slice(0, 5).map(r => `${r.ticker}:${r.score}`).join(' ');
  const edgarHits = ok.filter(r => r.discoveredBy === 'edgar').length;
  console.log(`[screen] ${ok.length} scored / ${rows.length} total. EDGAR-discovered: ${edgarHits}. Top: ${top}`);
  return rows;
}

if (require.main === module) runScreen().then(() => process.exit(0));
module.exports = { runScreen };


if (require.main === module) runScreen().then(() => process.exit(0));
module.exports = { runScreen };
