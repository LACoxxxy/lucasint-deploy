/** Screen job: live fundamentals + price history → guardrails → full scoring model. */
const { fetchQuote, fetchFundamentals, fetchHistory } = require('../util/yahoo');
const { score, momFromHistory, realizedVol } = require('../scoring');
const { sentimentDirection } = require('../sentiment-direction');
const { assessMoat } = require('../moat');
const { loadStore, saveStore } = require('../util/store');
const { dataFreshness } = require('../util/market-status');
const watchlist = require('../data/watchlist.json');
const meta = require('../data/ticker-meta.json');

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function runScreen() {
  const bySector = {};
  const rows = [];
  const tickers = Object.entries(watchlist).flatMap(([sector, ts]) => ts.map(t => ({ t, sector })));
  console.log(`  screen: fetching ${tickers.length} tickers…`);
  for (const { t, sector } of tickers) {
    try {
      const q = await fetchQuote(t);
      const [f, h] = [
        await fetchFundamentals(t, q.price).catch(e => { console.error(`  fund ${t}: ${e.message}`); return {}; }),
        await fetchHistory(t, 3).catch(() => null),
      ];
      const m1 = momFromHistory(h,21);
      // priceConfirm: is recent attention accompanying a rise or fall? (−1..+1) — the one
      // directional input we can derive without options/social feeds. Scaled from 1m momentum.
      const priceConfirm = m1 == null ? null : Math.max(-1, Math.min(1, m1 / 15));
      const buzz = sentimentDirection({ activity: null, putCallRatio: null, socialPolarity: null, priceConfirm });
      const row = { ticker: t, sector, name: meta[t]?.name || t, price: q.price, currency: q.currency,
        pe: f.pe ?? null, eps: f.eps ?? null, revGrowth: f.revGrowth ?? null, grossMargin: f.grossMargin ?? null,
        debtToEquity: f.debtToEquity ?? null, currentRatio: f.currentRatio ?? null,
        roic: f.roic ?? null, fcfPerShare: f.fcfPerShare ?? null, fcfGrowth5y: f.fcfGrowth5y ?? null,
        freeCashflow: f.freeCashflow ?? null, shortPctFloat: f.shortPctFloat ?? null,
        marketCap: f.marketCap ?? null, fundSource: f._source ?? null, fundAsOf: f._asOf ?? null,
        mom1m: m1, mom3m: momFromHistory(h,63), mom6m: momFromHistory(h,126), mom12m: momFromHistory(h,251),
        volatility: realizedVol(h), buzz, _fetchedAt: q._fetchedAt };
      row.moat = assessMoat(f);   // long-term conviction (free, from EDGAR multi-year series)
      const fresh = dataFreshness(t, q._fetchedAt);
      row.market = fresh.market; row.marketOpen = fresh.open;
      (bySector[sector] = bySector[sector] || []).push(row);
      rows.push(row);
      await sleep(500); // polite to Yahoo
    } catch (e) { console.error(`  screen: ${t} — ${e.message}`); rows.push({ ticker: t, sector, error: e.message }); }
  }
  // score with sector peers
  const store = loadStore();
  const enrich = store.enrichments || {};   // from the weekly enrich job (insider/patent/govt/longTerm)
  for (const row of rows) {
    if (row.error) continue;
    const e = enrich[row.ticker];
    if (e) {
      row.insiderPts = e.insiderPts; row.insiderNote = e.insiderNote;
      row.patentPts = e.patentPts;   row.patentNote = e.patentNote;
      row.govtPts = e.govtPts;       row.govtNote = e.govtNote;
      row.insider = e.insider; row.patents = e.patents; row.govt = e.govt;
      row.longTerm = e.longTerm; row.longTermConviction = e.longTermConviction;
      if (e.shortPctFloat != null && row.shortPctFloat == null) row.shortPctFloat = e.shortPctFloat;
    }
    const peers = (bySector[row.sector] || []).filter(p => p.ticker !== row.ticker);
    const s = score(row, peers);
    row.score = s.score; row.breakdown = s.breakdown; row.covered = s.covered;
    row.missing = s.missing; row.solvencyCapped = s.solvencyCapped;
  }
  store.screenResults = rows; store.screenAsOf = new Date().toISOString();
  saveStore(store);
  const ok = rows.filter(r => !r.error);
  console.log(`  screen: ${ok.length}/${rows.length} ok. Top: ${ok.filter(r=>r.score!=null).sort((a,b)=>b.score-a.score).slice(0,5).map(r=>`${r.ticker}:${r.score}`).join(' ')}`);
  return rows;
}

if (require.main === module) runScreen().then(() => process.exit(0));
module.exports = { runScreen };
