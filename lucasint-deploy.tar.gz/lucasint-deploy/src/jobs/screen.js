/** Screen job: live fundamentals + price history → guardrails → full scoring model. */
const { fetchQuote, fetchFundamentals, fetchHistory } = require('../util/yahoo');
const { score, momFromHistory, realizedVol } = require('../scoring');
const { loadStore, saveStore } = require('../util/store');
const { dataFreshness } = require('../util/market-status');
const watchlist = require('../data/watchlist.json');
const meta = require('../data/ticker-meta.json');

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function runScreen() {
  const bySector = {};
  const rows = [];
  const tickers = Object.entries(watchlist).flatMap(([sector, ts]) => ts.map(t => ({ t, sector })));
  console.log(`  screen: fetching ${tickers.length} tickers…`);
  for (const { t, sector } of tickers) {
    try {
      const [q, f, h] = [await fetchQuote(t), await fetchFundamentals(t).catch(() => ({})), await fetchHistory(t, 1).catch(() => null)];
      const row = { ticker: t, sector, name: meta[t]?.name || t, price: q.price, currency: q.currency,
        pe: f.pe ?? null, revGrowth: f.revGrowth ?? null, grossMargin: f.grossMargin ?? null,
        debtToEquity: f.debtToEquity ?? null, currentRatio: f.currentRatio ?? null,
        shortPctFloat: f.shortPctFloat ?? null, marketCap: f.marketCap ?? null,
        mom1m: momFromHistory(h,21), mom3m: momFromHistory(h,63), mom6m: momFromHistory(h,126), mom12m: momFromHistory(h,251),
        volatility: realizedVol(h), _fetchedAt: q._fetchedAt };
      const fresh = dataFreshness(t, q._fetchedAt);
      row.market = fresh.market; row.marketOpen = fresh.open;
      (bySector[sector] = bySector[sector] || []).push(row);
      rows.push(row);
      await sleep(500); // polite to Yahoo
    } catch (e) { console.error(`  screen: ${t} — ${e.message}`); rows.push({ ticker: t, sector, error: e.message }); }
  }
  // score with sector peers
  for (const row of rows) {
    if (row.error) continue;
    const peers = (bySector[row.sector] || []).filter(p => p.ticker !== row.ticker);
    const s = score(row, peers);
    row.score = s.score; row.breakdown = s.breakdown; row.covered = s.covered;
    row.missing = s.missing; row.solvencyCapped = s.solvencyCapped;
  }
  const store = loadStore();
  store.screenResults = rows; store.screenAsOf = new Date().toISOString();
  saveStore(store);
  const ok = rows.filter(r => !r.error);
  console.log(`  screen: ${ok.length}/${rows.length} ok. Top: ${ok.filter(r=>r.score!=null).sort((a,b)=>b.score-a.score).slice(0,5).map(r=>`${r.ticker}:${r.score}`).join(' ')}`);
  return rows;
}

if (require.main === module) runScreen().then(() => process.exit(0));
module.exports = { runScreen };
