/**
 * Screen job: fetch live fundamentals for the watchlist, validate (research
 * guardrails), score, and cache. The scoring + validation logic is the SAME
 * model proven in the prototype — port scoring.js in when ready.
 */
const { fetchQuote } = require('../util/yahoo');
const { loadStore, saveStore } = require('../util/store');
const { dataFreshness } = require('../util/market-status');
const watchlist = require('../data/watchlist.json');

async function runScreen() {
  const tickers = Object.values(watchlist).flat();
  const results = [];
  for (const t of tickers) {
    try {
      const q = await fetchQuote(t);
      // TODO: pipe q through research-guardrails validate() + scoring model
      const fresh = dataFreshness(t, q._fetchedAt);
      results.push({ ...q, flags: [], market: fresh.market, marketOpen: fresh.open, freshnessNote: fresh.note });
      await new Promise(r => setTimeout(r, 400)); // be polite to Yahoo
    } catch (e) {
      console.error(`  screen: ${t} failed — ${e.message}`);
      results.push({ ticker: t, error: e.message });
    }
  }
  const store = loadStore();
  store.screenResults = results;
  store.screenAsOf = new Date().toISOString();
  saveStore(store);
  console.log(`  screen: ${results.filter(r => !r.error).length}/${tickers.length} ok`);
  return results;
}

if (require.main === module) runScreen().then(() => process.exit(0));
module.exports = { runScreen };
