/**
 * discover.js — Weekly universe refresh.
 * Rebuilds universe.json from EDGAR SIC sweeps + ETF seeds.
 * Reports new discoveries to Telegram.
 * Runs every Sunday at 6am AEST (cron from server.js).
 */

const https   = require('https');
const fs      = require('fs');
const path    = require('path');
const { buildUniverse } = require('../util/universe');
const { loadStore }     = require('../util/store');

const TOKEN   = process.env.TELEGRAM_BOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

function tgSend(text) {
  if (!TOKEN || !CHAT_ID) return Promise.resolve();
  const body = JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: 'HTML' });
  return new Promise((resolve) => {
    const req = https.request({
      hostname: 'api.telegram.org', path: `/bot${TOKEN}/sendMessage`,
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, res => { res.resume(); res.on('end', resolve); });
    req.on('error', () => resolve());
    req.end(body);
  });
}

async function runDiscover() {
  console.log('[discover] Starting weekly universe refresh...');

  // Load previous universe to detect new entries
  let previousTickers = new Set();
  try {
    const prev = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'universe.json'), 'utf8'));
    previousTickers = new Set(Object.keys(prev));
  } catch { /* first run */ }

  const universe = await buildUniverse();
  const allTickers = Object.keys(universe);
  const newTickers = allTickers.filter(t => !previousTickers.has(t));
  const edgarDiscovered = Object.entries(universe).filter(([,v]) => v.source === 'edgar').map(([t]) => t);

  const msg = [
    `🔍 <b>Universe Refresh Complete</b>`,
    `Total: ${allTickers.length} stocks screened`,
    `EDGAR-discovered (unknowns): ${edgarDiscovered.length}`,
    newTickers.length ? `\n🆕 <b>New this week:</b> ${newTickers.slice(0, 20).join(', ')}${newTickers.length > 20 ? ` +${newTickers.length - 20} more` : ''}` : `No new tickers this week`,
  ].join('\n');

  await tgSend(msg);
  console.log(`[discover] Done. ${allTickers.length} total, ${newTickers.length} new.`);
  return { total: allTickers.length, new: newTickers.length, edgarDiscovered: edgarDiscovered.length };
}

if (require.main === module) {
  runDiscover().then(r => { console.log(r); process.exit(0); }).catch(e => { console.error(e); process.exit(1); });
}

module.exports = { runDiscover };
