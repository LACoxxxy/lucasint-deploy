/** 6pm digest: summarise the day's screen + portfolio, send via Telegram. */
const { loadStore } = require('../util/store');
const { askClaude } = require('../util/claude');
const { sendTelegram } = require('../util/telegram');

async function runDigest() {
  const store = loadStore();
  const results = store.screenResults || [];
  const top = results.filter(r => !r.error).slice(0, 8);
  const system = `You write a concise daily investment intelligence digest. Plain text, mobile-friendly, no markdown symbols. Lead with highest-conviction names. End with one line: this is research, not financial advice; decisions are the user's.`;
  const user = `Write the 6pm digest from today's screen of ${top.length} names.\nData: ${JSON.stringify(top)}\nKeep it scannable on a phone. Sections: top movers, anything newly notable, one short watch-note. Be honest about uncertainty.`;
  let body;
  try { body = await askClaude({ system, user, maxTokens: 800 }); }
  catch (e) { body = `Digest generation failed: ${e.message}. Raw top names: ${top.map(t => t.ticker).join(', ')}`; }
  await sendTelegram(body);
  console.log('  digest: sent');
  return body;
}

if (require.main === module) runDigest().then(() => process.exit(0));
module.exports = { runDigest };
