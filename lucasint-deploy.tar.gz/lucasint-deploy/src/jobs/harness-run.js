/**
 * harness-run.js — feeds REAL price history through the validation harness.
 * Tests PRICE-BASED hypotheses only (momentum, relative strength) — the only ones
 * honestly testable without point-in-time fundamentals. Verdicts are whatever the
 * harness says: SURVIVED strategies populate /api/validated; FAILED ones don't.
 * Predicates stored declaratively: [{field, op, value}] ANDed.
 */
const { fetchHistory } = require('../util/yahoo');
const { runHarness, resetHypothesisCounter } = require('../validation-harness');
const { loadStore, saveStore } = require('../util/store');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const OPS = { '>': (a, b) => a > b, '<': (a, b) => a < b, '>=': (a, b) => a >= b, '<=': (a, b) => a <= b };
const evalPred = (conds) => (snap) => conds.every(c => snap[c.field] != null && OPS[c.op](snap[c.field], c.value));

// The hypotheses (kept few — multiple-testing correction punishes fishing):
const HYPOTHESES = [
  { id: 'mom-strong', label: '6m momentum > 25%', direction: 'bullish', conds: [{ field: 'mom6m', op: '>', value: 25 }] },
  { id: 'rel-strength', label: 'Leading sector by > 10%', direction: 'bullish', conds: [{ field: 'relStrength', op: '>', value: 10 }] },
  { id: 'mom-negative', label: 'Negative 6m momentum (expect underperform)', direction: 'bearish', conds: [{ field: 'mom6m', op: '<', value: 0 }] },
];

function momAt(closes, i, days) { const j = i - days; return j >= 0 && closes[j] ? ((closes[i] - closes[j]) / closes[j]) * 100 : null; }

async function runHarnessJob() {
  // Universe = the live screen results (largest 500 by market cap: enough
  // statistical power without a marathon fetch). Falls back to whatever exists.
  const store0 = loadStore();
  let entries = (store0.screenResults || [])
    .filter(r => r && r.ticker && r.score != null)
    .map(r => ({ t: r.ticker, sector: r.sector, mcap: r.marketCap || 0 }));
  if (!entries.length) { console.error('  harness: no screen results yet — run a screen first.'); return null; }
  entries.sort((a, b) => (b.mcap || 0) - (a.mcap || 0));
  entries = entries.slice(0, 500);
  const tickers = entries;
  console.log(`  harness: fetching 3y history for ${tickers.length} tickers (top-mcap slice of live universe)…`);
  const hist = {};
  for (const { t, sector } of tickers) {
    try { hist[t] = { ...(await fetchHistory(t, 3)), sector }; await sleep(350); }
    catch (e) { /* thin/dead names skip silently at this scale */ }
  }
  const have = Object.keys(hist);
  if (have.length < 8) { console.error('  harness: too little history fetched; aborting.'); return null; }

  // Build monthly periods: snapshot (mom6m, relStrength) + 3m forward returns
  const ref = hist[have[0]];
  const periods = [];
  const STEP = 21, FWD = 63, MOM = 126;
  for (let i = MOM; i < ref.closes.length - FWD; i += STEP) {
    const snapshots = [], forwardReturns = {}, sectorAgg = {};
    for (const t of have) {
      const h = hist[t];
      if (h.closes.length <= i + FWD) continue;
      const m = momAt(h.closes, i, MOM);
      if (m == null) continue;
      const fwd = ((h.closes[i + FWD] - h.closes[i]) / h.closes[i]) * 100;
      snapshots.push({ ticker: t, sector: h.sector, mom6m: m });
      forwardReturns[t] = fwd;
      (sectorAgg[h.sector] = sectorAgg[h.sector] || []).push({ m, fwd });
    }
    const sectorReturns = {}, sectorMom = {};
    for (const s in sectorAgg) {
      sectorReturns[s] = sectorAgg[s].reduce((a, x) => a + x.fwd, 0) / sectorAgg[s].length;
      sectorMom[s] = sectorAgg[s].reduce((a, x) => a + x.m, 0) / sectorAgg[s].length;
    }
    snapshots.forEach(sn => { sn.relStrength = +(sn.mom6m - sectorMom[sn.sector]).toFixed(1); });
    if (snapshots.length >= 5) periods.push({ date: new Date(ref.dates[i]).toISOString().slice(0, 10), snapshots, forwardReturns, sectorReturns });
  }
  console.log(`  harness: built ${periods.length} monthly periods from real history.`);

  resetHypothesisCounter();
  const results = [];
  for (const hy of HYPOTHESES) {
    const verdict = runHarness({ id: hy.id, label: hy.label, predicate: evalPred(hy.conds) }, periods);
    results.push({ id: hy.id, label: hy.label, direction: hy.direction, conds: hy.conds, grade: verdict.grade, verdict: verdict.verdict,
      outOfSample: verdict.outOfSample, warnings: verdict.warnings });
    console.log(`  harness: [${verdict.grade}] ${hy.label} — OOS hit ${verdict.outOfSample?.hitRate}, excess ${verdict.outOfSample?.avgExcess}%`);
  }
  const store = loadStore();
  store.harnessResults = results; store.harnessAsOf = new Date().toISOString();
  store.harnessNote = 'Price-based hypotheses only. Fundamentals hypotheses need point-in-time data (not yet available).';
  saveStore(store);
  return results;
}

if (require.main === module) runHarnessJob().then(() => process.exit(0));
module.exports = { runHarnessJob };
