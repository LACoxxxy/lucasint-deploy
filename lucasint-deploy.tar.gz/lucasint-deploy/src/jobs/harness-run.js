/**
 * harness-run.js — feeds REAL price history through the validation harness.
 * Tests PRICE-BASED hypotheses only (momentum, relative strength) — the only ones
 * honestly testable without point-in-time fundamentals. Verdicts are whatever the
 * harness says: SURVIVED strategies populate /api/validated; FAILED ones don't.
 * Predicates stored declaratively: [{field, op, value}] ANDed.
 */
const { fetchHistory } = require('../util/yahoo');
const { runHarness, resetHypothesisCounter } = require('../validation-harness');
const { loadStore, saveStore } = require('../util/store');
const watchlist = require('../data/watchlist.json');

const sleep = ms => new Promise(r => setTimeout(r, ms));
const OPS = { '>': (a, b) => a > b, '<': (a, b) => a < b, '>=': (a, b) => a >= b, '<=': (a, b) => a <= b };
const evalPred = (conds) => (snap) => conds.every(c => snap[c.field] != null && OPS[c.op](snap[c.field], c.value));

// The hypotheses (kept few — multiple-testing correction punishes fishing):
const HYPOTHESES = [
  { id: 'mom-strong', label: '6m momentum > 25%', conds: [{ field: 'mom6m', op: '>', value: 25 }] },
  { id: 'rel-strength', label: 'Leading sector by > 10%', conds: [{ field: 'relStrength', op: '>', value: 10 }] },
  { id: 'mom-negative', label: 'Negative 6m momentum (expect underperform)', conds: [{ field: 'mom6m', op: '<', value: 0 }] },
];

function momAt(closes, i, days) { const j = i - days; return j >= 0 && closes[j] ? ((closes[i] - closes[j]) / closes[j]) * 100 : null; }

async function runHarnessJob() {
  const tickers = Object.entries(watchlist).flatMap(([sector, ts]) => ts.map(t => ({ t, sector })));
  console.log(`  harness: fetching 3y history for ${tickers.length} tickers…`);
  const hist = {};
  for (const { t, sector } of tickers) {
    try { hist[t] = { ...(await fetchHistory(t, 3)), sector }; await sleep(500); }
    catch (e) { console.error(`  harness: ${t} history failed — ${e.message}`); }
  }
  const have = Object.keys(hist);
  if (have.length < 8) { console.error('  harness: too little history fetched; aborting.'); return null; }

  // Build monthly periods: snapshot (mom6m, relStrength) + 3m forward returns
  const ref = hist[have[0]];
  const periods = [];
  const STEP = 21, FWD = 63, MOM = 126;
  for (let i = MOM; i < ref.closes.length - FWD; i += STEP) {
    const snapshots = [], forwardReturns = {}, sectorAgg = {};
    for (const t of have) {
      const h = hist[t];
      if (h.closes.length <= i + FWD) continue;
      const m = momAt(h.closes, i, MOM);
      if (m == null) continue;
      const fwd = ((h.closes[i + FWD] - h.closes[i]) / h.closes[i]) * 100;
      snapshots.push({ ticker: t, sector: h.sector, mom6m: m });
      forwardReturns[t] = fwd;
      (sectorAgg[h.sector] = sectorAgg[h.sector] || []).push({ m, fwd });
    }
    const sectorReturns = {}, sectorMom = {};
    for (const s in sectorAgg) {
      sectorReturns[s] = sectorAgg[s].reduce((a, x) => a + x.fwd, 0) / sectorAgg[s].length;
      sectorMom[s] = sectorAgg[s].reduce((a, x) => a + x.m, 0) / sectorAgg[s].length;
    }
    snapshots.forEach(sn => { sn.relStrength = +(sn.mom6m - sectorMom[sn.sector]).toFixed(1); });
    if (snapshots.length >= 5) periods.push({ date: new Date(ref.dates[i]).toISOString().slice(0, 10), snapshots, forwardReturns, sectorReturns });
  }
  console.log(`  harness: built ${periods.length} monthly periods from real history.`);

  resetHypothesisCounter();
  const results = [];
  for (const hy of HYPOTHESES) {
    const verdict = runHarness({ id: hy.id, label: hy.label, predicate: evalPred(hy.conds) }, periods);
    results.push({ id: hy.id, label: hy.label, conds: hy.conds, grade: verdict.grade, verdict: verdict.verdict,
      outOfSample: verdict.outOfSample, warnings: verdict.warnings });
    console.log(`  harness: [${verdict.grade}] ${hy.label} — OOS hit ${verdict.outOfSample?.hitRate}, excess ${verdict.outOfSample?.avgExcess}%`);
  }
  const store = loadStore();
  store.harnessResults = results; store.harnessAsOf = new Date().toISOString();
  store.harnessNote = 'Price-based hypotheses only. Fundamentals hypotheses need point-in-time data (not yet available).';
  saveStore(store);
  return results;
}

if (require.main === module) runHarnessJob().then(() => process.exit(0));
module.exports = { runHarnessJob };
