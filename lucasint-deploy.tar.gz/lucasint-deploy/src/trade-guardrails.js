/**
 * trade-guardrails.js
 * ───────────────────────────────────────────────────────────────────────────
 * DEFENCE-IN-DEPTH SAFETY LAYER for the LucasINT trading agent.
 *
 * PHILOSOPHY: This does NOT make automated trading "safe". It makes failures
 * smaller, slower, and catchable. Every check FAILS CLOSED — if anything is
 * uncertain, the trade is BLOCKED and you are alerted. A human is assumed to be
 * reachable via Telegram for anything the system won't auto-approve.
 *
 * Order of defence (a trade must pass ALL layers):
 *   0. KILL SWITCH        — global on/off, trumps everything
 *   1. MODE GATE          — research / confirm / auto; controls autonomy level
 *   2. DATA INTEGRITY      — is the price/data feed fresh, sane, non-stale?
 *   3. SANITY CHECKS       — does the order itself make sense?
 *   4. RISK LIMITS         — position size, exposure, cash, concentration
 *   5. RATE / VELOCITY     — too many trades too fast = bug signature
 *   6. CIRCUIT BREAKERS    — daily loss, error streak, volatility halt
 *   7. CONFIRMATION GATE    — human approval for anything above thresholds
 *   8. AUDIT LOG           — immutable record of every decision
 * ───────────────────────────────────────────────────────────────────────────
 */

// ============================ CONFIG ========================================
const CONFIG = {
  // ---- Autonomy mode ----
  // 'research'  : agent suggests only, NEVER touches orders (default, safest)
  // 'confirm'   : agent prepares orders, requires explicit Telegram approval
  // 'auto'      : agent executes within limits, alerts after (highest risk)
  mode: 'research',

  // ---- Hard money limits (illustrative — set to your real numbers) ----
  portfolioValue:        100000,   // total account value, refreshed live
  maxPositionPct:        12,       // no single position above 12% of portfolio
  maxPositionDollars:    12000,    // absolute $ cap, whichever is LOWER wins
  maxSectorExposurePct:  35,       // no single sector above 35%
  maxNewCapitalPerDay:   10000,    // total $ deployable to new buys per day
  minCashReservePct:     10,       // never deploy below this cash floor

  // ---- Order sanity bounds ----
  maxOrderSlippagePct:   2,        // reject if order price > 2% from last quote
  minOrderDollars:       250,      // ignore dust orders (likely a bug)
  maxSharePriceDeviation: 0.15,    // reject if quoted price moved >15% vs prior tick (bad feed)

  // ---- Velocity / rate limits ----
  maxTradesPerHour:      6,
  maxTradesPerDay:       15,
  minSecondsBetweenTrades: 60,     // no two orders within 60s (anti-runaway)

  // ---- Circuit breakers ----
  maxDailyLossPct:       5,        // halt ALL trading if account down >5% in a day
  maxConsecutiveErrors:  3,        // halt after 3 errors in a row (likely systemic)
  haltOnVolatilitySpike: true,     // halt a name if its intraday move > threshold
  volatilityHaltPct:     20,       // single-name intraday move that triggers halt

  // ---- Data freshness ----
  maxQuoteAgeSeconds:    30,       // reject trades on quotes older than this
  maxFundamentalAgeHours: 26,      // re-screen data must be < ~1 day old

  // ---- Speculative layer guard ----
  blockAutoOnSpeculativeOnly: true, // NEVER auto-trade on speculative/sentiment alone
};

// ============================ STATE =========================================
// In production this lives in a small persistent store (SQLite/JSON on Beelink)
// so it survives restarts. Reset logic runs at market open each day.
const STATE = {
  killSwitch: false,            // master abort
  tradesThisHour: [],           // timestamps
  tradesToday: [],              // timestamps
  newCapitalToday: 0,
  consecutiveErrors: 0,
  dayStartValue: CONFIG.portfolioValue,
  haltedTickers: new Set(),     // names under volatility halt
  globalHalt: false,            // circuit-breaker tripped
  lastTradeTs: 0,
};

// ============================ ALERTING ======================================
// Wire this to your Telegram bot. Critical alerts should be impossible to miss.
function alert(level, message, ctx = {}) {
  // level: 'info' | 'warn' | 'block' | 'critical'
  const payload = { ts: new Date().toISOString(), level, message, ...ctx };
  console.log(`[${level.toUpperCase()}] ${message}`, ctx);
  // TODO: sendTelegram(level, message, ctx)  ← hook into bot
  // 'critical' should also trigger a fallback (SMS/email) in case Telegram is down
  return payload;
}

// ============================ AUDIT LOG =====================================
// Append-only. Every decision — pass or block — is recorded with full context.
const AUDIT = [];
function audit(decision, order, reason, extra = {}) {
  const entry = {
    ts: new Date().toISOString(),
    decision,            // 'APPROVED' | 'BLOCKED' | 'CONFIRM_REQUIRED' | 'EXECUTED' | 'ERROR'
    order,
    reason,
    mode: CONFIG.mode,
    ...extra,
  };
  AUDIT.push(entry);
  // TODO: persist to append-only file/db on Beelink (never overwrite)
  return entry;
}

// ============================ HELPERS =======================================
function nowSec() { return Date.now() / 1000; }
function pruneWindows() {
  const t = Date.now();
  STATE.tradesThisHour = STATE.tradesThisHour.filter(ts => t - ts < 3600_000);
  STATE.tradesToday    = STATE.tradesToday.filter(ts => t - ts < 86_400_000);
}

// ============================ THE LAYERS ====================================

// LAYER 0 — KILL SWITCH
function checkKillSwitch() {
  if (STATE.killSwitch) return { ok: false, reason: 'KILL SWITCH ACTIVE — all trading manually disabled' };
  if (STATE.globalHalt) return { ok: false, reason: 'GLOBAL HALT — a circuit breaker has tripped; manual reset required' };
  return { ok: true };
}

// LAYER 1 — MODE GATE
function checkMode(order) {
  if (CONFIG.mode === 'research') {
    return { ok: false, reason: 'RESEARCH MODE — agent is suggest-only; no orders permitted', soft: true };
  }
  if (CONFIG.mode === 'confirm') {
    return { ok: true, requiresConfirmation: true };
  }
  if (CONFIG.mode === 'auto') {
    // Auto mode still routes large/unusual orders to confirmation (see Layer 7)
    return { ok: true };
  }
  return { ok: false, reason: `Unknown mode "${CONFIG.mode}" — failing closed` };
}

// LAYER 2 — DATA INTEGRITY
function checkDataIntegrity(order, marketData) {
  if (!marketData || marketData.lastQuote == null) {
    return { ok: false, reason: 'No market data — cannot verify price; failing closed' };
  }
  const quoteAge = nowSec() - marketData.quoteTs;
  if (quoteAge > CONFIG.maxQuoteAgeSeconds) {
    return { ok: false, reason: `Stale quote (${quoteAge.toFixed(0)}s old > ${CONFIG.maxQuoteAgeSeconds}s) — feed may be down` };
  }
  // Detect a corrupt/bad feed: implausible jump vs previous tick
  if (marketData.prevQuote) {
    const dev = Math.abs(marketData.lastQuote - marketData.prevQuote) / marketData.prevQuote;
    if (dev > CONFIG.maxSharePriceDeviation) {
      return { ok: false, reason: `Price moved ${(dev*100).toFixed(1)}% vs prior tick — suspected bad feed, blocking` };
    }
  }
  if (marketData.lastQuote <= 0 || !isFinite(marketData.lastQuote)) {
    return { ok: false, reason: 'Non-sensical quote (<=0 or NaN) — bad data' };
  }
  // Fundamental data staleness (the screen that generated this idea)
  if (order.screenAgeHours != null && order.screenAgeHours > CONFIG.maxFundamentalAgeHours) {
    return { ok: false, reason: `Screening data ${order.screenAgeHours}h old — re-screen before acting` };
  }
  return { ok: true };
}

// LAYER 3 — ORDER SANITY
function checkSanity(order, marketData) {
  if (!order.ticker || !order.side || !order.qty || order.qty <= 0) {
    return { ok: false, reason: 'Malformed order (missing ticker/side/qty) — bug signature' };
  }
  if (!['BUY', 'SELL'].includes(order.side)) {
    return { ok: false, reason: `Invalid side "${order.side}"` };
  }
  const orderValue = order.qty * marketData.lastQuote;
  if (orderValue < CONFIG.minOrderDollars) {
    return { ok: false, reason: `Order $${orderValue.toFixed(0)} below min $${CONFIG.minOrderDollars} — likely dust/bug` };
  }
  // Slippage / limit sanity: agent's intended price vs live quote
  if (order.limitPrice) {
    const slip = Math.abs(order.limitPrice - marketData.lastQuote) / marketData.lastQuote;
    if (slip > CONFIG.maxOrderSlippagePct / 100) {
      return { ok: false, reason: `Limit price ${(slip*100).toFixed(1)}% off market (>${CONFIG.maxOrderSlippagePct}%) — rejecting` };
    }
  }
  return { ok: true, orderValue };
}

// LAYER 4 — RISK LIMITS
function checkRiskLimits(order, orderValue, positions) {
  if (order.side !== 'BUY') return { ok: true }; // sells reduce risk; lighter checks

  // Position size cap (lower of % and $ wins)
  const posPctCap = CONFIG.portfolioValue * CONFIG.maxPositionPct / 100;
  const hardCap = Math.min(posPctCap, CONFIG.maxPositionDollars);
  const existing = positions[order.ticker]?.value || 0;
  if (existing + orderValue > hardCap) {
    return { ok: false, reason: `Position would be $${(existing+orderValue).toFixed(0)} > cap $${hardCap.toFixed(0)} (${CONFIG.maxPositionPct}% / $${CONFIG.maxPositionDollars})` };
  }
  // Sector concentration
  const sectorVal = Object.values(positions).filter(p => p.sector === order.sector).reduce((s,p)=>s+p.value, 0);
  const sectorCap = CONFIG.portfolioValue * CONFIG.maxSectorExposurePct / 100;
  if (sectorVal + orderValue > sectorCap) {
    return { ok: false, reason: `Sector ${order.sector} would exceed ${CONFIG.maxSectorExposurePct}% exposure cap` };
  }
  // Daily new-capital budget
  if (STATE.newCapitalToday + orderValue > CONFIG.maxNewCapitalPerDay) {
    return { ok: false, reason: `Would exceed daily new-capital budget $${CONFIG.maxNewCapitalPerDay} (used $${STATE.newCapitalToday.toFixed(0)})` };
  }
  // Cash reserve floor
  const totalDeployed = Object.values(positions).reduce((s,p)=>s+p.value, 0);
  const cashAfter = CONFIG.portfolioValue - totalDeployed - orderValue;
  if (cashAfter < CONFIG.portfolioValue * CONFIG.minCashReservePct / 100) {
    return { ok: false, reason: `Would breach ${CONFIG.minCashReservePct}% cash reserve floor` };
  }
  return { ok: true };
}

// LAYER 5 — VELOCITY / RATE
function checkVelocity() {
  pruneWindows();
  const sinceLast = nowSec() - STATE.lastTradeTs;
  if (sinceLast < CONFIG.minSecondsBetweenTrades) {
    return { ok: false, reason: `Only ${sinceLast.toFixed(0)}s since last trade (<${CONFIG.minSecondsBetweenTrades}s) — anti-runaway block` };
  }
  if (STATE.tradesThisHour.length >= CONFIG.maxTradesPerHour) {
    return { ok: false, reason: `Hourly trade limit (${CONFIG.maxTradesPerHour}) reached — possible loop, blocking` };
  }
  if (STATE.tradesToday.length >= CONFIG.maxTradesPerDay) {
    return { ok: false, reason: `Daily trade limit (${CONFIG.maxTradesPerDay}) reached` };
  }
  return { ok: true };
}

// LAYER 6 — CIRCUIT BREAKERS
function checkCircuitBreakers(order, marketData, currentPortfolioValue) {
  // Daily loss breaker
  const dailyPnlPct = ((currentPortfolioValue - STATE.dayStartValue) / STATE.dayStartValue) * 100;
  if (dailyPnlPct <= -CONFIG.maxDailyLossPct) {
    STATE.globalHalt = true;
    alert('critical', `DAILY LOSS BREAKER: account down ${dailyPnlPct.toFixed(1)}% — ALL trading halted, manual reset required`);
    return { ok: false, reason: `Daily loss breaker tripped (${dailyPnlPct.toFixed(1)}%)` };
  }
  // Error-streak breaker
  if (STATE.consecutiveErrors >= CONFIG.maxConsecutiveErrors) {
    STATE.globalHalt = true;
    alert('critical', `ERROR-STREAK BREAKER: ${STATE.consecutiveErrors} consecutive errors — systemic problem suspected, halted`);
    return { ok: false, reason: 'Consecutive-error breaker tripped' };
  }
  // Per-name volatility halt
  if (CONFIG.haltOnVolatilitySpike && marketData.intradayMovePct != null) {
    if (Math.abs(marketData.intradayMovePct) > CONFIG.volatilityHaltPct) {
      STATE.haltedTickers.add(order.ticker);
      alert('warn', `${order.ticker} moved ${marketData.intradayMovePct.toFixed(1)}% intraday — auto-trading halted for this name`);
      return { ok: false, reason: `${order.ticker} under volatility halt (${marketData.intradayMovePct.toFixed(1)}% move)` };
    }
  }
  if (STATE.haltedTickers.has(order.ticker)) {
    return { ok: false, reason: `${order.ticker} is under an active volatility halt` };
  }
  return { ok: true };
}

// LAYER 7 — CONFIRMATION GATE
function needsConfirmation(order, orderValue, modeResult) {
  if (modeResult.requiresConfirmation) return true;            // confirm mode = always
  if (CONFIG.mode === 'auto') {
    // Even in auto mode, force human approval for the riskiest orders
    if (orderValue > CONFIG.maxPositionDollars * 0.5) return true;
    if (order.speculativeOnly && CONFIG.blockAutoOnSpeculativeOnly) return true;
    if (order.alignedFlag === false && order.fundamentalScore < 70) return true;
  }
  return false;
}

// ============================ ORCHESTRATOR ==================================
/**
 * Run an intended order through every layer.
 * Returns: { action, reason, audit }
 *   action: 'EXECUTE' | 'REQUEST_CONFIRMATION' | 'BLOCK'
 */
function evaluateTrade(order, marketData, positions, currentPortfolioValue) {
  try {
    // 0
    let r = checkKillSwitch();
    if (!r.ok) return finalize('BLOCK', order, r.reason);
    // 1
    const modeResult = checkMode(order);
    if (!modeResult.ok) return finalize('BLOCK', order, modeResult.reason, { soft: modeResult.soft });
    // 2
    r = checkDataIntegrity(order, marketData);
    if (!r.ok) { STATE.consecutiveErrors++; return finalize('BLOCK', order, r.reason); }
    // 3
    r = checkSanity(order, marketData);
    if (!r.ok) { STATE.consecutiveErrors++; return finalize('BLOCK', order, r.reason); }
    const orderValue = r.orderValue;
    // 4
    r = checkRiskLimits(order, orderValue, positions);
    if (!r.ok) return finalize('BLOCK', order, r.reason);
    // 5
    r = checkVelocity();
    if (!r.ok) return finalize('BLOCK', order, r.reason);
    // 6
    r = checkCircuitBreakers(order, marketData, currentPortfolioValue);
    if (!r.ok) return finalize('BLOCK', order, r.reason);
    // 7
    if (needsConfirmation(order, orderValue, modeResult)) {
      alert('warn', `Confirmation required: ${order.side} ${order.qty} ${order.ticker} (~$${orderValue.toFixed(0)})`, { order });
      return finalize('REQUEST_CONFIRMATION', order, 'Awaiting human approval via Telegram', { orderValue });
    }
    // PASSED ALL LAYERS
    STATE.consecutiveErrors = 0; // reset streak on a clean pass
    return finalize('EXECUTE', order, 'Passed all guardrails', { orderValue });
  } catch (err) {
    // Any unexpected error fails closed AND counts toward the breaker
    STATE.consecutiveErrors++;
    alert('critical', `Guardrail engine threw — failing closed: ${err.message}`, { order });
    return finalize('BLOCK', order, `Engine error (failed closed): ${err.message}`);
  }
}

// Called by the executor ONLY after a real fill, to update state honestly
function recordFill(order, fillValue) {
  STATE.lastTradeTs = nowSec();
  STATE.tradesThisHour.push(Date.now());
  STATE.tradesToday.push(Date.now());
  if (order.side === 'BUY') STATE.newCapitalToday += fillValue;
  audit('EXECUTED', order, 'Fill confirmed by broker', { fillValue });
}

function finalize(action, order, reason, extra = {}) {
  const decision = action === 'EXECUTE' ? 'APPROVED'
                 : action === 'REQUEST_CONFIRMATION' ? 'CONFIRM_REQUIRED'
                 : 'BLOCKED';
  const a = audit(decision, order, reason, extra);
  if (action === 'BLOCK' && !extra.soft) alert('block', `Trade blocked: ${reason}`, { order });
  return { action, reason, audit: a };
}

// ---- Manual controls (wire to Telegram commands) ----
function engageKillSwitch() { STATE.killSwitch = true; alert('critical', 'KILL SWITCH ENGAGED'); }
function releaseKillSwitch() { STATE.killSwitch = false; alert('warn', 'Kill switch released'); }
function resetGlobalHalt(reason) { STATE.globalHalt = false; STATE.consecutiveErrors = 0; alert('warn', `Global halt reset: ${reason}`); }
function clearTickerHalt(ticker) { STATE.haltedTickers.delete(ticker); alert('info', `Volatility halt cleared for ${ticker}`); }
function setMode(mode) {
  if (!['research','confirm','auto'].includes(mode)) return alert('block', `Refused invalid mode "${mode}"`);
  CONFIG.mode = mode; alert('warn', `Trading mode changed to "${mode}"`);
}
function startOfDayReset(liveValue) {
  STATE.dayStartValue = liveValue; STATE.newCapitalToday = 0;
  STATE.tradesToday = []; STATE.tradesThisHour = []; STATE.haltedTickers.clear();
  alert('info', `Start-of-day reset. Day-start value $${liveValue}`);
}

module.exports = {
  CONFIG, STATE, evaluateTrade, recordFill,
  engageKillSwitch, releaseKillSwitch, resetGlobalHalt, clearTickerHalt,
  setMode, startOfDayReset, getAuditLog: () => AUDIT,
};
