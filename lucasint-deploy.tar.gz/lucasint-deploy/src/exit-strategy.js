/**
 * exit-strategy.js
 * ───────────────────────────────────────────────────────────────────────────
 * Exit / sell discipline for held positions. THREE TIERS:
 *   Tier 1 — MONITOR: surface exit signals on holdings (advisory, safe).
 *   Tier 2 — SUGGEST: compute suggested stop + target levels (advisory framework).
 *   Tier 3 — EXECUTE: place stop/sell orders. LOCKED behind trade-guardrails;
 *            scaffolded only. Never active without explicit, deliberate opt-in.
 *
 * Shows ALL exit methods side by side so you choose, rather than imposing one:
 *   - Volatility (ATR) stop  — gives volatile small-caps room; suits your universe
 *   - Trailing stop          — ratchets up with price, locks in gains
 *   - Thesis/conviction decay — exit when the REASON to own has broken
 *   - Profit targets         — scale-out levels
 *   - Time stop              — thesis hasn't played out in window
 *
 * HONESTY: these are frameworks, not instructions. They don't know your tax
 * position, your other holdings, or the future. Exit decisions are yours; this
 * is squarely the kind of thing to discuss with a financial advisor.
 * ───────────────────────────────────────────────────────────────────────────
 */

const EXIT_CONFIG = {
  atrStopMultiple: 2.5,       // stop = entry - (2.5 x ATR). Wider = more room.
  trailingStopPct: 20,        // trail 20% below the high-water mark
  profitTargets: [25, 50, 100], // scale-out at +25%, +50%, +100%
  scaleOutFraction: 0.33,     // sell 1/3 at each target
  convictionDecayTrigger: 15, // alert if conviction drops this many points since buy
  timeStopMonths: 18,         // flag if thesis hasn't played out
  hardStopPct: 35,            // absolute backstop (last resort, very wide)
};

/**
 * Estimate ATR% from annualised volatility when true ATR isn't available.
 * (Live build should use real ATR from price history; this is a reasonable proxy.)
 */
function atrPctFromVol(annualVolPct) {
  if (annualVolPct == null) return null;
  // daily vol ≈ annual/sqrt(252); ATR ~ daily range, roughly daily vol.
  return +(annualVolPct / Math.sqrt(252)).toFixed(2);
}

/**
 * Compute all exit levels for a position.
 * @param pos { ticker, entryPrice, qty, entryConviction, entryDate }
 * @param live { price, high (high-water since entry), volatility, conviction, solvencyHigh, sector }
 */
function exitLevels(pos, live) {
  const out = {};

  // ── Volatility (ATR) stop ──
  const atrPct = atrPctFromVol(live.volatility);
  if (atrPct != null) {
    const atrAbs = pos.entryPrice * (atrPct / 100);
    out.atrStop = +(pos.entryPrice - EXIT_CONFIG.atrStopMultiple * atrAbs).toFixed(2);
    out.atrStopPct = +(((out.atrStop - pos.entryPrice) / pos.entryPrice) * 100).toFixed(1);
  }

  // ── Trailing stop (off the high-water mark since entry) ──
  const hwm = Math.max(live.high ?? live.price, pos.entryPrice);
  out.trailingStop = +(hwm * (1 - EXIT_CONFIG.trailingStopPct / 100)).toFixed(2);
  out.trailingFromHigh = EXIT_CONFIG.trailingStopPct;
  out.highWaterMark = +hwm.toFixed(2);

  // ── Hard backstop ──
  out.hardStop = +(pos.entryPrice * (1 - EXIT_CONFIG.hardStopPct / 100)).toFixed(2);

  // ── Profit targets (scale-out) ──
  out.profitTargets = EXIT_CONFIG.profitTargets.map(pct => ({
    pct,
    price: +(pos.entryPrice * (1 + pct / 100)).toFixed(2),
    action: `sell ${Math.round(EXIT_CONFIG.scaleOutFraction * 100)}% (${Math.round(pos.qty * EXIT_CONFIG.scaleOutFraction)} shares)`,
    hit: live.price >= pos.entryPrice * (1 + pct / 100),
  }));

  // ── Current P&L ──
  out.currentPnlPct = +(((live.price - pos.entryPrice) / pos.entryPrice) * 100).toFixed(1);

  return out;
}

/**
 * Tier 1 — surface active exit SIGNALS (advisory). Returns array of alerts.
 */
function exitSignals(pos, live) {
  const signals = [];
  const lv = exitLevels(pos, live);

  // Price below volatility stop
  if (lv.atrStop != null && live.price <= lv.atrStop)
    signals.push({ sev: 'high', type: 'ATR stop', msg: `Price $${live.price} at/below volatility stop $${lv.atrStop}. Normal-noise threshold breached.` });

  // Price below trailing stop
  if (live.price <= lv.trailingStop)
    signals.push({ sev: 'high', type: 'Trailing stop', msg: `Price $${live.price} below trailing stop $${lv.trailingStop} (${EXIT_CONFIG.trailingStopPct}% off high of $${lv.highWaterMark}).` });

  // Hard backstop
  if (live.price <= lv.hardStop)
    signals.push({ sev: 'critical', type: 'Hard stop', msg: `Price down ${EXIT_CONFIG.hardStopPct}%+ from entry. Backstop level — reassess urgently.` });

  // Conviction decay — the thesis-based exit
  if (live.conviction != null && pos.entryConviction != null) {
    const drop = pos.entryConviction - live.conviction;
    if (drop >= EXIT_CONFIG.convictionDecayTrigger)
      signals.push({ sev: 'high', type: 'Conviction decay', msg: `Conviction fell ${drop}pts (${pos.entryConviction}→${live.conviction}) since you bought. The reason to own may be weakening.` });
  }

  // New solvency flag appeared after purchase
  if (live.solvencyHigh)
    signals.push({ sev: 'high', type: 'Solvency', msg: `A high-severity solvency flag is now active on this holding. Balance-sheet risk emerged.` });

  // Profit target hit
  lv.profitTargets.forEach(pt => {
    if (pt.hit) signals.push({ sev: 'info', type: 'Profit target', msg: `Up +${pt.pct}% — target hit. Framework suggests: ${pt.action}.` });
  });

  // Time stop
  if (pos.entryDate) {
    const months = (Date.now() - new Date(pos.entryDate)) / (1000 * 60 * 60 * 24 * 30.4);
    if (months >= EXIT_CONFIG.timeStopMonths && lv.currentPnlPct < 10)
      signals.push({ sev: 'info', type: 'Time stop', msg: `Held ${Math.round(months)} months with little progress (${lv.currentPnlPct}%). Thesis may be dead money — consider redeploying.` });
  }

  return { signals, levels: lv };
}

/**
 * Tier 3 — EXECUTE (LOCKED). Returns a would-be order but never sends it unless
 * trade-guardrails are live AND mode permits. Scaffold only.
 */
function buildExitOrder(pos, live, reason) {
  return {
    _locked: true,
    note: 'Exit execution is LOCKED. This is a scaffold — routes through trade-guardrails on confirm/auto mode only, which requires deliberate opt-in.',
    intended: { ticker: pos.ticker, side: 'SELL', qty: pos.qty, reason, refPrice: live.price },
  };
}

module.exports = { EXIT_CONFIG, exitLevels, exitSignals, buildExitOrder, atrPctFromVol };
