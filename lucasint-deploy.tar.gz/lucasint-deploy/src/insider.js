/**
 * insider.js — Insider-buying signal from SEC EDGAR Form 4 filings (free, no key).
 *
 * Signal basis (finance literature): open-market BUYS (transaction code P) are the
 * strongest insider signal; CLUSTERS (multiple distinct insiders buying) are stronger
 * still. Sells (code S) are noisy (tax/diversification) so weighted lightly. Option
 * exercises / grants / gifts (M, A, G, F) are compensation mechanics — ignored.
 *
 * Reuses the CIK resolver from edgar.js. Parses the Form 4 ownershipDocument XML for
 * the fields we need. Absent data → neutral, never fabricated.
 */
const { cikFor } = require('./util/edgar');

const SEC_UA = { headers: { 'User-Agent': 'LucasINT/1.0 (contact: lucas@geojob.com)', 'Accept-Encoding': 'gzip, deflate' } };

async function getJson(url) { const r = await fetch(url, SEC_UA); if (!r.ok) throw new Error(`sec ${r.status}`); return r.json(); }
async function getText(url) { const r = await fetch(url, SEC_UA); if (!r.ok) throw new Error(`sec ${r.status}`); return r.text(); }

const tag = (xml, name) => { const m = xml.match(new RegExp(`<${name}>\\s*([\\s\\S]*?)\\s*</${name}>`, 'i')); return m ? m[1].trim() : null; };
const num = x => { const v = parseFloat(String(x).replace(/[^0-9.\-]/g, '')); return isFinite(v) ? v : null; };

/** Parse one Form 4 XML → array of non-derivative transactions we care about. */
function parseForm4(xml) {
  const owner = tag(xml, 'rptOwnerName') || 'insider';
  const isDir = /<isDirector>\s*(1|true)\s*<\/isDirector>/i.test(xml);
  const isOff = /<isOfficer>\s*(1|true)\s*<\/isOfficer>/i.test(xml);
  const txns = [];
  const blocks = xml.split(/<nonDerivativeTransaction>/i).slice(1);
  for (const b of blocks) {
    const code = tag(b, 'transactionCode');
    const shares = num(tag(b, 'transactionShares') ? tag(tag(b, 'transactionShares'), 'value') || tag(b, 'transactionShares') : null)
                || num((b.match(/<transactionShares>[\s\S]*?<value>([\d.,]+)<\/value>/i) || [])[1]);
    const price = num((b.match(/<transactionPricePerShare>[\s\S]*?<value>([\d.,]+)<\/value>/i) || [])[1]);
    if (code && shares) txns.push({ owner, isDir, isOff, code, shares, price: price || 0, value: shares * (price || 0) });
  }
  return txns;
}

/**
 * @param ticker
 * @param days lookback window (default 90 — buys predict 30-90d moves)
 * @returns { signal, cluster, buyers, sellers, netBuyValue, transactions, asOf } or { error }
 */
async function insiderActivity(ticker, days = 90) {
  try {
    const cik = await cikFor(ticker);
    const subs = await getJson(`https://data.sec.gov/submissions/CIK${cik}.json`);
    const r = subs.filings?.recent;
    if (!r) return { signal: 'neutral', note: 'No filing index.' };
    const cutoff = Date.now() - days * 864e5;
    const cikNum = String(parseInt(cik, 10));
    const form4s = [];
    for (let i = 0; i < r.form.length && form4s.length < 25; i++) {
      if (r.form[i] !== '4') continue;
      if (new Date(r.filingDate[i]).getTime() < cutoff) break;      // recent[] is newest-first
      form4s.push({ acc: r.accessionNumber[i].replace(/-/g, ''), date: r.filingDate[i] });
    }
    const buys = new Set(), sells = new Set(); let netBuyValue = 0; const transactions = [];
    for (const f of form4s) {
      // primary Form 4 XML lives at the predictable EDGAR archive path
      let xml;
      try { xml = await getText(`https://www.sec.gov/Archives/edgar/data/${cikNum}/${f.acc}/form4.xml`); }
      catch { continue; }                                            // some filers name it differently — skip, honest
      for (const t of parseForm4(xml)) {
        if (t.code === 'P') { buys.add(t.owner); netBuyValue += t.value; transactions.push({ ...t, date: f.date, dir: 'buy' }); }
        else if (t.code === 'S') { sells.add(t.owner); netBuyValue -= t.value; transactions.push({ ...t, date: f.date, dir: 'sell' }); }
      }
    }
    const cluster = buys.size >= 2;
    let signal = 'neutral';
    if (buys.size >= 1 && netBuyValue > 0) signal = cluster ? 'insider_buying_cluster' : 'insider_buying';
    else if (sells.size >= 2 && netBuyValue < 0) signal = 'insider_selling';        // needs a cluster — single sells are noise
    return { signal, cluster, buyers: buys.size, sellers: sells.size,
      netBuyValue: Math.round(netBuyValue), transactions, days, asOf: new Date().toISOString() };
  } catch (e) { return { error: e.message, signal: 'neutral' }; }
}

/** Score contribution for the conviction model (buys are the alpha; sells damped). */
function insiderScore(a) {
  if (!a || a.signal === 'neutral' || a.error) return { pts: 0, note: null };
  if (a.signal === 'insider_buying_cluster') return { pts: 8, note: `Insider buying cluster (${a.buyers} insiders, $${(a.netBuyValue/1e6).toFixed(1)}M net)` };
  if (a.signal === 'insider_buying') return { pts: 4, note: `Insider open-market buy ($${(a.netBuyValue/1e6).toFixed(1)}M)` };
  if (a.signal === 'insider_selling') return { pts: -3, note: `Insider selling cluster (${a.sellers} insiders)` };
  return { pts: 0, note: null };
}

module.exports = { insiderActivity, insiderScore, parseForm4 };
