/**
 * pit.js — Point-In-Time fundamentals from SEC EDGAR companyfacts.
 *
 * The one honest source for "what was knowable on date X": every datapoint in
 * companyfacts carries its `filed` date. We only use values FILED on or before
 * the snapshot date — no restatements from the future, no look-ahead bias.
 * US filers only (that's who files with the SEC).
 */
const fs = require('fs');
const path = require('path');

const SEC_UA = { headers: { 'User-Agent': 'LucasINT/1.0 (contact: lucas@geojob.com)', 'Accept-Encoding': 'gzip, deflate' } };
const FACTS_DIR = path.join(__dirname, '..', 'data', 'edgar-facts');

const TAGS = {
  revenue:     ['Revenues', 'RevenueFromContractWithCustomerExcludingAssessedTax', 'RevenueFromContractWithCustomerIncludingAssessedTax', 'SalesRevenueNet'],
  grossProfit: ['GrossProfit'],
  netIncome:   ['NetIncomeLoss'],
  equity:      ['StockholdersEquity', 'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest'],
  liabilities: ['Liabilities'],
  opCF:        ['NetCashProvidedByUsedInOperatingActivities'],
  capex:       ['PaymentsToAcquirePropertyPlantAndEquipment'],
  eps:         ['EarningsPerShareDiluted', 'EarningsPerShareBasic'],
  shares:      ['WeightedAverageNumberOfDilutedSharesOutstanding', 'WeightedAverageNumberOfSharesOutstandingBasic', 'CommonStockSharesOutstanding'],
};

async function fetchFactsCached(cik) {
  if (!fs.existsSync(FACTS_DIR)) fs.mkdirSync(FACTS_DIR, { recursive: true });
  const file = path.join(FACTS_DIR, `${cik}.json`);
  try {
    const st = fs.statSync(file);
    if (Date.now() - st.mtimeMs < 30 * 24 * 3600 * 1000) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch { /* fetch */ }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  try {
    const r = await fetch(`https://data.sec.gov/api/xbrl/companyfacts/CIK${cik}.json`, { ...SEC_UA, signal: ctrl.signal });
    if (!r.ok) throw new Error(`facts ${r.status}`);
    const j = await r.json();
    try { fs.writeFileSync(file, JSON.stringify(j)); } catch { }
    return j;
  } finally { clearTimeout(timer); }
}

/** All annual (FY, 10-K/20-F) points for a concept, FILED on/before asOf, newest fiscal-end first. */
function pitSeries(facts, tags, asOfISO) {
  for (const tax of ['us-gaap', 'ifrs-full', 'dei']) {
    const grp = facts.facts?.[tax];
    if (!grp) continue;
    for (const tag of tags) {
      const units = grp[tag]?.units;
      if (!units) continue;
      const unitKey = Object.keys(units)[0];
      const pts = units[unitKey].filter(p =>
        (p.form === '10-K' || p.form === '20-F') && p.fp === 'FY' && p.val != null &&
        p.filed && p.filed <= asOfISO
      );
      if (!pts.length) continue;
      const byEnd = {};
      for (const p of pts) if (!byEnd[p.end] || p.filed <= byEnd[p.end].filed) byEnd[p.end] = p; // earliest filing per FY = as first known
      const series = Object.values(byEnd).sort((a, b) => (a.end < b.end ? 1 : -1));
      if (series.length) return series;
    }
  }
  return [];
}

/** Fundamentals snapshot as known on asOf date. Returns null if nothing filed by then. */
function pitFundamentals(facts, asOfISO) {
  const g = (k) => pitSeries(facts, TAGS[k], asOfISO);
  const rev = g('revenue'), gp = g('grossProfit'), ni = g('netIncome'), eq = g('equity');
  const li = g('liabilities'), ocf = g('opCF'), cap = g('capex'), eps = g('eps'), sh = g('shares');
  if (!rev.length && !ni.length && !eq.length) return null;

  const v = s => s.length ? s[0].val : null;
  const prev = s => s.length > 1 ? s[1].val : null;

  const revenue = v(rev);
  const revGrowth = (revenue != null && prev(rev)) ? +(((revenue - prev(rev)) / Math.abs(prev(rev))) * 100).toFixed(1) : null;
  const grossMargin = (v(gp) != null && revenue) ? +((v(gp) / revenue) * 100).toFixed(1) : null;
  const roe = (v(ni) != null && v(eq)) ? +((v(ni) / v(eq)) * 100).toFixed(1) : null;
  const dToE = (v(li) != null && v(eq)) ? +(v(li) / v(eq)).toFixed(2) : null;
  const fcf = (v(ocf) != null) ? v(ocf) - (v(cap) ?? 0) : null;
  const fcfPerShare = (fcf != null && v(sh)) ? +(fcf / v(sh)).toFixed(2) : null;

  return {
    asOf: asOfISO,
    hasRevenue: revenue != null ? revenue > 0 : null,
    revGrowth, grossMargin, roe, dToE,
    fcfPerShare, eps: v(eps),
    latestFY: rev.length ? rev[0].end : (ni.length ? ni[0].end : null),
  };
}

module.exports = { fetchFactsCached, pitFundamentals };
